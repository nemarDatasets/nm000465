function output = ersp(EEG,ce,elec,elats,limits,bl,frequencies,freq_sd,method,mc)

% MC spits out p value for Cond1 > Cond2
% For four conditions it's Cond1 - Cond2 > Cond3 - Cond4

% CHECK ARGUMENTS
if nargin<10; mc = 0; end
if nargin<9; method = '%';end
if nargin<8||isempty(freq_sd); freq_sd = .5; end
% pre-assign output
output = struct;

% convert ms to samples
limits = round(limits*EEG.srate/1000);
% check if baseline is inside epoch, if so, convert to samples
if ~isstruct(bl); bl = round(bl*EEG.srate/1000); else bllimits = round(bl.limits*EEG.srate/1000); end

% MAKE DATA STRUCTURE
conditions = fieldnames(elats);
if ce == 1; data = eeg_getica(EEG); elseif ce == 2; data = EEG.data; end
data = data(elec,:);
if size(data,1) > 1
    data = mean(data,1);
end

% make epochs (and check for rejections)
artilats = [EEG.event(find(strcmpi({EEG.event.type},'boundary'))).latency];
for ic = 1:length(conditions)
    % get and make epoch limits
    eval(['lats = elats.' conditions{ic} ';']);
    lats = [lats'+limits(1) lats'+limits(2)]; il = size(lats,1);
    if isstruct(bl)
        eval(['bllats = bl.' conditions{ic} ';']);
        bllats = [bllats'+bllimits(1) bllats'+bllimits(2)];
    end
    % check for artifacts
    art = 0; arts = [];
    for ia = 1:length(artilats)
        inepoch = find(sum([artilats(ia) > lats(:,1) artilats(ia) < lats(:,2)]')==2);
        if ~isempty(inepoch); art = art+1; arts(art:art-1+length(inepoch)) = inepoch; end
        % if baseline outside of data, check baseline too
        if isstruct(bl)
            inepoch = find(sum([artilats(ia) > bllats(:,1) artilats(ia) < bllats(:,2)]')==2);
            if ~isempty(inepoch); art = art+1; arts(art:art-1+length(inepoch)) = inepoch; end
        end
    end
    lats(unique(arts),:) = [];
    eval(['output.reject.' conditions{ic} ' = unique(arts);']);
    disp(['Condition ' num2str(ic) ' (' conditions{ic} '): Number of epochs rejected for bad data: ' num2str(il - size(lats,1))]);
    % store
    eval(['lats' num2str(ic) ' = lats;']);
    if isstruct(bl); eval(['bllats' num2str(ic) ' = bllats;']); end
end

% preassign output
for icond = 1:length(conditions)
    eval(['output.ersp.' conditions{icond} ' = zeros(length(frequencies),limits(2)-limits(1)+1);']);
end
if mc > 0
    output.p = zeros(length(frequencies),limits(2)-limits(1)+1);
end

% Frequency decomposition
warning off
fprintf(['Beginning frequency decomp... ']);
for ifr = 1:length(frequencies)
    % filter and TF
    fprintf([num2str(ifr) ' ']);
    idata = abs(hilbert(eegfilt(double(data),EEG.srate,frequencies(ifr)-freq_sd,frequencies(ifr)+freq_sd,0,[],0,'fir1')'))'.^2;
    % go through conds
    for icond = 1:length(conditions)
        eval(['lats = lats' num2str(icond) ';']);
        ERSP = zeros(size(lats,1),limits(2)-limits(1)+1);
        % go through trials
        for it = 1:size(lats,1)
            % bl
            evlock = lats(it,1)+abs(limits(1));
            if ~isstruct(bl)
                bldata = mean(idata(evlock+bl(1):evlock+bl(2)));
            else
                eval(['bllats = bllats' num2str(icond) ';']);
                bldata = mean(idata(bllats(it,1):bllats(it,2)));
            end
            % erp
            if strcmpi(method,'%')
                ERSP(it,:) = 100*(idata(lats(it,1):lats(it,2)) - bldata)./bldata;
            elseif strcmpi(method,'z')
                triald = idata(lats(it,1):lats(it,2)) - bldata;
                ERSP(it,:) = (triald - mean(triald))./std(triald);
            elseif strcmpi(method,'db')
                ERSP(it,:) = 10*log10(idata(lats(it,1):lats(it,2))./ bldata);
            end
        end
        [h,p] = ttest(ERSP);
        eval(['output.ttest.' conditions{icond} '(ifr,:) = p;']);
        eval(['output.ersp.' conditions{icond} '(ifr,:) = mean(ERSP,1);']);
        eval(['ERSP' conditions{icond} ' = ERSP;']);
    end
    % normal ttesting
    if mc == 0
        if size(conditions,1) == 2
            eval(['sample1 = ERSP' conditions{1} ';']);
            eval(['sample2 = ERSP' conditions{2} ';']);
            diffp = zeros(1,size(sample1,2));
            for isamp = 1:size(sample1,2)
                diffp(isamp) = kruskalwallis([sample1(:,isamp); sample2(:,isamp)],[zeros(size(sample1,1),1);ones(size(sample2,1),1)],'off');
            end
            output.p(ifr,:) = diffp;
        elseif size(conditions,1) == 4 % this doesn't work yet!
            %{
            eval(['sample1 = ERSP' conditions{1} ';']);
            eval(['sample2 = ERSP' conditions{2} ';']);
            eval(['sample3 = ERSP' conditions{3} ';']);
            eval(['sample4 = ERSP' conditions{4} ';']);
            sample1 = sample1 - sample2;
            sample2 = sample3 - sample4;
            diffp = zeros(1,size(sample1,2));
            for isamp = 1:size(sample1,2)
                diffp(isamp) = kruskalwallis([sample1(:,isamp); sample2(:,isamp)],[zeros(size(sample1,1),1);ones(size(sample2,1),1)],'off');
            end
            output.p(ifr,:) = diffp;
            %}
            output.p = 0;
        end
    end
    % monte carlo testing
    if mc > 0
        % get original ERSP
        if length(conditions) == 2
            eval(['actual_diff = output.ersp.' conditions{1} '(ifr,:) - output.ersp.' conditions{2} '(ifr,:);']);
        elseif length(conditions) == 4
            eval(['actual_diff = (output.ersp.' conditions{1} '(ifr,:) - output.ersp.' conditions{2} '(ifr,:)) - (output.ersp.' conditions{3} '(ifr,:) - output.ersp.' conditions{4} '(ifr,:));']);
        else
            error('Monte carlo testing only works with two/four conditions!');
        end
        % mc it
        mclats = [lats1;lats2];
        totalep = size(mclats,1);
        ep1 = size(lats1,1);
        mcdiff = zeros(mc,size(actual_diff,2));
        for mci = 1:mc
            % shuffle lats
            mcclats = mclats(randperm(totalep),:);
            mclats1 = mcclats(1:ep1,:);
            mclats2 = mcclats(ep1+1:end,:);
            % make mc diff
            for icond = 1:length(conditions)
                % get lats (could use eval but slow)
                if icond == 1
                    lats = mclats1;
                elseif icond == 2
                    lats = mclats2;
                end
                ERSP = zeros(size(lats,1),limits(2)-limits(1)+1);
                % go through trials
                for it = 1:size(lats,1)
                    % bl
                    evlock = lats(it,1)+abs(limits(1));
                    bldata = mean(idata(evlock+bl(1):evlock+bl(2)));
                    % erp
                    if strcmpi(method,'%')
                        ERSP(it,:) = 100*(idata(lats(it,1):lats(it,2)) - bldata)/bldata;
                    elseif strcmpi(method,'z')
                        triald = idata(lats(it,1):lats(it,2)) - bldata;
                        ERSP(it,:) = (triald - mean(triald))/std(triald);
                    end
                end
                % store (could use eval but slow)
                if icond == 1
                    mcersp1 = mean(ERSP,1);
                elseif icond == 2
                    mcersp2 = mean(ERSP,1);
                elseif icond == 3
                    mcersp3 = mean(ERSP,1);
                elseif icond == 4
                    mcersp4 = mean(ERSP,1);
                end
            end % of making mc difference
            % make difference
            if size(conditions,1) == 2
                mcdiff(mci,:) = mcersp1 - mcersp2;
            elseif size(conditions,1) == 4
                mcdiff(mci,:) = (mcersp1 - mcersp2) - (mcersp3 - mcersp4);
            end
        end % of mc iterations
        % generate p val
        sortmcdiff = sort(mcdiff,1);
        for is = 1:size(mcdiff,2)
            firstsample = find(sortmcdiff(:,is)>actual_diff(is),1,'first');
            if isempty(firstsample); firstsample = mc; end
            output.p(ifr,is) = 1-(firstsample/mc);
        end
        
    end % of checking whether there is mc or not
end % of frequencies
fprintf('\n'); warning on