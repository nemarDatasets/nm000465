%% StopOR localizer block data import function
% Darcy  Diesburg
% This function imports raw LFP data from the StopOR project and converts
% it to the default EEGLab structure, with behavioral information and
% triggers as events. It takes the following inputs:
% is: a single value, the subject number to do
% datasets: A structure containing information about all the subjects in
% the sample. This structure is set up in StopOR_initialize and contains
% information about where raw data and behavioral data are located.
% folders: folder tree (a structure) for output files, set up in
% StopOR_initialize
function LFP = ImportLocalizerRawData(is,datasets,folders)

% pull subject number and load ephys file
subnum = datasets(is).subnum;
infile = char(datasets(is).eeg);
load(fullfile(folders.localizer,infile));

% account for different srate in some datasets
if intersect(is,1:4)
    srate = 24000;
else
    srate = 2000;
end

% Channels in LFP data - varies by subnum
chans_data = getlocchans(subnum);

% trigger channel used for TTL triggers
chans_trig = ['Inpt_RZ2_chn001'];

clear LFP % load in each channel - this may take a little while
for ic = 1:length(chans_data)
    
    % load data
    eval(['LFP.data(' num2str(ic) ',:) = double(' chans_data{ic,1} '.dat);']);
    
    % load name
    LFP.chanlocs(ic).labels = chans_data{ic,2};
    
end

% mandatory fields for eeglab data structure
eval(['LFP.setname = ' char(39) 'Subject_' num2str(datasets(is).subnum) char(39) ';']);
eval(['LFP.filename = ' char(39) 'Subject_' num2str(datasets(is).subnum) '.set' char(39) ';']);
LFP.icawinv = []; LFP.icaweights = []; LFP.icachansind = []; LFP.icasphere = []; LFP.icaact = [];
LFP.pnts = size(LFP.data,2); LFP.nbchan = size(LFP.data,1);
LFP.srate = srate;
LFP.trials = 1;
LFP.xmin = 0; LFP.xmax = LFP.pnts/LFP.srate;
LFP.comments = []; LFP.filepath = fullfile(folders.pp);
LFP.event = []; LFP.urevent = [];

% load behav
filename = char(datasets(is).localizer);
load(fullfile(folders.behavloc,filename));
trialseq_id = Basicstop_columns;
if strcmpi(subnum,'106') ==1; trialseq(38:41,:) = [];end % this participant didn't do the last few trials of localizer

eval(['trchan = ' chans_trig '.dat;']);
% search input channel for upflanks that mark trigger latency
bigsamples = find(trchan>1); triggers = bigsamples(logical([diff(bigsamples)>1; 1]))-3;

% remove extra trigger
if strcmpi(subnum,'101') == 1 || strcmpi(subnum,'125') == 1; triggers(1) = []; end
shouldbetrig = length(trialseq);
if shouldbetrig ~= size(triggers,1); error('Triggers and trials mismatch'); end

triggerclass = zeros(length(triggers),1); % 0's are go's, 1's are stops
triggertrial = 1:length(trialseq);

% Add triggers to event structure
rcnt = 0; clear stimuli; clear responses;
for it = 1:length(triggers)
    if triggerclass(it) == 0; stimuli(it).type = 'GoStimulus';
    elseif triggerclass(it) == 1; stimuli(it).type = 'StopStimulus'; end
    stimuli(it).duration = 1;
    stimuli(it).latency = triggers(it);
    stimuli(it).tnum = triggertrial(it);
    stimuli(it).side = trialseq(triggertrial(it),trialseq_id.dir);
    stimuli(it).resp_side = trialseq(triggertrial(it),trialseq_id.resp);
    stimuli(it).acc = trialseq(triggertrial(it),trialseq_id.acc);
    stimuli(it).rt = trialseq(triggertrial(it),trialseq_id.rt);
    stimuli(it).behav = trialseq(triggertrial(it),:);
    
    % add responses
    if trialseq(triggertrial(it),trialseq_id.rt) > 0
        rcnt = rcnt + 1;
        responses(rcnt) = stimuli(it);
        responses(rcnt).type = 'Response';
        responses(rcnt).latency = triggers(it) + trialseq(triggertrial(it),trialseq_id.rt)*srate/1000;
        responses(rcnt).tnum = triggertrial(it);
        responses(rcnt).rt = trialseq(triggertrial(it),trialseq_id.rt);
        responses(rcnt).behav = trialseq(triggertrial(it),:);
    end
end

% concatenate stimulus and responses events
events = [stimuli responses];
[~,b] = sort([events.latency]); LFP.event = events(b);