%% Beta burst detection script
%This script identifies beta bursts in our LFP data around all event
% markers, then saves indices of bursts for further analysis. The script
% cycles through the analysis twice for thalamic implant subjects, once
% each for VIM and dorsal thalamus implants
window = [-.5 1]; % window around ev to look for bursts
srate = 1000; 
frequencies = 15:29; % define limits of beta band
cycles = 7;
mediancutoff = 6;
% this setting at 1 pulls previously selected beta channels so you use the
% same ones from the previous time, regardless of window/other settings. If
% you haven't run before, run once with it set at 0, then at 1.
channels_selected = 1;

for is = 1:length(datasets) % do once for each subject
    disp(['Working on Subject ' num2str(is) '!']);
    subnum = datasets(is).subnum; % sub number for file load/save

    % clear output to prevent accumulation from prev subs
    clear trialevs blevs LFP chanlabels evfreqs evlength blevfreqs blevlength
    
    % load in preprocessed data and selected channels if this analysis has
    % already been run
    if channels_selected; load(fullfile(folders.beta,['Subject' num2str(subnum) 'selchans.mat'])); end
    load(fullfile(folders.pp,['Subject' datasets(is).subnum '-LFP.mat']));
    % selected artifactual periods
    load(fullfile(folders.pp,['ManualRej' num2str(datasets(is).subnum) '.mat']),'rejpoints','rejections');

    % remove single blocks with flagged accuracy or rt issues
    if strcmpi(subnum,'104'); LFP.event(find(arrayfun(@(x) isequal(x.behav(2),4), LFP.event))) = [];
    elseif strcmpi(subnum,'105'); LFP.event(find(arrayfun(@(x) isequal(x.behav(2),3), LFP.event))) = [];
    elseif strcmpi(subnum,'109'); LFP.event(find(arrayfun(@(x) isequal(x.behav(2),2), LFP.event))) = [];
    elseif strcmpi(subnum,'110'); LFP.event(find(arrayfun(@(x) isequal(x.behav(2),1), LFP.event))) = [];
    elseif strcmpi(subnum,'113'); LFP.event(find(arrayfun(@(x) isequal(x.behav(2),4), LFP.event))) = [];
    elseif strcmpi(subnum,'129'); LFP.event(find(arrayfun(@(x) isequal(x.behav(2),2), LFP.event))) = [];
    end
    LM1 = []; RM1 = []; RSTN = []; LSTN = []; RVIM = []; LVIM = []; % preassign
    
    % Prepare to remake channels into bipolar arrays
    % find contacts that exist for each subject (some had bigger M1 strips, some had STN and not VIM)
    % We only grab the channels determined by the neurosurgeon to be
    % placed in VIM proper. All potential STN channels included.
    rstn_chans = find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'R STN'))); % R STN channels
    if ~isempty(rstn_chans); rstn_chans = [find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'R STN LFP 0'))) find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'R STN LFP 1'))) find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'R STN LFP 2'))) find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'R STN LFP 3')))]; end
    lstn_chans = find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'L STN'))); % L STN channels
    if ~isempty(lstn_chans); lstn_chans = [find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'L STN LFP 0'))) find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'L STN LFP 1'))) find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'L STN LFP 2'))) find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'L STN LFP 3')))]; end
    rvim_chans = find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'R VIM'))); % R VIM channels
    if ~isempty(rvim_chans); rvim_chans = [find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'R VIM LFP 0'))) find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'R VIM LFP 1')))]; end 
    lvim_chans = find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'L VIM'))); % L VIM channels
    if ~isempty(lvim_chans); lvim_chans = [find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'L VIM LFP 0'))) find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'L VIM LFP 1')))]; end
    rm1_chans = find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'R subgaleal'))); % R M1 channels
    lm1_chans = find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'L subgaleal'))); % L M1 channels
    number_of_locations = ~isempty(rstn_chans) + ~isempty(lstn_chans) + ~isempty(rvim_chans) + ~isempty(lvim_chans) + ~isempty(rm1_chans) + ~isempty(lm1_chans);
    locations = {'rstn','lstn','rvim','lvim','rm1','lm1'}; % all possible contacts
         
    % go through locations and make bipolar data with M1 contacts available
    newchanlocs = []; % will be appended
    newdata = []; % will be appended
    for il = 1:length(locations)
        % check if location is present in subject
        loclabel = [locations{il} '_chans'];
        eval(['locchans = ' loclabel ';']);
        if ~isempty(locchans)
            % go through location channels and make data and chanlabel
            locdata = zeros(length(locchans)-1,LFP.pnts);
            locchanlocs = LFP.chanlocs(1);  % will be overwritten, adopt structure layout
            for ilc = 1:length(locchans)-1
                locdata(ilc,:) = LFP.data(locchans(ilc),:) - LFP.data(locchans(ilc+1),:);
                locchanlocs(ilc).labels = [locations{il} '_' num2str(ilc)];
            end
            % identify new channel indices
            eval([loclabel ' = [' num2str(length(newchanlocs)+1:length(newchanlocs)+length(locchanlocs)) '];']);
            % append data and chanlocs
            newchanlocs = [newchanlocs locchanlocs];
            newdata = [newdata; locdata];
        end
    end
    % insert bipolar arrays into main EEGLab structure
    LFP.data = newdata; LFP.chanlocs = newchanlocs; LFP.nbchan = length(LFP.chanlocs);
    
    % extract behavior from LFP trials
    events = reshape([LFP.event.behav],length(LFP.event(2).behav),length([LFP.event.behav])/length(LFP.event(2).behav))';
    [~,b] = unique(events(:,1));
    trialseq = events(b,:);
    
    % convert event types to our preferred standard
    gostims = find(strcmpi({LFP.event.type},'GoStimulus'));
    gotrials = find([LFP.event.acc] ~= 3 & [LFP.event.acc] ~= 4);
    stoptrials = find([LFP.event.acc] == 3 | [LFP.event.acc] == 4);
    % insert types
    s200 = find(strcmpi({LFP.event.type},'StopStimulus'));
    for ie = 1:length(s200); LFP.event(s200(ie)).type = 'S200'; end
    s1 = intersect(gostims,gotrials);
    for ie = 1:length(s1); LFP.event(s1(ie)).type = 'S  1'; end
    s2 = intersect(gostims,stoptrials);
    for ie = 1:length(s2); LFP.event(s2(ie)).type = 'S  2'; end
    % delete response events for this analysis (we pull this info from
    % the behavioral data when we need RT)
    LFP.event(strcmpi({LFP.event.type},'Response')) = [];
    % reject segments marked for rejection due to artifact
    LFP = pop_select(LFP,'nopoint',rejpoints);
    LFP.event(strcmpi({LFP.event.type},'Response')) = [];
    
    % get RT and SSRT from included trials
    behav = Basicstop_analyze(trialseq,1);
    SSRT = behav.RT.SSRTi;
    RT = behav.RT.corgo;
    ssrtsamples = round(SSRT*LFP.srate/1000);
    % save behavior for each participant
    % save(fullfile(folders.behavout,['Subject' num2str(subnum) '_behavanalysis.mat']),'behav');
    
    % create wavelet for time-frequency conversion (will be same for other channel
    % segmentations as well, just different contacts)
    time = -1:1/LFP.srate:1;
    % pre assign
    wavelet_conv_data = zeros(length(frequencies),LFP.pnts);
    
    % go through channels
    for ic = 1:LFP.nbchan
        
        % preassign
        tLFP = LFP;
        
        % go through frequencies
        for ifr = 1:length(frequencies)
            
            % freqs and cycles
            f = frequencies(ifr);
            s = cycles/(2*pi*f);
            % sine and gaussian
            sine_wave = exp(1i*2*pi*f.*time);
            gaussian_win = exp(-time.^2./(2*s^2));
            % normalization factor
            normalization_factor = 1 / (s * sqrt(2* pi));
            % make wavelet
            wavelet = normalization_factor .* sine_wave .* gaussian_win;
            halfwaveletsize = ceil(length(wavelet)/2); % half of the wavelet size
            
            % convolve with data
            n_conv = length(wavelet) + LFP.pnts - 1; % compute Gaussian
            % fft
            fft_w = fft(wavelet,n_conv);
            fft_e = fft(LFP.data(ic,:),n_conv);
            ift   = ifft(fft_e.*fft_w,n_conv);
            wavelet_conv_data(ifr,:) = abs(ift(halfwaveletsize:end-halfwaveletsize+1)).^2;
            
        end
        
        % insert into temporary EEGlab structure
        tLFP.data = wavelet_conv_data;
        tLFP.nbchan = 1:length(frequencies); tLFP.chanlocs = []; tLFP.icaweights = []; tLFP.icawinv = [];
        
        % epoch around our events of interest (avoiding snipped
        % segments)
        eLFP = pop_epoch(tLFP,{'S200' 'S  1' 'S  2'},window);
        epochs = eLFP.data;
        eventsample = abs(window(1)*LFP.srate); % onset of event within epoch
        
        % get trial info we want later
        accuracy = zeros(eLFP.trials,1); for ie = 1:eLFP.trials; accuracy(ie) = eLFP.epoch(ie).eventacc{1}; end
        ssd = zeros(eLFP.trials,1); for ie = 1:eLFP.trials; ssd(ie) = eLFP.epoch(ie).eventbehav{1}(4+eLFP.epoch(ie).eventbehav{1}(3)); end
        side = zeros(eLFP.trials,1); for ie = 1:eLFP.trials; side(ie) = eLFP.epoch(ie).eventbehav{1}(3); end
        tnum = zeros(eLFP.trials,1); for ie = 1:eLFP.trials; tnum(ie) = eLFP.epoch(ie).eventtnum{1}; end
        % convert go-locked stop-trial accuracy to be able to separate stop from go-locked data based on acc variable alone
        tt = {}; lastStopDone = 0;
        for ie = 1:eLFP.trials
            % if two evs at same latency (trial where SSD = 0)
            evlock = find(cell2mat(eLFP.epoch(ie).eventlatency)==0); 
            if length(evlock)>1
                if ie>lastStopDone
                    tt(ie) = eLFP.epoch(ie).eventtype(evlock(1));
                    tt(ie+1) = eLFP.epoch(ie+1).eventtype(evlock(2));
                    lastStopDone = ie+1;
                end
            else % any other time - SSD > 0 or go trial
                tt(ie) = eLFP.epoch(ie).eventtype(evlock(1)); 
            end
        end
        rt = zeros(eLFP.trials,1); for ie = 1:eLFP.trials; rt(ie) = eLFP.epoch(ie).eventrt{1}; end
        accuracy(strcmpi(tt,'S  2')) = accuracy(strcmpi(tt,'S  2')) + 1000; % now all go-locked stop trials will be accuracy+1000
        
        % get frequency medians
        fmedian = zeros(size(epochs,1),1);
        for ifr = 1:size(epochs,1)
            alldata = [reshape(squeeze(epochs(ifr,:,accuracy<1000)),size(epochs,2)*sum(accuracy<1000),1)];
            fmedian(ifr,1) = median(alldata);
        end
        
        % go through trials and pull all beta events
        if ic == 1; eventnums = zeros(LFP.nbchan,size(eLFP.data,1)); bl_eventnums = eventnums; end % preassign
        for it = 1:size(epochs,3)
            
            % POST-event
            % get trial TF data (from event to end of window, here, 1000ms)
            tdata = squeeze(epochs(:,eventsample+1:end,it));
            % find local maxima
            [peakF,peakT] = find(imregionalmax(tdata));
            % get power for events
            peakpower = zeros(length(peakF),5); % column 1 = value, column 2 =  above threshold
            for ie = 1:length(peakF)
                peakpower(ie,1) = tdata(peakF(ie),peakT(ie));
                if peakpower(ie,1) > mediancutoff*fmedian(peakF(ie)); peakpower(ie,2) = 1; end % check cutoff
                peakpower(ie,3) = peakF(ie)+frequencies(1)-1; % frequency of blob
                peakpower(ie,4) = peakT(ie)*1000/LFP.srate; % ms of blob
                if peakpower(ie,1) > mediancutoff*fmedian(peakF(ie))
                start_burst = find(fliplr(tdata(peakF(ie),1:peakT(ie)))<mediancutoff*fmedian(peakF(ie)),1,'first'); 
                if isempty(start_burst); start_burst = peakT(ie)-1; end
                stop_burst = find(tdata(peakF(ie),peakT(ie):end)<mediancutoff*fmedian(peakF(ie)),1,'first');
                if isempty(stop_burst); stop_burst = length(tdata)-peakT(ie); end
                peakpower(ie,5) = ((peakT(ie)+stop_burst)-(peakT(ie)-start_burst))*1000/LFP.srate;
                end
            end
            eventnums(ic,it) = sum(peakpower(:,2));
            peakpower = peakpower(logical(peakpower(:,2)),:);
            % store
            channame = LFP.chanlocs(ic).labels; channame(strfind(channame,' ')) = [];
            if eventnums(ic,it) > 0
                eval(['trialevs.' channame '.t' num2str(it) ' = [' num2str(peakpower(:,4)') '];']);
                eval(['evfreqs.' channame '.t' num2str(it) ' = [' num2str(peakpower(:,3)') '];']);
                eval(['evlength.' channame '.t' num2str(it) ' = [' num2str(peakpower(:,5)') '];']);
            else
                eval(['trialevs.' channame '.t' num2str(it) ' = [];']);
                eval(['evfreqs.' channame '.t' num2str(it) ' = [];']);
                eval(['evlength.' channame '.t' num2str(it) ' = [];']);                
            end
            
            % baseline
            % get trial TF data (from -SSRT to event)
            tdata = squeeze(epochs(:,1:eventsample-1,it));
            % find local maxima
            [peakF,peakT] = find(imregionalmax(tdata));
            % get power for events
            peakpower = zeros(length(peakF),5); % column 1 = value, column 2 =  above threshold
            for ie = 1:length(peakF)
                peakpower(ie,1) = tdata(peakF(ie),peakT(ie));
                peakpower(ie,3) = peakF(ie)+frequencies(1)-1; % frequency of blob
                peakpower(ie,4) = peakT(ie)*1000/LFP.srate; % ms of blob
                if peakpower(ie,1) > mediancutoff*fmedian(peakF(ie)); peakpower(ie,2) = 1; end
                if peakpower(ie,1) > mediancutoff*fmedian(peakF(ie))
                start_burst = find(fliplr(tdata(peakF(ie),1:peakT(ie)))<mediancutoff*fmedian(peakF(ie)),1,'first'); 
                if isempty(start_burst); start_burst = peakT(ie)-1; end
                stop_burst = find(tdata(peakF(ie),peakT(ie):end)<mediancutoff*fmedian(peakF(ie)),1,'first');
                if isempty(stop_burst); stop_burst = length(tdata)-peakT(ie); end
                peakpower(ie,5) = ((peakT(ie)+stop_burst)-(peakT(ie)-start_burst))*1000/LFP.srate;
                end
            end
            bl_eventnums(ic,it) = sum(peakpower(:,2));
            peakpower = peakpower(logical(peakpower(:,2)),:);
            % store
            channame = LFP.chanlocs(ic).labels; channame(strfind(channame,' ')) = [];
            if eventnums(ic,it) > 0
                eval(['blevs.' channame '.t' num2str(it) ' = [' num2str(peakpower(:,4)') '];']);
                eval(['blevfreqs.' channame '.t' num2str(it) ' = [' num2str(peakpower(:,3)') '];']);
                eval(['blevlength.' channame '.t' num2str(it) ' = [' num2str(peakpower(:,5)') '];']);
            else
                eval(['blevs.' channame '.t' num2str(it) ' = [];']);
                eval(['blevfreqs.' channame '.t' num2str(it) ' = [];']);
                eval(['blevlength.' channame '.t' num2str(it) ' = [];']);
            end
            
        end
        if channels_selected == 1
            if ic == selchans(1); RSTN = eLFP; end
            if ic == selchans(2); LSTN = eLFP; end
            if ic == selchans(3); RM1 = eLFP; end
            if ic == selchans(4); LM1 = eLFP; end
            if ic == selchans(5); RVIM = eLFP; end
            if ic == selchans(6); LVIM = eLFP; end
        end
    end
    
    % select bipolar contacts to save with data
    totalevs = sum(eventnums,2);
    if channels_selected == 0
        if ~isempty(rstn_chans); [~,rstn] = max(totalevs(rstn_chans)); rstn = rstn + rstn_chans(1)-1; else; rstn = 0; end % right stn
        if ~isempty(lstn_chans); [~,lstn] = max(totalevs(lstn_chans)); lstn = lstn + lstn_chans(1)-1; else; lstn = 0; end % left stn
        if ~isempty(rm1_chans); [~,rm1] = max(totalevs(rm1_chans)); rm1 = rm1 + rm1_chans(1)-1; else; rm1 = 0; end % right m1
        if ~isempty(lm1_chans); [~,lm1] = max(totalevs(lm1_chans)); lm1 = lm1 + lm1_chans(1)-1; else; lm1 = 0; end % left m1
        if ~isempty(rvim_chans); [~,rvim] = max(totalevs(rvim_chans)); rvim = rvim + rvim_chans(1)-1; else; rvim = 0; end % right vim
        if ~isempty(lvim_chans); [~,lvim] = max(totalevs(lvim_chans)); lvim = lvim + lvim_chans(1)-1; else; lvim = 0; end % left vim
        selchans = [rstn lstn rm1 lm1 rvim lvim]; chanlabels = {LFP.chanlocs.labels}; chanlabels = chanlabels(selchans(selchans~=0));
    end

    
    % save beta burst indices (with behavioral exclusion blocks removed)
    %save(fullfile(folders.beta,['Subject' num2str(subnum) '.mat']),'chanlabels','trialseq','trialevs','blevs','blevs','blevfreqs','blevlength','evfreqs','evlength','RT','rt','SSRT','accuracy','ssd','side','tnum','selchans','RSTN','LSTN','LM1','RM1','LVIM','RVIM');
    %if channels_selected == 0; save(fullfile(folders.beta,['Subject' num2str(subnum) 'selchans.mat']),'chanlabels','selchans'); end
end

%% do beta detection for dorsal thalamus
for is = tha % do once for each subject
    disp(['Dorsal thalamus - working on Subject ' num2str(is) '!']);
    subnum = datasets(is).subnum; % sub number for file load/save

    % clear output to prevent accumulation from prev subs
    clear trialevs blevs LFP chanlabels evfreqs evlength blevfreqs blevlength
    
    % load in preprocessed data and selected channels if this analysis has
    % already been run
    load(fullfile(folders.pp,['Subject' datasets(is).subnum '-LFP.mat']));
    % selected artifactual periods
    load(fullfile(folders.pp,['ManualRej' num2str(datasets(is).subnum) '.mat']),'rejpoints','rejections');

    % remove single blocks with flagged accuracy or rt issues
    if strcmpi(subnum,'104'); LFP.event(find(arrayfun(@(x) isequal(x.behav(2),4), LFP.event))) = [];
    elseif strcmpi(subnum,'105'); LFP.event(find(arrayfun(@(x) isequal(x.behav(2),3), LFP.event))) = [];
    elseif strcmpi(subnum,'109'); LFP.event(find(arrayfun(@(x) isequal(x.behav(2),2), LFP.event))) = [];
    elseif strcmpi(subnum,'110'); LFP.event(find(arrayfun(@(x) isequal(x.behav(2),1), LFP.event))) = [];
    elseif strcmpi(subnum,'113'); LFP.event(find(arrayfun(@(x) isequal(x.behav(2),4), LFP.event))) = [];
    elseif strcmpi(subnum,'129'); LFP.event(find(arrayfun(@(x) isequal(x.behav(2),2), LFP.event))) = [];
    end
    LM1 = []; RM1 = []; RSTN = []; LSTN = []; RVIM = []; LVIM = []; % preassign
    
    % Prepare to remake channels into bipolar arrays
    % find contacts that exist for each subject (some had bigger M1 strips, some had STN and not VIM)
    % We only grab the channels determined by the neurosurgeon to be
    % placed in VIM proper. All potential STN channels included.
    rstn_chans = find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'R STN'))); % R STN channels
    lstn_chans = find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'L STN'))); % L STN channels
    rvim_chans = find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'R VIM'))); % R VIM channels
    if ~isempty(rvim_chans); rvim_chans = [find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'R VIM LFP 2'))) find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'R VIM LFP 3')))]; end 
    lvim_chans = find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'L VIM'))); % L VIM channels
    if ~isempty(lvim_chans); lvim_chans = [find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'L VIM LFP 2'))) find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'L VIM LFP 3')))]; end
    rm1_chans = find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'R subgaleal'))); % R M1 channels
    lm1_chans = find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'L subgaleal'))); % L M1 channels
    number_of_locations = ~isempty(rstn_chans) + ~isempty(lstn_chans) + ~isempty(rvim_chans) + ~isempty(lvim_chans) + ~isempty(rm1_chans) + ~isempty(lm1_chans);
    locations = {'rstn','lstn','rvim','lvim','rm1','lm1'}; % all possible contacts
    
    % go through locations and make bipolar data with M1 contacts available
    newchanlocs = []; % will be appended
    newdata = []; % will be appended
    for il = 1:length(locations)
        % check if location is present in subject
        loclabel = [locations{il} '_chans'];
        eval(['locchans = ' loclabel ';']);
        if ~isempty(locchans)
            % go through location channels and make data and chanlabel
            locdata = zeros(length(locchans)-1,LFP.pnts);
            locchanlocs = LFP.chanlocs(1);  % will be overwritten, adopt structure layout
            for ilc = 1:length(locchans)-1
                locdata(ilc,:) = LFP.data(locchans(ilc),:) - LFP.data(locchans(ilc+1),:);
                locchanlocs(ilc).labels = [locations{il} '_' num2str(ilc)];
            end
            % identify new channel indices
            eval([loclabel ' = [' num2str(length(newchanlocs)+1:length(newchanlocs)+length(locchanlocs)) '];']);
            % append data and chanlocs
            newchanlocs = [newchanlocs locchanlocs];
            newdata = [newdata; locdata];
        end
    end
    
    % insert bipolar arrays into main EEGLab structure
    LFP.data = newdata; LFP.chanlocs = newchanlocs; LFP.nbchan = length(LFP.chanlocs);
    
    % extract behavior from LFP trials
    events = reshape([LFP.event.behav],length(LFP.event(2).behav),length([LFP.event.behav])/length(LFP.event(2).behav))';
    [~,b] = unique(events(:,1));
    trialseq = events(b,:);
    
    % convert event types to our preferred standard
    gostims = find(strcmpi({LFP.event.type},'GoStimulus'));
    gotrials = find([LFP.event.acc] ~= 3 & [LFP.event.acc] ~= 4);
    stoptrials = find([LFP.event.acc] == 3 | [LFP.event.acc] == 4);
    % insert types
    s200 = find(strcmpi({LFP.event.type},'StopStimulus'));
    for ie = 1:length(s200); LFP.event(s200(ie)).type = 'S200'; end
    s1 = intersect(gostims,gotrials);
    for ie = 1:length(s1); LFP.event(s1(ie)).type = 'S  1'; end
    s2 = intersect(gostims,stoptrials);
    for ie = 1:length(s2); LFP.event(s2(ie)).type = 'S  2'; end
    % delete response events for this analysis (we pull this info from
    % the behavioral data when we need RT)
    LFP.event(strcmpi({LFP.event.type},'Response')) = [];
    % reject segments marked for rejection due to artifact
    LFP = pop_select(LFP,'nopoint',rejpoints);
    
    % get RT and SSRT from included trials
    behav = Basicstop_analyze(trialseq,1);
    SSRT = behav.RT.SSRTi;
    RT = behav.RT.corgo;
    ssrtsamples = round(SSRT*LFP.srate/1000);
   
    % create wavelet for time-frequency conversion
    time = -1:1/LFP.srate:1;
    % pre assign
    wavelet_conv_data = zeros(length(frequencies),LFP.pnts);
    
    % go through channels
    for ic = 1:LFP.nbchan
        
        % preassign
        tLFP = LFP;
        
        % go through frequencies
        for ifr = 1:length(frequencies)
            
            % freqs and cycles
            f = frequencies(ifr);
            s = cycles/(2*pi*f);
            % sine and gaussian
            sine_wave = exp(1i*2*pi*f.*time);
            gaussian_win = exp(-time.^2./(2*s^2));
            % normalization factor
            normalization_factor = 1 / (s * sqrt(2* pi));
            % make wavelet
            wavelet = normalization_factor .* sine_wave .* gaussian_win;
            halfwaveletsize = ceil(length(wavelet)/2); % half of the wavelet size
            
            % convolve with data
            n_conv = length(wavelet) + LFP.pnts - 1; % compute Gaussian
            % fft
            fft_w = fft(wavelet,n_conv);
            fft_e = fft(LFP.data(ic,:),n_conv);
            ift   = ifft(fft_e.*fft_w,n_conv);
            wavelet_conv_data(ifr,:) = abs(ift(halfwaveletsize:end-halfwaveletsize+1)).^2;
            
        end
        
        % insert into temporary EEGlab structure
        tLFP.data = wavelet_conv_data;
        tLFP.nbchan = 1:length(frequencies); tLFP.chanlocs = []; tLFP.icaweights = []; tLFP.icawinv = [];
        
        % epoch around our events of interest (avoiding snipped
        % segments)
        eLFP = pop_epoch(tLFP,{'S200' 'S  1' 'S  2'},window);
        epochs = eLFP.data;
        eventsample = abs(window(1)*LFP.srate); % onset of event within epoch
        
        % get trial info we want later
        accuracy = zeros(eLFP.trials,1); for ie = 1:eLFP.trials; accuracy(ie) = eLFP.epoch(ie).eventacc{1}; end
        ssd = zeros(eLFP.trials,1); for ie = 1:eLFP.trials; ssd(ie) = eLFP.epoch(ie).eventbehav{1}(4+eLFP.epoch(ie).eventbehav{1}(3)); end
        side = zeros(eLFP.trials,1); for ie = 1:eLFP.trials; side(ie) = eLFP.epoch(ie).eventbehav{1}(3); end
        tnum = zeros(eLFP.trials,1); for ie = 1:eLFP.trials; tnum(ie) = eLFP.epoch(ie).eventtnum{1}; end
        % convert go-locked stop-trial accuracy to be able to separate stop from go-locked data based on acc variable alone
        tt = {}; lastStopDone = 0;
        for ie = 1:eLFP.trials
            % if two evs at same latency (trial where SSD = 0)
            evlock = find(cell2mat(eLFP.epoch(ie).eventlatency)==0); 
            if length(evlock)>1
                if ie>lastStopDone
                    tt(ie) = eLFP.epoch(ie).eventtype(evlock(1));
                    tt(ie+1) = eLFP.epoch(ie+1).eventtype(evlock(2));
                    lastStopDone = ie+1;
                end
            else % any other time - SSD > 0 or go trial
                tt(ie) = eLFP.epoch(ie).eventtype(evlock(1)); 
            end
        end
        rt = zeros(eLFP.trials,1); for ie = 1:eLFP.trials; rt(ie) = eLFP.epoch(ie).eventrt{1}; end
        accuracy(strcmpi(tt,'S  2')) = accuracy(strcmpi(tt,'S  2')) + 1000; % now all go-locked stop trials will be accuracy+1000
        
        % get frequency medians
        fmedian = zeros(size(epochs,1),1);
        for ifr = 1:size(epochs,1)
            alldata = [reshape(squeeze(epochs(ifr,:,accuracy<1000)),size(epochs,2)*sum(accuracy<1000),1)];
            fmedian(ifr,1) = median(alldata);
        end
        
        % go through trials and pull all beta events
        if ic == 1; eventnums = zeros(LFP.nbchan,size(eLFP.data,1)); bl_eventnums = eventnums; end % preassign
        for it = 1:size(epochs,3)
            
            % POST-event
            % get trial TF data (from event to SSRT)
            tdata = squeeze(epochs(:,eventsample+1:end,it));
            % find local maxima
            [peakF,peakT] = find(imregionalmax(tdata));
            % get power for events
            peakpower = zeros(length(peakF),5); % column 1 = value, column 2 =  above threshold
            for ie = 1:length(peakF)
                peakpower(ie,1) = tdata(peakF(ie),peakT(ie));
                if peakpower(ie,1) > mediancutoff*fmedian(peakF(ie)); peakpower(ie,2) = 1; end % check cutoff
                peakpower(ie,3) = peakF(ie)+frequencies(1)-1; % frequency of blob
                peakpower(ie,4) = peakT(ie)*1000/LFP.srate; % ms of blob
                if peakpower(ie,1) > mediancutoff*fmedian(peakF(ie))
                start_burst = find(fliplr(tdata(peakF(ie),1:peakT(ie)))<mediancutoff*fmedian(peakF(ie)),1,'first'); 
                if isempty(start_burst); start_burst = peakT(ie)-1; end
                stop_burst = find(tdata(peakF(ie),peakT(ie):end)<mediancutoff*fmedian(peakF(ie)),1,'first');
                if isempty(stop_burst); stop_burst = length(tdata)-peakT(ie); end
                peakpower(ie,5) = ((peakT(ie)+stop_burst)-(peakT(ie)-start_burst))*1000/LFP.srate;
                end
            end
            eventnums(ic,it) = sum(peakpower(:,2));
            peakpower = peakpower(logical(peakpower(:,2)),:);
            % store
            channame = LFP.chanlocs(ic).labels; channame(strfind(channame,' ')) = [];
            if eventnums(ic,it) > 0
                eval(['trialevs.' channame '.t' num2str(it) ' = [' num2str(peakpower(:,4)') '];']);
                eval(['evfreqs.' channame '.t' num2str(it) ' = [' num2str(peakpower(:,3)') '];']);
                eval(['evlength.' channame '.t' num2str(it) ' = [' num2str(peakpower(:,5)') '];']);
            else
                eval(['trialevs.' channame '.t' num2str(it) ' = [];']);
                eval(['evfreqs.' channame '.t' num2str(it) ' = [];']);
                eval(['evlength.' channame '.t' num2str(it) ' = [];']);                
            end
            
            % baseline
            % get trial TF data (from -SSRT to event)
            tdata = squeeze(epochs(:,1:eventsample-1,it));
            % find local maxima
            [peakF,peakT] = find(imregionalmax(tdata));
            % get power for events
            peakpower = zeros(length(peakF),5); % column 1 = value, column 2 =  above threshold
            for ie = 1:length(peakF)
                peakpower(ie,1) = tdata(peakF(ie),peakT(ie));
                peakpower(ie,3) = peakF(ie)+frequencies(1)-1; % frequency of blob
                peakpower(ie,4) = peakT(ie)*1000/LFP.srate; % ms of blob
                if peakpower(ie,1) > mediancutoff*fmedian(peakF(ie)); peakpower(ie,2) = 1; end
                if peakpower(ie,1) > mediancutoff*fmedian(peakF(ie))
                start_burst = find(fliplr(tdata(peakF(ie),1:peakT(ie)))<mediancutoff*fmedian(peakF(ie)),1,'first'); 
                if isempty(start_burst); start_burst = peakT(ie)-1; end
                stop_burst = find(tdata(peakF(ie),peakT(ie):end)<mediancutoff*fmedian(peakF(ie)),1,'first');
                if isempty(stop_burst); stop_burst = length(tdata)-peakT(ie); end
                peakpower(ie,5) = ((peakT(ie)+stop_burst)-(peakT(ie)-start_burst))*1000/LFP.srate;
                end
            end
            bl_eventnums(ic,it) = sum(peakpower(:,2));
            peakpower = peakpower(logical(peakpower(:,2)),:);
            % store
            channame = LFP.chanlocs(ic).labels; channame(strfind(channame,' ')) = [];
            if eventnums(ic,it) > 0
                eval(['blevs.' channame '.t' num2str(it) ' = [' num2str(peakpower(:,4)') '];']);
                eval(['blevfreqs.' channame '.t' num2str(it) ' = [' num2str(peakpower(:,3)') '];']);
                eval(['blevlength.' channame '.t' num2str(it) ' = [' num2str(peakpower(:,5)') '];']);
            else
                eval(['blevs.' channame '.t' num2str(it) ' = [];']);
                eval(['blevfreqs.' channame '.t' num2str(it) ' = [];']);
                eval(['blevlength.' channame '.t' num2str(it) ' = [];']);                
            end
            chanlabels = {LFP.chanlocs.labels};
            
        end
        if channels_selected == 1
            if strcmpi(LFP.chanlocs(ic).labels,'rvim_1'); RVIM = eLFP; end
            if strcmpi(LFP.chanlocs(ic).labels,'lvim_1'); LVIM = eLFP; end
        end
    end
    
    % save beta burst indices (with behavioral exclusion blocks removed)
    %save(fullfile(folders.beta,['Subject' num2str(subnum) '_dorsal.mat']),'RVIM','LVIM','chanlabels','trialseq','trialevs','blevs','blevfreqs','blevlength','evfreqs','evlength','RT','rt','SSRT','accuracy','ssd','side','tnum','LM1','RM1','LVIM','RVIM');
end

%% do beta detection for all stn channels so we can parse dorsal and ventral
for is = stn % do once for each subject
    disp(['All STN channels - working on Subject ' num2str(is) '!']);
    subnum = datasets(is).subnum; % sub number for file load/save

    % clear output to prevent accumulation from prev subs
    clear trialevs blevs LFP chanlabels
    
    % load in preprocessed data and selected channels if this analysis has
    % already been run
    load(fullfile(folders.pp,['Subject' datasets(is).subnum '-LFP.mat']));
    % selected artifactual periods
    load(fullfile(folders.pp,['ManualRej' num2str(datasets(is).subnum) '.mat']),'rejpoints','rejections');

    % remove single blocks with flagged accuracy or rt issues
    if strcmpi(subnum,'104'); LFP.event(find(arrayfun(@(x) isequal(x.behav(2),4), LFP.event))) = [];
    elseif strcmpi(subnum,'105'); LFP.event(find(arrayfun(@(x) isequal(x.behav(2),3), LFP.event))) = [];
    elseif strcmpi(subnum,'109'); LFP.event(find(arrayfun(@(x) isequal(x.behav(2),2), LFP.event))) = [];
    elseif strcmpi(subnum,'110'); LFP.event(find(arrayfun(@(x) isequal(x.behav(2),1), LFP.event))) = [];
    elseif strcmpi(subnum,'113'); LFP.event(find(arrayfun(@(x) isequal(x.behav(2),4), LFP.event))) = [];
    elseif strcmpi(subnum,'129'); LFP.event(find(arrayfun(@(x) isequal(x.behav(2),2), LFP.event))) = [];
    end
    RSTN = []; LSTN = []; % preassign
    
    % Prepare to remake channels into bipolar arrays
    % find contacts that exist for each subject (some had bigger M1 strips, some had STN and not VIM)
    % We only grab the channels determined by the neurosurgeon to be
    % placed in VIM proper. All potential STN channels included.
    rstn_chans = find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'R STN'))); % R STN channels
    lstn_chans = find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'L STN'))); % L STN channels
    number_of_locations = ~isempty(rstn_chans) + ~isempty(lstn_chans);
    locations = {'rstn','lstn'}; % all possible contacts
    
    % go through locations and make bipolar data with M1 contacts available
    newchanlocs = []; % will be appended
    newdata = []; % will be appended
    for il = 1:length(locations)
        % check if location is present in subject
        loclabel = [locations{il} '_chans'];
        eval(['locchans = ' loclabel ';']);
        if ~isempty(locchans)
            % go through location channels and make data and chanlabel
            locdata = zeros(length(locchans)-1,LFP.pnts);
            locchanlocs = LFP.chanlocs(1);  % will be overwritten, adopt structure layout
            for ilc = 1:length(locchans)-1
                locdata(ilc,:) = LFP.data(locchans(ilc),:) - LFP.data(locchans(ilc+1),:);
                locchanlocs(ilc).labels = [locations{il} '_' num2str(ilc)];
            end
            % identify new channel indices
            eval([loclabel ' = [' num2str(length(newchanlocs)+1:length(newchanlocs)+length(locchanlocs)) '];']);
            % append data and chanlocs
            newchanlocs = [newchanlocs locchanlocs];
            newdata = [newdata; locdata];
        end
    end
    
    % insert bipolar arrays into main EEGLab structure
    LFP.data = newdata; LFP.chanlocs = newchanlocs; LFP.nbchan = length(LFP.chanlocs);
    
    % extract behavior from LFP trials
    events = reshape([LFP.event.behav],length(LFP.event(2).behav),length([LFP.event.behav])/length(LFP.event(2).behav))';
    [~,b] = unique(events(:,1));
    trialseq = events(b,:);
    
    % convert event types to our preferred standard
    gostims = find(strcmpi({LFP.event.type},'GoStimulus'));
    gotrials = find([LFP.event.acc] ~= 3 & [LFP.event.acc] ~= 4);
    stoptrials = find([LFP.event.acc] == 3 | [LFP.event.acc] == 4);
    % insert types
    s200 = find(strcmpi({LFP.event.type},'StopStimulus'));
    for ie = 1:length(s200); LFP.event(s200(ie)).type = 'S200'; end
    s1 = intersect(gostims,gotrials);
    for ie = 1:length(s1); LFP.event(s1(ie)).type = 'S  1'; end
    s2 = intersect(gostims,stoptrials);
    for ie = 1:length(s2); LFP.event(s2(ie)).type = 'S  2'; end
    % delete response events for this analysis (we pull this info from
    % the behavioral data when we need RT)
    LFP.event(strcmpi({LFP.event.type},'Response')) = [];
    % reject segments marked for rejection due to artifact
    LFP = pop_select(LFP,'nopoint',rejpoints);
    
    % get RT and SSRT from included trials
    behav = Basicstop_analyze(trialseq,1);
    SSRT = behav.RT.SSRTi;
    RT = behav.RT.corgo;
    ssrtsamples = round(SSRT*LFP.srate/1000);
   
    % create wavelet for time-frequency conversion
    time = -1:1/LFP.srate:1;
    % pre assign
    wavelet_conv_data = zeros(length(frequencies),LFP.pnts);
    
    % go through channels
    for ic = 1:LFP.nbchan
        
        % preassign
        tLFP = LFP;
        
        % go through frequencies
        for ifr = 1:length(frequencies)
            
            % freqs and cycles
            f = frequencies(ifr);
            s = cycles/(2*pi*f);
            % sine and gaussian
            sine_wave = exp(1i*2*pi*f.*time);
            gaussian_win = exp(-time.^2./(2*s^2));
            % normalization factor
            normalization_factor = 1 / (s * sqrt(2* pi));
            % make wavelet
            wavelet = normalization_factor .* sine_wave .* gaussian_win;
            halfwaveletsize = ceil(length(wavelet)/2); % half of the wavelet size
            
            % convolve with data
            n_conv = length(wavelet) + LFP.pnts - 1; % compute Gaussian
            % fft
            fft_w = fft(wavelet,n_conv);
            fft_e = fft(LFP.data(ic,:),n_conv);
            ift   = ifft(fft_e.*fft_w,n_conv);
            wavelet_conv_data(ifr,:) = abs(ift(halfwaveletsize:end-halfwaveletsize+1)).^2;
            
        end
        
        % insert into temporary EEGlab structure
        tLFP.data = wavelet_conv_data;
        tLFP.nbchan = 1:length(frequencies); tLFP.chanlocs = []; tLFP.icaweights = []; tLFP.icawinv = [];
        
        % epoch around our events of interest (avoiding snipped
        % segments)
        eLFP = pop_epoch(tLFP,{'S200' 'S  1' 'S  2'},window);
        epochs = eLFP.data;
        eventsample = abs(window(1)*LFP.srate); % onset of event within epoch
        
        % get trial info we want later
        accuracy = zeros(eLFP.trials,1); for ie = 1:eLFP.trials; accuracy(ie) = eLFP.epoch(ie).eventacc{1}; end
        ssd = zeros(eLFP.trials,1); for ie = 1:eLFP.trials; ssd(ie) = eLFP.epoch(ie).eventbehav{1}(4+eLFP.epoch(ie).eventbehav{1}(3)); end
        side = zeros(eLFP.trials,1); for ie = 1:eLFP.trials; side(ie) = eLFP.epoch(ie).eventbehav{1}(3); end
        tnum = zeros(eLFP.trials,1); for ie = 1:eLFP.trials; tnum(ie) = eLFP.epoch(ie).eventtnum{1}; end
        % convert go-locked stop-trial accuracy to be able to separate stop from go-locked data based on acc variable alone
        tt = {}; lastStopDone = 0;
        for ie = 1:eLFP.trials
            % if two evs at same latency (trial where SSD = 0)
            evlock = find(cell2mat(eLFP.epoch(ie).eventlatency)==0); 
            if length(evlock)>1
                if ie>lastStopDone
                    tt(ie) = eLFP.epoch(ie).eventtype(evlock(1));
                    tt(ie+1) = eLFP.epoch(ie+1).eventtype(evlock(2));
                    lastStopDone = ie+1;
                end
            else % any other time - SSD > 0 or go trial
                tt(ie) = eLFP.epoch(ie).eventtype(evlock(1)); 
            end
        end
        rt = zeros(eLFP.trials,1); for ie = 1:eLFP.trials; rt(ie) = eLFP.epoch(ie).eventrt{1}; end
        accuracy(strcmpi(tt,'S  2')) = accuracy(strcmpi(tt,'S  2')) + 1000; % now all go-locked stop trials will be accuracy+1000
        
        % get frequency medians
        fmedian = zeros(size(epochs,1),1);
        for ifr = 1:size(epochs,1)
            alldata = [reshape(squeeze(epochs(ifr,:,accuracy<1000)),size(epochs,2)*sum(accuracy<1000),1)];
            fmedian(ifr,1) = median(alldata);
        end
        
        % go through trials and pull all beta events
        if ic == 1; eventnums = zeros(LFP.nbchan,size(eLFP.data,1)); bl_eventnums = eventnums; end % preassign
        for it = 1:size(epochs,3)
            
            % POST-event
            % get trial TF data (from event to SSRT)
            tdata = squeeze(epochs(:,eventsample+1:end,it));
            % find local maxima
            [peakF,peakT] = find(imregionalmax(tdata));
            % get power for events
            peakpower = zeros(length(peakF),4); % column 1 = value, column 2 =  above threshold
            for ie = 1:length(peakF)
                peakpower(ie,1) = tdata(peakF(ie),peakT(ie));
                if peakpower(ie,1) > mediancutoff*fmedian(peakF(ie)); peakpower(ie,2) = 1; end % check cutoff
                peakpower(ie,3) = peakF(ie)+frequencies(1)-1; % frequency of blob
                peakpower(ie,4) = peakT(ie)*1000/LFP.srate; % ms of blob
            end
            eventnums(ic,it) = sum(peakpower(:,2));
            peakpower = peakpower(logical(peakpower(:,2)),:);
            % store
            channame = LFP.chanlocs(ic).labels; channame(strfind(channame,' ')) = [];
            if eventnums(ic,it) > 0
                eval(['trialevs.' channame '.t' num2str(it) ' = [' num2str(peakpower(:,4)') '];']);
            else eval(['trialevs.' channame '.t' num2str(it) ' = [];']);
            end
            
            % baseline
            % get trial TF data (from -SSRT to event)
            tdata = squeeze(epochs(:,1:eventsample-1,it));
            % find local maxima
            [peakF,peakT] = find(imregionalmax(tdata));
            % get power for events
            peakpower = zeros(length(peakF),4); % column 1 = value, column 2 =  above threshold
            for ie = 1:length(peakF)
                peakpower(ie,1) = tdata(peakF(ie),peakT(ie));
                peakpower(ie,3) = peakF(ie)+frequencies(1)-1; % frequency of blob
                peakpower(ie,4) = peakT(ie)*1000/LFP.srate; % ms of blob
                if peakpower(ie,1) > mediancutoff*fmedian(peakF(ie)); peakpower(ie,2) = 1; end
            end
            bl_eventnums(ic,it) = sum(peakpower(:,2));
            peakpower = peakpower(logical(peakpower(:,2)),:);
            % store
            channame = LFP.chanlocs(ic).labels; channame(strfind(channame,' ')) = [];
            if eventnums(ic,it) > 0
                eval(['blevs.' channame '.t' num2str(it) ' = [' num2str(peakpower(:,4)') '];']);
            else eval(['blevs.' channame '.t' num2str(it) ' = [];']);
            end
            chanlabels = {LFP.chanlocs.labels};
        end

    end
    
    % save beta burst indices (with behavioral exclusion blocks removed)
    %save(fullfile(folders.beta,['Subject' num2str(subnum) '_allstn.mat']),'chanlabels','trialseq','trialevs','blevs','RT','rt','SSRT','accuracy','ssd','side','tnum','RSTN','LSTN');
end