%% StopOR main block data import function
% Darcy  Diesburg
% This function imports raw LFP data from the StopOR project and converts
% it to the default EEGLab structure, with behavioral information and
% triggers as events. It takes the following inputs:
% is: a single value, the subject number to do
% datasets: A structure containing information about all the subjects in
% the sample. This structure is set up in StopOR_initialize and contains
% information about where raw data and behavioral data are located.
% folders: folder tree (a structure) for output files, set up in
% StopOR_initialize

function LFP = ImportRawData(is,datasets,folders)

% load subject number and ephys files
subnum = datasets(is).subnum;
infile = char(datasets(is).eeg);
load(fullfile(folders.raw,infile));

% Account for different sampling rates in some datasets
if strcmpi(subnum,'101') || strcmpi(subnum,'104') || strcmpi(subnum,'105') || strcmpi(subnum,'106')
    srate = 24000; % 24kHz
else
    srate = 2000; % 2kHz
end

% Channels in LFP data - differ for some datasets
chans_data = getchans(subnum);

% trigger channel used for TTL triggers
chans_trig = 'Inpt_RZ2_chn001';

clear LFP
for ic = 1:length(chans_data) % load each channel into the workspace
    % (this may take a little time for the bigger srate sets)
    % load data
    eval(['LFP.data(' num2str(ic) ',:) = double(' chans_data{ic,1} '.dat);']);
    % load name
    LFP.chanlocs(ic).labels = chans_data{ic,2};
end

% Add in mandatory fields to make EEGLab structure
eval(['LFP.setname = ' char(39) 'Subject_' num2str(datasets(is).subnum) char(39) ';']); % set name
eval(['LFP.filename = ' char(39) 'Subject_' num2str(datasets(is).subnum) '.set' char(39) ';']); % filename
LFP.icawinv = []; LFP.icaweights = []; LFP.icachansind = []; LFP.icasphere = []; LFP.icaact = []; % ica info requires filling - none conducted here
LFP.pnts = size(LFP.data,2); LFP.nbchan = size(LFP.data,1); % data points, number of chans
LFP.srate = srate; % sampling rate
LFP.trials = 1; % make one long trial for now
LFP.xmin = 0; LFP.xmax = LFP.pnts/LFP.srate; LFP.epoch = []; % no epoching for now
LFP.comments = []; LFP.filepath = fullfile(folders.pp);  % filepath
LFP.event = []; LFP.urevent = []; % no events added yet

% load behavioral data
filename = char(datasets(is).behav);
load(fullfile(folders.behav,filename));
% trial data column indices
trialseq_id = Basicstop_columns;

% downsample trigger channel data if 118 (trig chan = 24KHz, rec chan = 2k)
eval(['trchan = double(' chans_trig '.dat);']);
if strcmpi(subnum,'118'); trchan = resample(trchan,2,24); end

% check the input channel recording - find latency of upflanks where
% triggers occurred
bigsamples = find(trchan>1); triggers = bigsamples(logical([diff(bigsamples)>1; 1]))-3;

% Delete any accidental extra triggers
if strcmpi(subnum,'101') == 1; triggers(1) = []; end % participant 101 had an accidental extra trigger at beginning
if strcmpi(subnum,'104')== 1; triggers(257:end) = []; end % extra block of go-only that wasn't used

% there are triggers sent for every go and stop signal - check number
% there should be
shouldbetrig = length(trialseq) + length(trialseq)*(1/3);
if shouldbetrig ~= size(triggers,1); error('Triggers and trials mismatch'); end

% correct tracking algorithm error - SSDs can't possibly be < 0ms
trialseq(trialseq(:,trialseq_id.lssd) < 0,trialseq_id.lssd) = 0; 
trialseq(trialseq(:,trialseq_id.rssd) < 0,trialseq_id.rssd) = 0; 

% preallocate
triggerclass = zeros(length(triggers),1); % 0's are go's, 1's are stops
triggertrial = zeros(length(triggers),1);
cnt = 0;
% label go and stop triggers in the data by referencing behavioral info
for it = 1:length(trialseq)
    if trialseq(it,trialseq_id.stop) == 0 % if a go only trial, 1 trigger
        cnt = cnt + 1;
        triggerclass(cnt) = 0;
        triggertrial(cnt) = it;
    elseif trialseq(it,trialseq_id.stop) == 1 % if a SS trial, 2 triggers
        cnt = cnt + 1;
        triggerclass(cnt) = 0;
        triggertrial(cnt) = it;
        cnt = cnt + 1;
        triggerclass(cnt) = 1;
        triggertrial(cnt) = it;
    end
end

% Add events for triggers to LFP data structure
rcnt = 0; clear stimuli; clear responses;
for it = 1:length(triggers)
    if triggerclass(it) == 0; stimuli(it).type = 'GoStimulus';
    elseif triggerclass(it) == 1; stimuli(it).type = 'StopStimulus'; end
    stimuli(it).duration = 1;
    stimuli(it).latency = triggers(it);
    stimuli(it).tnum = triggertrial(it);
    stimuli(it).side = trialseq(triggertrial(it),trialseq_id.dir);
    stimuli(it).resp_side = trialseq(triggertrial(it),trialseq_id.resp);
    stimuli(it).acc = trialseq(triggertrial(it),trialseq_id.acc);
    stimuli(it).rt = trialseq(triggertrial(it),trialseq_id.rt);
    stimuli(it).behav = trialseq(triggertrial(it),:);
    
    % add responses with button press as events
    if trialseq(triggertrial(it),trialseq_id.rt) > 0 && strcmpi(stimuli(it).type,'GoStimulus')
        rcnt = rcnt + 1;
        responses(rcnt) = stimuli(it);
        responses(rcnt).type = 'Response';
        responses(rcnt).latency = triggers(it) + round(trialseq(triggertrial(it),trialseq_id.rt))*srate/1000;
        responses(rcnt).tnum = triggertrial(it);
        responses(rcnt).rt = trialseq(triggertrial(it),trialseq_id.rt);
        responses(rcnt).behav = trialseq(triggertrial(it),:);
    end
end

% concatenate stimulus and response events
events = [stimuli responses];
[~,b] = sort([events.latency]); LFP.event = events(b);

% fix stop-signal event timing in structure in several sets - trigger sent at time not
% SSD
stopsignals = find(strcmpi({LFP.event.type},'StopStimulus'));
for ie = 1:length(stopsignals)
    if LFP.event(stopsignals(ie)).side == 1
        LFP.event(stopsignals(ie)).latency = LFP.event(stopsignals(ie)-1).latency + (LFP.event(stopsignals(ie)).behav(5)*srate/1000);
    elseif LFP.event(stopsignals(ie)).side == 2
        LFP.event(stopsignals(ie)).latency = LFP.event(stopsignals(ie)-1).latency + (LFP.event(stopsignals(ie)).behav(6)*srate/1000);
    end
end

end