%% BARPLOT.m > Plots a scatter-bar plot
% JRW 2017, jan-wessel@uiowa.edu
% Needs: Structure with a field for every sample / dataset. Fields needs to
% be a vector
% Optional: paired option (second argument = 'paired'). Will draw lines
% between each subjects data. Assumes that 1 is paired w 2, 3 with 4, and
% so forth. Obviously needs equally sized vectors for these subjects

function barplot(data,paired)

if nargin < 2; paired = ''; end

% settings
hold;
mc = [.7 .7 .7]; % marker color
lbuff = .1; % width for nanmean line
lw = 3; % thickness for nanmean line
lc = 'r'; % color of nanmean line
slc = [1 .5 .5]; % color of std line
slw = 1; % thickness of std line
plc = mc; % color of paired subjects line
plw = .5; % thickness of paired subjects line

% get fieldnames
fields = fieldnames(data);

% preassign empty
adat = []; % all data
lb = {}; % labels

% paired lines first
if strcmpi(paired,'paired')
    
    % go through pairs
    for is = 1:2:length(fields)
        
        % get data
        eval(['sdat1 = data.' fields{is} ';']);
        eval(['sdat2 = data.' fields{is+1} ';']);
        
        % random x-dim scatter in case of overlapping sample points
        rs = repmat(-lbuff/2 + (lbuff/2+lbuff/2).*rand(length(sdat1),1),1); 
        eval(['RS.' fields{is} ' = rs;']); % save for later
        eval(['RS.' fields{is+1} ' = rs;']); % save for later
        
        % draw line
        for id = 1:size(sdat1,1);
            line([is+rs(id,1) is+1+rs(id,1)],[sdat1(id) sdat2(id)],'LineWidth',plw,'Color',plc);
        end
        
    end
    
end
    

% go through samples
for is = 1:length(fields)
    
    % get
    eval(['cdat = data.' fields{is} ';']);
    
    % get rs back from above or make new
    if strcmpi(paired,'paired')
        eval(['rs = RS.' fields{is} ';']);
    else rs = repmat(-lbuff/2 + (lbuff/2+lbuff/2).*rand(length(cdat),1),1);  % make anew
    end
    
    % plot
    
    scatter(repmat(is,length(cdat),1)+rs,cdat,'MarkerFaceColor',mc,'MarkerEdgeColor',mc);
    
    % attach
    adat = [adat; cdat];
    lb = [lb fields(is)];
    
    % desc: sem line
    SEM = nanstd(cdat)./sqrt(length(cdat));
    line([is is],[nanmean(cdat)-SEM nanmean(cdat)+SEM],'LineWidth',slw,'Color',slc);
    % bottom and top
    line([is-lbuff/5 is+lbuff/5],[nanmean(cdat)-SEM nanmean(cdat)-SEM],'LineWidth',slw,'Color',slc);
    line([is-lbuff/5 is+lbuff/5],[nanmean(cdat)+SEM nanmean(cdat)+SEM],'LineWidth',slw,'Color',slc);
    
    % desc: nanmean line
    line([is-lbuff is+lbuff],[nanmean(cdat) nanmean(cdat)],'LineWidth',lw,'Color',lc);
    
end

% limits
xlim = [.5 length(fields)+.5];
ylim = [min(adat)-nanmean(adat)/10 max(adat)+nanmean(adat)/10];

% set
set(gca,'Xlim',xlim,'Ylim',ylim,'Xtick',1:length(fields),'Xticklabel',lb);