%% Check differences in SSD-SSRT burst counts for left vs. right BG
% preassign
contra_StoptoSSRT = zeros(length(datasets),6); ipsi_StoptoSSRT = contra_StoptoSSRT;
dorsal_contra_StoptoSSRT = zeros(length(datasets),6); dorsal_ipsi_StoptoSSRT = zeros(length(datasets),6);
tha_to_do = tha(2:end);

for is = 1:length(datasets) % for each subject
     clear trials dorsal_trials;
    % load
    subnum = datasets(is).subnum;
    load(fullfile(folders.beta,['Subject' num2str(subnum) '.mat']));
    
    % identify channels
    % assign VIM [THIS DEFAULTS TO STN FOR 104 (which has both VIM and STN)]
    if sum(~cellfun(@isempty,strfind(chanlabels,'rvim'))) == 1
        rbgchan = ~cellfun(@isempty,strfind(chanlabels,'rvim'));
        lbgchan = ~cellfun(@isempty,strfind(chanlabels,'lvim'));
        eval(['trialsbgl = trialevs.' chanlabels{rbgchan} ';']);
        eval(['trialsbgr = trialevs.' chanlabels{lbgchan} ';']);
    end
    % assign STN [THIS DEFAULTS TO STN FOR 104 (which has both VIM and STN)]
    if sum(~cellfun(@isempty,strfind(chanlabels,'rstn'))) == 1
        rbgchan = ~cellfun(@isempty,strfind(chanlabels,'rstn'));
        lbgchan = ~cellfun(@isempty,strfind(chanlabels,'lstn'));
        eval(['trialsbgl = trialevs.' chanlabels{rbgchan} ';']);
        eval(['trialsbgr = trialevs.' chanlabels{lbgchan} ';']);
    end

    if ~isempty(intersect(is,tha))
        load(fullfile(folders.beta,['Subject' num2str(subnum) '_dorsal.mat']));
    
        if sum(~cellfun(@isempty,strfind(chanlabels,'lvim'))) == 1
            if is~= 2; rbgchan = ~cellfun(@isempty,strfind(chanlabels,'rvim')); end
            lbgchan = ~cellfun(@isempty,strfind(chanlabels,'lvim'));
            if is~= 2; eval(['dorsal_trialsbgl = trialevs.' chanlabels{rbgchan} ';']); end
            eval(['dorsal_trialsbgr = trialevs.' chanlabels{lbgchan} ';']);
        end

    end
    
    % preassign
    lcontra_pre_SSRT = zeros(length(fieldnames(trialsbgl)),1);
    ldorsal_contra_pre_SSRT = lcontra_pre_SSRT;
    lipsi_pre_SSRT = lcontra_pre_SSRT;
    ldorsal_ipsi_pre_SSRT = lcontra_pre_SSRT;
    
    % go through left bg trials
    for it = 1:length(fieldnames(trialsbgl))

        % get events
        eval(['evs = trialsbgl.t' num2str(it) ';']);
        evs(evs<=2) = [];
        if ~isempty(intersect(is,tha))
            eval(['devs = dorsal_trialsbgl.t' num2str(it) ';']);
            devs(devs<=2) = [];
        end
        % if there are events
        if ~isempty(evs)
            
            % get pre-SSRT data (timewindow from event to SSRT)
            % if a go trial, grab ssd to SSRT
            if side(it) == 2
                if accuracy(it) == 1 
                    lcontra_pre_SSRT(it) = sum(evs>ssd(it) & evs<ssd(it)+SSRT);
                else
                    lcontra_pre_SSRT(it) = sum(evs<SSRT);
                end
            else
                if accuracy(it) == 1 
                    lipsi_pre_SSRT(it) = sum(evs>ssd(it) & evs<ssd(it)+SSRT);
                else
                    lipsi_pre_SSRT(it) = sum(evs<SSRT);
                end
            end
            
        end
        % if there are events in dorsal thal
        if ~isempty(intersect(is,tha_to_do))
            if ~isempty(devs)
                
                % get pre-SSRT data (timewindow from event to SSRT)
                % if a go trial, grab ssd to SSRT
                if side(it) == 2
                    if accuracy(it) == 1
                        ldorsal_contra_pre_SSRT(it) = sum(devs>ssd(it) & devs<ssd(it)+SSRT);
                    else
                        ldorsal_contra_pre_SSRT(it) = sum(devs<SSRT);
                    end
                else
                    if accuracy(it) == 1
                        ldorsal_ipsi_pre_SSRT(it) = sum(devs>ssd(it) & devs<ssd(it)+SSRT);
                    else
                        ldorsal_ipsi_pre_SSRT(it) = sum(devs<SSRT);
                    end
                end
                
            end
        end
    end
    
    % preassign
    rcontra_pre_SSRT = zeros(length(fieldnames(trialsbgr)),1);
    rdorsal_contra_pre_SSRT = rcontra_pre_SSRT;
    ripsi_pre_SSRT = rcontra_pre_SSRT;
    rdorsal_ipsi_pre_SSRT = rcontra_pre_SSRT;
    
    % go through right bg trials
    for it = 1:length(fieldnames(trialsbgr))

        % get events
        eval(['evs = trialsbgr.t' num2str(it) ';']);
        evs(evs<=2) = [];
        if ~isempty(intersect(is,tha))
            eval(['devs = dorsal_trialsbgr.t' num2str(it) ';']);
            devs(devs<=2) = [];
        end
        % if there are events
        if ~isempty(evs)
            
            % get pre-SSRT data (timewindow from event to SSRT)
            % if a go trial, grab ssd to SSRT
            if side(it) == 1
                if accuracy(it) == 1 
                    rcontra_pre_SSRT(it) = sum(evs>ssd(it) & evs<ssd(it)+SSRT);
                else
                    rcontra_pre_SSRT(it) = sum(evs<SSRT);
                end
            else
                if accuracy(it) == 1 
                    ripsi_pre_SSRT(it) = sum(evs>ssd(it) & evs<ssd(it)+SSRT);
                else
                    ripsi_pre_SSRT(it) = sum(evs<SSRT);
                end
            end
            
        end
        % if there are events in dorsal thal
        if ~isempty(intersect(is,tha_to_do))
            if ~isempty(devs)
                
                % get pre-SSRT data (timewindow from event to SSRT)
                % if a go trial, grab ssd to SSRT
                if side(it) == 1
                    if accuracy(it) == 1
                        rdorsal_contra_pre_SSRT(it) = sum(devs>ssd(it) & devs<ssd(it)+SSRT);
                    else
                        rdorsal_contra_pre_SSRT(it) = sum(devs<SSRT);
                    end
                else
                    if accuracy(it) == 1
                        rdorsal_ipsi_pre_SSRT(it) = sum(devs>ssd(it) & devs<ssd(it)+SSRT);
                    else
                        rdorsal_ipsi_pre_SSRT(it) = sum(devs<SSRT);
                    end
                end
                
            end
        end
    end
    
    % sort by accuracy
    contra_StoptoSSRT(is,1) = mean([lcontra_pre_SSRT(accuracy==3,1); rcontra_pre_SSRT(accuracy==3,1)]);
    contra_StoptoSSRT(is,2) = mean([lcontra_pre_SSRT(accuracy==4,1); rcontra_pre_SSRT(accuracy==4,1)]);
    if ~isempty(intersect(is,tha_to_do))
        dorsal_contra_StoptoSSRT(is,1) = mean([ldorsal_contra_pre_SSRT(accuracy==3,1); rdorsal_contra_pre_SSRT(accuracy==3,1)]);
        dorsal_contra_StoptoSSRT(is,2) = mean([ldorsal_contra_pre_SSRT(accuracy==4,1); rdorsal_contra_pre_SSRT(accuracy==4,1)]);
    end
    ipsi_StoptoSSRT(is,1) = mean([lipsi_pre_SSRT(accuracy==3,1); ripsi_pre_SSRT(accuracy==3,1)]);
    ipsi_StoptoSSRT(is,2) = mean([lipsi_pre_SSRT(accuracy==4,1); ripsi_pre_SSRT(accuracy==4,1)]);
    if ~isempty(intersect(is,tha_to_do))
        dorsal_ipsi_StoptoSSRT(is,1) = mean([ldorsal_ipsi_pre_SSRT(accuracy==3,1); rdorsal_ipsi_pre_SSRT(accuracy==3,1)]);
        dorsal_ipsi_StoptoSSRT(is,2) = mean([ldorsal_ipsi_pre_SSRT(accuracy==4,1); rdorsal_ipsi_pre_SSRT(accuracy==4,1)]);
    end
    stops = find(accuracy == 3 | accuracy == 4);
    for ie = 1:length(stops) % get count for the matched go trial
        match = find(ssd-ssd(stops(ie)) == 0 & accuracy == 1); nextgo = match(find(match>stops(ie),1,'first'));
        % if fails, flip and find most recent before
        if isempty(nextgo); match = find(ssd-ssd(stops(ie)) == 0 & accuracy == 1); nextgo = match(find(match<stops(ie),1,'last')); end
        % if failed, pick first go trial w/ SSD w/in 50ms
        if isempty(nextgo); nextgo = find(ssd-ssd(stops(ie)) == 50 | ssd-ssd(stops(ie)) == -50 & accuracy == 1,1,'first'); end
        contra_matched_gos(ie) = mean([lcontra_pre_SSRT(nextgo); rcontra_pre_SSRT(nextgo)]);
        ipsi_matched_gos(ie) = mean([lipsi_pre_SSRT(nextgo); ripsi_pre_SSRT(nextgo)]);
        if ~isempty(intersect(is,tha_to_do))
            dorsal_contra_matched_gos(ie) = mean([ldorsal_contra_pre_SSRT(nextgo); rdorsal_contra_pre_SSRT(nextgo)]);
            dorsal_ipsi_matched_gos(ie) = mean([ldorsal_ipsi_pre_SSRT(nextgo); rdorsal_ipsi_pre_SSRT(nextgo)]);
        end
    end    
    contra_StoptoSSRT(is,3) = mean(contra_matched_gos); ipsi_StoptoSSRT(is,3) = mean(ipsi_matched_gos);
    contra_StoptoSSRT(is,4) = SSRT; ipsi_StoptoSSRT(is,4) = SSRT;
    if ~isempty(intersect(is,tha_to_do))
        dorsal_contra_StoptoSSRT(is,3) = mean(dorsal_contra_matched_gos);
        dorsal_ipsi_StoptoSSRT(is,3) = mean(dorsal_ipsi_matched_gos);
        dorsal_contra_StoptoSSRT(is,4) = SSRT; dorsal_ipsi_StoptoSSRT(is,4) = SSRT;
    end
end 

% figure: STN
figure('Color','w'); 
subplot(3,1,1);
clear s; 
s.contrass = contra_StoptoSSRT(stn,1); s.contrafs = contra_StoptoSSRT(stn,2); s.contrago = contra_StoptoSSRT(stn,3); 
s.ipsiss = ipsi_StoptoSSRT(stn,1); s.ipsifs = ipsi_StoptoSSRT(stn,2); s.ipsigo = ipsi_StoptoSSRT(stn,3); barplot(s);
xlabel('Trialtype'); ylabel('Beta bursts before SSRT'); title('STN');
% color lines
c = get(gca,'Children'); for ic = 1:length(c); if strcmpi(class(c(ic)),'matlab.graphics.primitive.Line') && c(ic).Color(1) == .7; set(c(ic),'Color',[1 .5 0]); end; end
c = get(gca,'Children'); for ic = 1:length(c); if strcmpi(class(c(ic)),'matlab.graphics.chart.primitive.Scatter') && c(ic).MarkerEdgeColor(1) == .7; set(c(ic),'MarkerEdgeColor',[1 .5 0]); end; end
set(gca,'Ylim',[0 1.5]);

% figure: VIM
subplot(3,1,2);
clear s; 
s.contrass = contra_StoptoSSRT(tha_to_do,1); s.contrafs = contra_StoptoSSRT(tha_to_do,2); s.contrago = contra_StoptoSSRT(tha_to_do,3);
s.ipsiss = ipsi_StoptoSSRT(tha_to_do,1); s.ipsifs = ipsi_StoptoSSRT(tha_to_do,2); s.ipsigo = ipsi_StoptoSSRT(tha_to_do,3); barplot(s);
xlabel('Trialtype'); ylabel('Beta bursts before SSRT'); title('VIM');
% color lines
c = get(gca,'Children'); for ic = 1:length(c); if strcmpi(class(c(ic)),'matlab.graphics.primitive.Line') && c(ic).Color(1) == .7; set(c(ic),'Color',[0 .3 0]); end; end
c = get(gca,'Children'); for ic = 1:length(c); if strcmpi(class(c(ic)),'matlab.graphics.chart.primitive.Scatter') && c(ic).MarkerEdgeColor(1) == .7; set(c(ic),'MarkerEdgeColor',[0 .3 0]); end; end
set(gca,'Ylim',[0 1.5]);

% figure: dorsal thalamus
subplot(3,1,3);
clear s; 
s.contrass = dorsal_contra_StoptoSSRT(tha_to_do,1); s.contrafs = dorsal_contra_StoptoSSRT(tha_to_do,2); s.contrago = dorsal_contra_StoptoSSRT(tha_to_do,3);
s.ipsiss = dorsal_ipsi_StoptoSSRT(tha_to_do,1); s.ipsifs = dorsal_ipsi_StoptoSSRT(tha_to_do,2); s.ipsigo = dorsal_ipsi_StoptoSSRT(tha_to_do,3); barplot(s);
xlabel('Trialtype'); ylabel('Beta bursts before SSRT'); title('Dorsal thalamus');
% color lines
c = get(gca,'Children'); for ic = 1:length(c); if strcmpi(class(c(ic)),'matlab.graphics.primitive.Line') && c(ic).Color(1) == .7; set(c(ic),'Color',[0 .3 0]); end; end
c = get(gca,'Children'); for ic = 1:length(c); if strcmpi(class(c(ic)),'matlab.graphics.chart.primitive.Scatter') && c(ic).MarkerEdgeColor(1) == .7; set(c(ic),'MarkerEdgeColor',[0 .3 0]); end; end
set(gca,'Ylim',[0 1.5]);

% paired tests for hemi differences
[~,STN_gop] = ttest(contra_StoptoSSRT(stn,3),ipsi_StoptoSSRT(stn,3));
[~,VIM_gop] = ttest(contra_StoptoSSRT(tha_to_do,3),ipsi_StoptoSSRT(tha_to_do,3));
[~,VOP_gop] = ttest(dorsal_contra_StoptoSSRT(tha_to_do,3),dorsal_ipsi_StoptoSSRT(tha_to_do,3));
[~,STN_failp] = ttest(contra_StoptoSSRT(stn,2),ipsi_StoptoSSRT(stn,2));
[~,VIM_failp] = ttest(contra_StoptoSSRT(tha_to_do,2),ipsi_StoptoSSRT(tha_to_do,2));
[~,VOP_failp] = ttest(dorsal_contra_StoptoSSRT(tha_to_do,2),dorsal_ipsi_StoptoSSRT(tha_to_do,2));
[~,STN_succp] = ttest(contra_StoptoSSRT(stn,1),ipsi_StoptoSSRT(stn,1));
[~,VIM_succp] = ttest(contra_StoptoSSRT(tha_to_do,1),ipsi_StoptoSSRT(tha_to_do,1));
[~,VOP_succp] = ttest(dorsal_contra_StoptoSSRT(tha_to_do,1),dorsal_ipsi_StoptoSSRT(tha_to_do,1));

if STN_gop < .05
    disp(['STN sample: Sig differences between hemispheres for go: p = ' num2str(STN_gop)]);
end
if STN_failp < .05
    disp(['STN sample: Sig differences between hemispheres for FS: p = ' num2str(STN_failp)]);
end
if STN_succp < .05
    disp(['STN sample: Sig differences between hemispheres for SS: p = ' num2str(STN_succp)]);
end
if VIM_gop < .05
    disp(['VIM sample: Sig differences between hemispheres for go: p = ' num2str(VIM_gop)]);
end
if VIM_failp < .05
    disp(['VIM sample: Sig differences between hemispheres for FS: p = ' num2str(VIM_failp)]);
end
if VIM_succp < .05
    disp(['VIM sample: Sig differences between hemispheres for SS: p = ' num2str(VIM_succp)]);
end
if VOP_succp < .05
    disp(['VOP sample: Sig differences between hemispheres for SS: p = ' num2str(VOP_succp)]);
end
if VOP_gop < .05
    disp(['Dorsal thalamus: Sig differences between hemispheres for go: p = ' num2str(VOP_gop)]);
end
if VOP_failp < .05
    disp(['Dorsal thalamus: Sig differences between hemispheres for FS: p = ' num2str(VOP_failp)]);
end
%% Check differences in burst rate for left vs right BG
nbins = 0:100:900; %set bins
% preallocations
CONTRA_FAILSTOP_main = NaN(length(datasets),length(nbins)-1); 
CONTRA_SUCCSTOP_main = CONTRA_FAILSTOP_main;
CONTRA_MATCHGO_main = CONTRA_FAILSTOP_main;
CONTRA_GO_bg_main = CONTRA_FAILSTOP_main;
IPSI_FAILSTOP_main = CONTRA_FAILSTOP_main;
IPSI_SUCCSTOP_main = CONTRA_FAILSTOP_main;
IPSI_MATCHGO_main = CONTRA_FAILSTOP_main;
IPSI_GO_bg_main = CONTRA_FAILSTOP_main;  
D_CONTRA_FAILSTOP_main = CONTRA_FAILSTOP_main;
D_CONTRA_SUCCSTOP_main = CONTRA_FAILSTOP_main;
D_CONTRA_MATCHGO_main = CONTRA_FAILSTOP_main;
D_CONTRA_GO_bg_main = CONTRA_FAILSTOP_main;
D_IPSI_FAILSTOP_main = CONTRA_FAILSTOP_main;
D_IPSI_SUCCSTOP_main = CONTRA_FAILSTOP_main;
D_IPSI_MATCHGO_main = CONTRA_FAILSTOP_main;
D_IPSI_GO_bg_main = CONTRA_FAILSTOP_main;  

for is = 1:length(datasets) % for each subject
    
    subnum = datasets(is).subnum; % subject number
    clear trialevs* trials* dorsal*
    
    % load beta event indices
    load(fullfile(folders.beta,['Subject' num2str(subnum) '.mat']));
    
    % assign channels (only main block has depth electrodes)
    % assign VIM [THIS DEFAULT TO STN FOR 104 (which has both VIM and STN)]
    if sum(~cellfun(@isempty,strfind(chanlabels,'rvim'))) == 1
        rbgchan = ~cellfun(@isempty,strfind(chanlabels,'rvim'));
        lbgchan = ~cellfun(@isempty,strfind(chanlabels,'lvim'));
        eval(['trialsbgl = trialevs.' chanlabels{lbgchan} ';']);
        eval(['trialsbgr = trialevs.' chanlabels{rbgchan} ';']);
    end
    % assign STN [THIS DEFAULTS TO STN FOR 104 (which has both VIM and STN)]
    if sum(~cellfun(@isempty,strfind(chanlabels,'rstn'))) == 1
        rbgchan = ~cellfun(@isempty,strfind(chanlabels,'rstn'));
        lbgchan = ~cellfun(@isempty,strfind(chanlabels,'lstn'));
        eval(['trialsbgl = trialevs.' chanlabels{lbgchan} ';']);
        eval(['trialsbgr = trialevs.' chanlabels{rbgchan} ';']);
    end
    % combine left and right bg data
    trialnumbers = fieldnames(trialsbgl); 
    
    if ~isempty(intersect(is,tha)) % if a thalamus case, load dorsal thal 
        % load dorsal thalamus bursts
        load(fullfile(folders.beta,['Subject' num2str(subnum) '_dorsal.mat']));
        if sum(~cellfun(@isempty,strfind(chanlabels,'lvim'))) == 1
            if is ~= 2; lbgchan = ~cellfun(@isempty,strfind(chanlabels,'lvim'));end
            rbgchan = ~cellfun(@isempty,strfind(chanlabels,'rvim'));
            eval(['dorsal_trialsbgl = trialevs.' chanlabels{lbgchan} ';']);
            if is ~= 2; eval(['dorsal_trialsbgr = trialevs.' chanlabels{rbgchan} ';']); end
        end
    end
    
    % do right bg first
    
    % presets
    r_bg_gol = []; r_bg_gor = []; gr = 0; gl = 0;
    r_bg_ssl = []; r_bg_ssr = []; ssr = 0; ssl = 0;
    r_bg_fsl = []; r_bg_fsr = []; fsr = 0; fsl = 0;
    r_bg_gossl = []; r_bg_gossr = []; gssr = 0; gssl = 0;
    r_bg_gofsl = []; r_bg_gofsr = []; gfsr = 0; gfsl = 0;
    r_matchl = []; r_matchr = []; ml = 0; mr = 0;
    
    for it = 1:length(fieldnames(trialsbgr)) % for each trial
        nextgo = []; match_evs = []; match = [];
        
        % if a stop trial, identify a go trial w/ similar or same
        % SSD
        if accuracy(it) == 3 || accuracy(it) == 4
            % try to pick matched go with same SSD soon after this
            % trial
            match = find(ssd-ssd(it) == 0 & accuracy == 1); nextgo = match(find(match>it,1,'first'));
            % if failed, pick first go trial w/ same SSD in exp
            if isempty(nextgo); nextgo = find(ssd-ssd(it) == 0 & accuracy == 1,1,'first'); end
            % if failed, pick first go trial w/ SSD w/in 50ms
            if isempty(nextgo); nextgo = find(ssd-ssd(it) == 50 | ssd-ssd(it) == -50 & accuracy == 1,1,'first'); end
            eval(['match_evs = trialsbgr.t' num2str(nextgo) ';']);
        end
        
        % get events from that trial
        eval(['evs = trialsbgr.t' num2str(it) ';']);
        evs(evs<=2) = [];
        
        % if there's an event during this trial
        if ~isempty(evs)
            % preallocate
            trial = zeros(size(nbins));
            r_match_trial = trial;
            
            for ie = 1:length(evs) % for each beta event
                
                % count trial in bin it belongs to
                upperbound = find(evs(ie)<nbins,1,'first');
                trial(upperbound) = trial(upperbound) + 1;
                
            end
            
            % store event counts for this trial according to
            % accuracy and side of response to be made
            if side(it) == 1 && accuracy(it) == 4
                fsl = fsl + 1;
                r_bg_fsl(fsl,:) = trial;
            elseif side(it) == 2 && accuracy(it) == 4
                fsr = fsr + 1;
                r_bg_fsr(fsr,:) = trial;
            end
            if side(it) == 1 && accuracy(it) == 3
                ssl = ssl + 1;
                r_bg_ssl(ssl,:) = trial;
            elseif side(it) == 2 && accuracy(it) == 3
                ssr = ssr + 1;
                r_bg_ssr(ssr,:) = trial;
            end
            if side(it) == 1 && accuracy(it) == 1
                gl = gl + 1;
                r_bg_gol(gl,:) = trial;
            elseif side(it) == 2 && accuracy(it) == 1
                gr = gr + 1;
                r_bg_gor(gr,:) = trial;
            end
        end
        
        % if there are events during a matched go trial
        match_evs(match_evs<=2) = [];
        if ~isempty(match_evs)
            for ie = 1:length(match_evs) % count those events in their bin (accounting for SSD)
                upperbound = find(match_evs(ie)-ssd(nextgo)<nbins & match_evs(ie)-ssd(nextgo)>0,1,'first');
                r_match_trial(upperbound) = r_match_trial(upperbound) + 1;
            end
            % sort according to accuracy and side
            if side(nextgo) == 1 && accuracy(nextgo) == 1
                ml = ml + 1;
                r_matchl(ml,:) = r_match_trial;
            elseif side(nextgo) == 2 && accuracy(nextgo) == 1
                mr = mr + 1;
                r_matchr(mr,:) = r_match_trial;
            end
        end
    end
    
    % left bg
    % presets
    l_bg_gol = []; l_bg_gor = []; gr = 0; gl = 0;
    l_bg_ssl = []; l_bg_ssr = []; ssr = 0; ssl = 0;
    l_bg_fsl = []; l_bg_fsr = []; fsr = 0; fsl = 0;
    l_bg_gossl = []; l_bg_gossr = []; gssr = 0; gssl = 0;
    l_bg_gofsl = []; l_bg_gofsr = []; gfsr = 0; gfsl = 0;
    l_matchl = []; l_matchr = []; ml = 0; mr = 0;
    
    for it = 1:length(fieldnames(trialsbgl)) % for each trial
        nextgo = []; match_evs = []; match = [];
        
        % if a stop trial, identify a go trial w/ similar or same
        % SSD
        if accuracy(it) == 3 || accuracy(it) == 4
            % try to pick matched go with same SSD soon after this
            % trial
            match = find(ssd-ssd(it) == 0 & accuracy == 1); nextgo = match(find(match>it,1,'first'));
            % if failed, pick first go trial w/ same SSD in exp
            if isempty(nextgo); nextgo = find(ssd-ssd(it) == 0 & accuracy == 1,1,'first'); end
            % if failed, pick first go trial w/ SSD w/in 50ms
            if isempty(nextgo); nextgo = find(ssd-ssd(it) == 50 | ssd-ssd(it) == -50 & accuracy == 1,1,'first'); end
            eval(['match_evs = trialsbgl.t' num2str(nextgo) ';']);
        end
        
        % get events from that trial
        eval(['evs = trialsbgl.t' num2str(it) ';']);
        evs(evs<=2) = [];
        
        % if there's an event during this trial
        if ~isempty(evs)
            % preallocate
            trial = zeros(size(nbins));
            l_match_trial = trial;
            
            for ie = 1:length(evs) % for each beta event
                
                % count trial in bin it belongs to
                upperbound = find(evs(ie)<nbins,1,'first');
                trial(upperbound) = trial(upperbound) + 1;
                
            end
            
            % store event counts for this trial according to
            % accuracy and side of response to be made
            if side(it) == 1 && accuracy(it) == 4
                fsl = fsl + 1;
                l_bg_fsl(fsl,:) = trial;
            elseif side(it) == 2 && accuracy(it) == 4
                fsr = fsr + 1;
                l_bg_fsr(fsr,:) = trial;
            end
            if side(it) == 1 && accuracy(it) == 3
                ssl = ssl + 1;
                l_bg_ssl(ssl,:) = trial;
            elseif side(it) == 2 && accuracy(it) == 3
                ssr = ssr + 1;
                l_bg_ssr(ssr,:) = trial;
            end
            if side(it) == 1 && accuracy(it) == 1
                gl = gl + 1;
                l_bg_gol(gl,:) = trial;
            elseif side(it) == 2 && accuracy(it) == 1
                gr = gr + 1;
                l_bg_gor(gr,:) = trial;
            end
        end
        
        % if there are events during a matched go trial
        match_evs(match_evs<=2) = [];
        if ~isempty(match_evs)
            for ie = 1:length(match_evs) % count those events in their bin (accounting for SSD)
                upperbound = find(match_evs(ie)-ssd(nextgo)<nbins & match_evs(ie)-ssd(nextgo)>0,1,'first');
                l_match_trial(upperbound) = l_match_trial(upperbound) + 1;
            end
            % sort according to accuracy and side
            if side(nextgo) == 1 && accuracy(nextgo) == 1
                ml = ml + 1;
                l_matchl(ml,:) = l_match_trial;
            elseif side(nextgo) == 2 && accuracy(nextgo) == 1
                mr = mr + 1;
                l_matchr(mr,:) = l_match_trial;
            end
        end
    end
    
    % if a thalamus DBS case, also do dorsal thalamus
    if ~isempty(intersect(is,tha))
        
        % left side first
        
        % presets for binned counts of bursts per trial type and trial type
        % counters
        d_l_bg_gol = []; d_l_bg_gor = []; dlgr = 0; dlgl = 0;
        d_l_bg_ssl = []; d_l_bg_ssr = []; dlssr = 0; dlssl = 0;
        d_l_bg_fsl = []; d_l_bg_fsr = []; dlfsr = 0; dlfsl = 0;
        d_l_bg_gossl = []; d_l_bg_gossr = []; dlgssr = 0; dlgssl = 0;
        d_l_bg_gofsl = []; d_l_bg_gofsr = []; dlgfsr = 0; dlgfsl = 0;
        d_l_matchl = []; d_l_matchr = []; dlml = 0; dlmr = 0; 
        
        for it = 1:length(fieldnames(dorsal_trialsbgl)) % for each trial
            % need to be cleared so we don't use last trial info
            nextgo = []; match_evs = []; match = []; evs = []; bevs = [];
            
            % if a stop trial, identify a go trial w/ similar or same
            % SSD
            if accuracy(it) == 3 || accuracy(it) == 4
                % try to pick matched go with same SSD soon after this
                % trial
                match = find(ssd-ssd(it) == 0 & accuracy == 1); nextgo = match(find(match>it,1,'first'));
                % if failed, pick first go trial w/ same SSD in exp
                if isempty(nextgo); nextgo = find(ssd-ssd(it) == 0 & accuracy == 1,1,'first'); end
                % if failed, pick first go trial w/ SSD w/in 50ms
                if isempty(nextgo); nextgo = find(ssd-ssd(it) == 50 | ssd-ssd(it) == -50 & accuracy == 1,1,'first'); end
                eval(['match_evs = dorsal_trialsbgl.t' num2str(nextgo) ';']);
            end
            
            % get events from that trial
            eval(['evs = dorsal_trialsbgl.t' num2str(it) ';']);
            evs(evs<=2) = []; % don't include bursts already happening at start time
            
            % if there's an event during this trial
            if ~isempty(evs)
                % preallocate
                trial = zeros(size(nbins));
                
                for ie = 1:length(evs) % for each beta event
                    
                    % count trial in bin it belongs to
                    upperbound = find(evs(ie)<nbins,1,'first');
                    trial(upperbound) = trial(upperbound) + 1;
                end
                
                % store event counts for this trial according to
                % accuracy and side of response to be made
                if side(it) == 1 && accuracy(it) == 4
                    dlfsl = dlfsl + 1;
                    d_l_bg_fsl(dlfsl,:) = trial;
                elseif side(it) == 2 && accuracy(it) == 4
                    dlfsr = dlfsr + 1;
                    d_l_bg_fsr(dlfsr,:) = trial;
                end
                if side(it) == 1 && accuracy(it) == 3
                    dlssl = dlssl + 1;
                    d_l_bg_ssl(dlssl,:) = trial;
                elseif side(it) == 2 && accuracy(it) == 3
                    dlssr = dlssr + 1;
                    d_l_bg_ssr(dlssr,:) = trial;
                end
                if side(it) == 1 && accuracy(it) == 1004
                    dlgfsl = dlgfsl + 1;
                    d_l_bg_gofsl(dlgfsl,:) = trial;
                elseif side(it) == 2 && accuracy(it) == 1004
                    dlgfsr = dlgfsr + 1;
                    d_l_bg_gofsr(dlgfsr,:) = trial;
                end
                if side(it) == 1 && accuracy(it) == 1003
                    dlgssl = dlgssl + 1;
                    d_l_bg_gossl(dlgssl,:) = trial;
                elseif side(it) == 2 && accuracy(it) == 1003
                    dlgssr = dlgssr + 1;
                    d_l_bg_gossr(dlgssr,:) = trial;
                end
                if side(it) == 1 && accuracy(it) == 1
                    dlgl = dlgl + 1;
                    d_l_bg_gol(dlgl,:) = trial;
                elseif side(it) == 2 && accuracy(it) == 1
                    dlgr = dlgr + 1;
                    d_l_bg_gor(dlgr,:) = trial;
                end
            end
            
            % if there are events during a matched go trial
            match_evs(match_evs<=2) = [];
            if ~isempty(match_evs)
                match_trial = zeros(size(nbins));
                
                for ie = 1:length(match_evs) % count those events in their bin (accounting for SSD)
                    upperbound = find(match_evs(ie)-ssd(nextgo)<nbins & match_evs(ie)-ssd(nextgo)>0,1,'first');
                    match_trial(upperbound) = match_trial(upperbound) + 1;
                end
                % sort according to accuracy and side
                if side(nextgo) == 1 && accuracy(nextgo) == 1
                    dlml = dlml + 1;
                    d_l_matchl(dlml,:) = match_trial;
                elseif side(nextgo) == 2 && accuracy(nextgo) == 1
                    dlmr = dlmr + 1;
                    d_l_matchr(dlmr,:) = match_trial;
                end
            end
        end
        
        % right side next
        if is ~= 2
        % presets for binned counts of bursts per trial type and trial type
        % counters
        d_r_bg_gol = []; d_r_bg_gor = []; drgr = 0; drgl = 0;
        d_r_bg_ssl = []; d_r_bg_ssr = []; drssr = 0; drssl = 0;
        d_r_bg_fsl = []; d_r_bg_fsr = []; drfsr = 0; drfsl = 0;
        d_r_bg_gossl = []; d_r_bg_gossr = []; drgssr = 0; drgssl = 0;
        d_r_bg_gofsl = []; d_r_bg_gofsr = []; drgfsr = 0; drgfsl = 0;
        d_r_matchl = []; d_r_matchr = []; drml = 0; drmr = 0; 
        
        for it = 1:length(fieldnames(dorsal_trialsbgr)) % for each trial
            % need to be cleared so we don't use last trial info
            nextgo = []; match_evs = []; match = []; evs = []; bevs = [];
            
            % if a stop trial, identify a go trial w/ similar or same
            % SSD
            if accuracy(it) == 3 || accuracy(it) == 4
                % try to pick matched go with same SSD soon after this
                % trial
                match = find(ssd-ssd(it) == 0 & accuracy == 1); nextgo = match(find(match>it,1,'first'));
                % if failed, pick first go trial w/ same SSD in exp
                if isempty(nextgo); nextgo = find(ssd-ssd(it) == 0 & accuracy == 1,1,'first'); end
                % if failed, pick first go trial w/ SSD w/in 50ms
                if isempty(nextgo); nextgo = find(ssd-ssd(it) == 50 | ssd-ssd(it) == -50 & accuracy == 1,1,'first'); end
                eval(['match_evs = dorsal_trialsbgr.t' num2str(nextgo) ';']);
            end
            
            % get events from that trial
            eval(['evs = dorsal_trialsbgr.t' num2str(it) ';']);
            evs(evs<=2) = []; % don't include bursts already happening at start time
            
            % if there's an event during this trial
            if ~isempty(evs)
                % preallocate
                trial = zeros(size(nbins));
                
                for ie = 1:length(evs) % for each beta event
                    
                    % count trial in bin it belongs to
                    upperbound = find(evs(ie)<nbins,1,'first');
                    trial(upperbound) = trial(upperbound) + 1;
                end
                
                % store event counts for this trial according to
                % accuracy and side of response to be made
                if side(it) == 1 && accuracy(it) == 4
                    drfsl = drfsl + 1;
                    d_r_bg_fsl(drfsl,:) = trial;
                elseif side(it) == 2 && accuracy(it) == 4
                    drfsr = drfsr + 1;
                    d_r_bg_fsr(drfsr,:) = trial;
                end
                if side(it) == 1 && accuracy(it) == 3
                    drssl = drssl + 1;
                    d_r_bg_ssl(drssl,:) = trial;
                elseif side(it) == 2 && accuracy(it) == 3
                    drssr = drssr + 1;
                    d_r_bg_ssr(drssr,:) = trial;
                end
                if side(it) == 1 && accuracy(it) == 1004
                    drgfsl = drgfsl + 1;
                    d_r_bg_gofsl(drgfsl,:) = trial;
                elseif side(it) == 2 && accuracy(it) == 1004
                    drgfsr = drgfsr + 1;
                    d_r_bg_gofsr(drgfsr,:) = trial;
                end
                if side(it) == 1 && accuracy(it) == 1003
                    drgssl = drgssl + 1;
                    d_r_bg_gossl(drgssl,:) = trial;
                elseif side(it) == 2 && accuracy(it) == 1003
                    drgssr = drgssr + 1;
                    d_r_bg_gossr(drgssr,:) = trial;
                end 
                if side(it) == 1 && accuracy(it) == 1
                    drgl = drgl + 1;
                    d_r_bg_gol(drgl,:) = trial;
                elseif side(it) == 2 && accuracy(it) == 1
                    drgr = drgr + 1;
                    d_r_bg_gor(drgr,:) = trial;
                end
            end
            
            % if there are events during a matched go trial
            match_evs(match_evs<=2) = [];
            if ~isempty(match_evs)
                match_trial = zeros(size(nbins));
                
                for ie = 1:length(match_evs) % count those events in their bin (accounting for SSD)
                    upperbound = find(match_evs(ie)-ssd(nextgo)<nbins & match_evs(ie)-ssd(nextgo)>0,1,'first');
                    match_trial(upperbound) = match_trial(upperbound) + 1;
                end
                % sort according to accuracy and side
                if side(nextgo) == 1 && accuracy(nextgo) == 1
                    drml = drml + 1;
                    d_r_matchl(drml,:) = match_trial;
                elseif side(nextgo) == 2 && accuracy(nextgo) == 1
                    drmr = drmr + 1;
                    d_r_matchr(drmr,:) = match_trial;
                end
            end
        end
        end
    end
    
    % delete all of the first time point bins to account for "pre-zero"
    % event accumulation
    r_bg_gol(:,1) = []; r_bg_gor(:,1) = [];
    if ~isempty(r_bg_fsr); r_bg_fsr(:,1) = []; end
    r_bg_fsl(:,1) = [];
    if ~isempty(r_bg_ssr); r_bg_ssr(:,1) = []; end
    if ~isempty(r_bg_ssl); r_bg_ssl(:,1) = []; end
    r_matchr(:,1) = []; r_matchl(:,1) = [];
    l_bg_gol(:,1) = []; l_bg_gor(:,1) = [];
    if ~isempty(l_bg_fsr); l_bg_fsr(:,1) = []; end
    l_bg_fsl(:,1) = [];
    l_bg_ssr(:,1) = []; l_bg_ssl(:,1) = [];
    l_matchr(:,1) = []; l_matchl(:,1) = [];
    if ~isempty(intersect(is,tha))
        if is ~= 2
        d_r_bg_gol(:,1) = []; d_r_bg_gor(:,1) = [];
        if ~isempty(d_r_bg_fsr); d_r_bg_fsr(:,1) = []; end
        if ~isempty(d_r_bg_fsl); d_r_bg_fsl(:,1) = []; end
        if ~isempty(d_r_bg_ssr); d_r_bg_ssr(:,1) = []; end
        if ~isempty(d_r_bg_ssl); d_r_bg_ssl(:,1) = []; end
        d_r_matchr(:,1) = []; d_r_matchl(:,1) = [];
        end
        d_l_bg_gol(:,1) = []; d_l_bg_gor(:,1) = [];
        if ~isempty(d_l_bg_fsr); d_l_bg_fsr(:,1) = []; end
        d_l_bg_fsl(:,1) = [];
        d_l_bg_ssr(:,1) = []; d_l_bg_ssl(:,1) = [];
        d_l_matchr(:,1) = []; d_l_matchl(:,1) = [];
    end
    
    % store percentages (get value of avg beta events per trial for each
    % trial type)
    CONTRA_FAILSTOP_main(is,:) = sum([l_bg_fsr;r_bg_fsl])/size([l_bg_fsr;r_bg_fsl],1);
    CONTRA_SUCCSTOP_main(is,:) = sum([l_bg_ssr;r_bg_ssl])/size([l_bg_ssr;r_bg_ssl],1);
    CONTRA_MATCHGO_main(is,:) = sum([r_matchl;l_matchr])/size([r_matchl;l_matchr],1);
    CONTRA_GO_bg_main(is,:) = sum([r_bg_gol;l_bg_gor])/size([r_bg_gol;l_bg_gor],1);
    IPSI_FAILSTOP_main(is,:) = sum([r_bg_fsr;l_bg_fsl])/size([r_bg_fsr;l_bg_fsl],1);
    IPSI_SUCCSTOP_main(is,:) = sum([r_bg_ssr;l_bg_ssl])/size([r_bg_ssr;l_bg_ssl],1);
    IPSI_MATCHGO_main(is,:) = sum([l_matchl;r_matchr])/size([l_matchl;r_matchr],1);
    IPSI_GO_bg_main(is,:) = sum([l_bg_gol;r_bg_gor])/size([l_bg_gol;r_bg_gor],1);
    if ~isempty(intersect(is,tha)) && is ~= 2
        D_CONTRA_FAILSTOP_main(is,:) = sum([d_l_bg_fsr;d_r_bg_fsl])/size([d_l_bg_fsr;d_r_bg_fsl],1);
        D_CONTRA_SUCCSTOP_main(is,:) = sum([d_l_bg_ssr;d_r_bg_ssl])/size([d_l_bg_ssr;d_r_bg_ssl],1);
        D_CONTRA_MATCHGO_main(is,:) = sum([d_r_matchl;d_l_matchr])/size([d_r_matchl;d_l_matchr],1);
        D_CONTRA_GO_bg_main(is,:) = sum([d_r_bg_gol;d_l_bg_gor])/size([d_r_bg_gol;d_l_bg_gor],1);
        D_IPSI_FAILSTOP_main(is,:) = sum([d_r_bg_fsr;d_l_bg_fsl])/size([d_r_bg_fsr;d_l_bg_fsl],1);
        D_IPSI_SUCCSTOP_main(is,:) = sum([d_r_bg_ssr;d_l_bg_ssl])/size([d_r_bg_ssr;d_l_bg_ssl],1);
        D_IPSI_MATCHGO_main(is,:) = sum([d_l_matchl;d_r_matchr])/size([d_l_matchl;d_r_matchr],1);
        D_IPSI_GO_bg_main(is,:) = sum([d_l_bg_gol;d_r_bg_gor])/size([d_l_bg_gol;d_r_bg_gor],1);
    end
end
thaplt = tha(2:end);
% barweb for stops
h = figure('Position',[1 1 1000 1000],'Color','w');
subplot(1,3,1);
barweb([nanmean(IPSI_SUCCSTOP_main(stn,:));nanmean(CONTRA_SUCCSTOP_main(stn,:))]',[sem(IPSI_SUCCSTOP_main(stn,:)); sem(CONTRA_SUCCSTOP_main(stn,:))]',.8,cellfun(@num2str,num2cell(nbins(2:end)),'UniformOutput',0),'Beta in STN on successful stop trials', 'time (ms) after stop signal', 'proportion of trials', '', '', {'ipsilateral stop','contralateral stop'});
subplot(1,3,2);
barweb([nanmean(IPSI_SUCCSTOP_main(thaplt,:));nanmean(CONTRA_SUCCSTOP_main(thaplt,:))]',[sem(IPSI_SUCCSTOP_main(thaplt,:)); sem(CONTRA_SUCCSTOP_main(thaplt,:))]',.8,cellfun(@num2str,num2cell(nbins(2:end)),'UniformOutput',0),'Beta in VIM on successful stop trials', 'time (ms) after stop signal', 'proportion of trials', '', '', {'ipsilateral stop','contralateral stop'});
subplot(1,3,3);
barweb([nanmean(D_IPSI_SUCCSTOP_main(thaplt,:));nanmean(D_CONTRA_SUCCSTOP_main(thaplt,:))]',[sem(D_IPSI_SUCCSTOP_main(thaplt,:)); sem(D_CONTRA_SUCCSTOP_main(thaplt,:))]',.8,cellfun(@num2str,num2cell(nbins(2:end)),'UniformOutput',0),'Beta in Vop on successful stop trials', 'time (ms) after stop signal', 'proportion of trials', '', '', {'ipsilateral stop','contralateral stop'});

h = figure('Position',[1 1 1000 1000],'Color','w');
subplot(1,3,1);
barweb([nanmean(IPSI_FAILSTOP_main(stn,:));nanmean(CONTRA_FAILSTOP_main(stn,:))]',[sem(IPSI_FAILSTOP_main(stn,:)); sem(CONTRA_FAILSTOP_main(stn,:))]',.8,cellfun(@num2str,num2cell(nbins(2:end)),'UniformOutput',0),'Beta in STN on fail trials', 'time (ms) after stop signal', 'proportion of trials', '', '', {'ipsilateral fail','contralateral fail'});
subplot(1,3,2);
barweb([nanmean(IPSI_FAILSTOP_main(thaplt,:));nanmean(CONTRA_FAILSTOP_main(thaplt,:))]',[sem(IPSI_FAILSTOP_main(thaplt,:)); sem(CONTRA_FAILSTOP_main(thaplt,:))]',.8,cellfun(@num2str,num2cell(nbins(2:end)),'UniformOutput',0),'Beta in VIM on fail trials', 'time (ms) after stop signal', 'proportion of trials', '', '', {'ipsilateral fail','contralateral fail'});
subplot(1,3,3);
barweb([nanmean(D_IPSI_FAILSTOP_main(thaplt,:));nanmean(D_CONTRA_FAILSTOP_main(thaplt,:))]',[sem(D_IPSI_FAILSTOP_main(thaplt,:)); sem(D_CONTRA_FAILSTOP_main(thaplt,:))]',.8,cellfun(@num2str,num2cell(nbins(2:end)),'UniformOutput',0),'Beta in Vop on fail trials', 'time (ms) after stop signal', 'proportion of trials', '', '', {'ipsilateral fail','contralateral fail'});

h = figure('Position',[1 1 1000 1000],'Color','w');
subplot(1,3,1);
barweb([nanmean(IPSI_MATCHGO_main(stn,:));nanmean(CONTRA_MATCHGO_main(stn,:))]',[sem(IPSI_MATCHGO_main(stn,:)); sem(CONTRA_MATCHGO_main(stn,:))]',.8,cellfun(@num2str,num2cell(nbins(2:end)),'UniformOutput',0),'Beta in STN on match go trials', 'time (ms) after stop signal', 'proportion of trials', '', '', {'ipsilateral go','contralateral go'});
subplot(1,3,2);
barweb([nanmean(IPSI_MATCHGO_main(thaplt,:));nanmean(CONTRA_MATCHGO_main(thaplt,:))]',[sem(IPSI_MATCHGO_main(thaplt,:)); sem(CONTRA_MATCHGO_main(thaplt,:))]',.8,cellfun(@num2str,num2cell(nbins(2:end)),'UniformOutput',0),'Beta in VIM on match go trials', 'time (ms) after stop signal', 'proportion of trials', '', '', {'ipsilateral go','contralateral go'});
subplot(1,3,3);
barweb([nanmean(D_IPSI_MATCHGO_main(thaplt,:));nanmean(D_CONTRA_MATCHGO_main(thaplt,:))]',[sem(D_IPSI_MATCHGO_main(thaplt,:)); sem(D_CONTRA_MATCHGO_main(thaplt,:))]',.8,cellfun(@num2str,num2cell(nbins(2:end)),'UniformOutput',0),'Beta in Vop on match go trials', 'time (ms) after stop signal', 'proportion of trials', '', '', {'ipsilateral go','contralateral go'});

% stats
for it = 1:length(nbins)-1
    [STN_gop(it)] = mc_ttest(CONTRA_MATCHGO_main(stn,it),IPSI_MATCHGO_main(stn,it),10000);
    [VIM_gop(it)] = mc_ttest(CONTRA_MATCHGO_main(thaplt,it),IPSI_MATCHGO_main(thaplt,it),10000);
    [VOP_gop(it)] = mc_ttest(D_CONTRA_MATCHGO_main(thaplt,it),D_IPSI_MATCHGO_main(thaplt,it),10000);
    [STN_failp(it)] = mc_ttest(CONTRA_FAILSTOP_main(stn,it),IPSI_FAILSTOP_main(stn,it),10000);
    [VIM_failp(it)] = mc_ttest(CONTRA_FAILSTOP_main(thaplt,it),IPSI_FAILSTOP_main(thaplt,it),10000);
    [VOP_failp(it)] = mc_ttest(D_CONTRA_FAILSTOP_main(thaplt,it),D_IPSI_FAILSTOP_main(thaplt,it),10000);
    [STN_succp(it)] = mc_ttest(CONTRA_SUCCSTOP_main(stn,it),IPSI_SUCCSTOP_main(stn,it),10000);
    [VIM_succp(it)] = mc_ttest(CONTRA_SUCCSTOP_main(thaplt,it),IPSI_SUCCSTOP_main(thaplt,it),10000);    
    [VOP_succp(it)] = mc_ttest(D_CONTRA_SUCCSTOP_main(thaplt,it),D_IPSI_SUCCSTOP_main(thaplt,it),10000);    
end
corrected_go_STNp = bonf_holm(STN_gop); corrected_fail_STNp = bonf_holm(STN_failp); corrected_succ_STNp = bonf_holm(STN_succp);
corrected_go_VIMp = bonf_holm(VIM_gop); corrected_fail_VIMp = bonf_holm(VIM_failp); corrected_succ_VIMp = bonf_holm(VIM_succp);
corrected_go_VOPp = bonf_holm(VOP_gop); corrected_fail_VOPp = bonf_holm(VOP_failp); corrected_succ_VOPp = bonf_holm(VOP_succp);
disp('STN sample - Significant burst differences were seen for go at these time points:');
for it = 1:length(nbins)-1
    if corrected_go_STNp(it) <= .05; disp([num2str(nbins(it)) ' to ' num2str(nbins(it+1)) 'ms: p = ' num2str(corrected_go_STNp(it))]); end
end
disp('STN sample - Significant burst differences were seen for fail at these time points:');
for it = 1:length(nbins)-1
    if corrected_fail_STNp(it) <= .05; disp([num2str(nbins(it)) ' to ' num2str(nbins(it+1)) 'ms: p = ' num2str(corrected_fail_STNp(it))]); end
end
disp('STN sample - Significant burst differences were seen for succ at these time points:');
for it = 1:length(nbins)-1
    if corrected_succ_STNp(it) <= .05; disp([num2str(nbins(it)) ' to ' num2str(nbins(it+1)) 'ms: p = ' num2str(corrected_succ_STNp(it))]); end
end

disp('VIM sample - Significant burst differences were seen for go at these time points:');
for it = 1:length(nbins)-1
    if corrected_go_VIMp(it)<=.05; disp([num2str(nbins(it)) ' to ' num2str(nbins(it+1)) 'ms: p = ' num2str(corrected_go_VIMp(it))]); end
end
disp('VIM sample - Significant burst differences were seen for fail at these time points:');
for it = 1:length(nbins)-1
    if corrected_fail_VIMp(it)<=.05; disp([num2str(nbins(it)) ' to ' num2str(nbins(it+1)) 'ms: p = ' num2str(corrected_fail_VIMp(it))]); end
end
disp('VIM sample - Significant burst differences were seen for succ at these time points:');
for it = 1:length(nbins)-1
    if corrected_succ_VIMp(it)<=.05; disp([num2str(nbins(it)) ' to ' num2str(nbins(it+1)) 'ms: p = ' num2str(corrected_succ_VIMp(it))]); end
end

disp('VOP sample - Significant burst differences were seen for go at these time points:');
for it = 1:length(nbins)-1
    if corrected_go_VOPp(it)<=.05; disp([num2str(nbins(it)) ' to ' num2str(nbins(it+1)) 'ms: p = ' num2str(corrected_go_VOPp(it))]); end
end
disp('VOP sample - Significant burst differences were seen for fail at these time points:');
for it = 1:length(nbins)-1
    if corrected_fail_VOPp(it)<=.05; disp([num2str(nbins(it)) ' to ' num2str(nbins(it+1)) 'ms: p = ' num2str(corrected_fail_VOPp(it))]); end
end
disp('VOP sample - Significant burst differences were seen for succ at these time points:');
for it = 1:length(nbins)-1
    if corrected_succ_VOPp(it)<=.05; disp([num2str(nbins(it)) ' to ' num2str(nbins(it+1)) 'ms: p = ' num2str(corrected_succ_VOPp(it))]); end
end

%% M1 bursts after BG bursts

border = 500; % max events in ms after stop-signal
M1bins = [-100:50:100]; %set bins

% preallocate
CONTRASUCC_main = NaN(length(datasets),length(M1bins)-1);
IPSISUCC_main = CONTRASUCC_main;
CONTRAFAIL_main = CONTRASUCC_main; IPSIFAIL_main = CONTRASUCC_main;
CONTRAGO_main = CONTRASUCC_main; IPSIGO_main = CONTRASUCC_main;
CONTRAMATCH_main = CONTRASUCC_main; IPSIMATCH_main = CONTRASUCC_main;
D_CONTRASUCC_main = CONTRASUCC_main; D_IPSISUCC_main = CONTRASUCC_main;
D_CONTRAFAIL_main = CONTRASUCC_main; D_IPSIFAIL_main = CONTRASUCC_main;
D_CONTRAGO_main = CONTRASUCC_main; D_IPSIGO_main = CONTRASUCC_main;
D_CONTRAMATCH_main = CONTRASUCC_main; D_IPSIMATCH_main = CONTRASUCC_main;
locations = {'rstn','lstn','rvim','lvim','rm1','lm1'}; % all possible

for is = 1:length(datasets) % For each participant
    
    subnum = datasets(is).subnum;
    
    clear trialevs* trials*
    
    % load eventindices
    load(fullfile(folders.beta,['Subject' num2str(subnum) '.mat']));
    
    % assign channels (only main block has depth electrodes)
    % assign VIM [THIS DEFAULT TO STN FOR 104 (which has both VIM and STN)]
    if sum(~cellfun(@isempty,strfind(chanlabels,'rvim'))) == 1
        rbgchan = ~cellfun(@isempty,strfind(chanlabels,'rvim'));
        lbgchan = ~cellfun(@isempty,strfind(chanlabels,'lvim'));
        eval(['trialsbgr = trialevs.' chanlabels{rbgchan} ';']);
        eval(['trialsbgl = trialevs.' chanlabels{lbgchan} ';']);
    end
    % assign STN [THIS DEFAULTS TO STN FOR 104 (which has both VIM and STN)]
    if sum(~cellfun(@isempty,strfind(chanlabels,'rstn'))) == 1
        rbgchan = ~cellfun(@isempty,strfind(chanlabels,'rstn'));
        lbgchan = ~cellfun(@isempty,strfind(chanlabels,'lstn'));
        eval(['trialsbgr = trialevs.' chanlabels{rbgchan} ';']);
        eval(['trialsbgl = trialevs.' chanlabels{lbgchan} ';']);
    end
    
    % combine left and right bg data
    trialnumbers = fieldnames(trialsbgl); clear trials;
    rightmotor = chanlabels{~cellfun(@isempty,strfind(chanlabels,'rm1'))};
    eval(['trialsc4 = trialevs.' rightmotor ';']);
    % assign left motor
    leftmotor = chanlabels{~cellfun(@isempty,strfind(chanlabels,'lm1'))};
    eval(['trialsc3 = trialevs.' leftmotor ';']);
    
    % do right bg first
    
    % presets
    ipsi_go = []; contra_go = [];
    ig = 0; cg = 0;
    ipsi_ss = []; contra_ss = [];
    iss = 0; css = 0;
    ipsi_fs = []; contra_fs = [];
    ifs = 0; cfs = 0;
    contra_match = []; ipsi_match = [];
    cm = 0; im = 0;
        
    for it = 1:length(fieldnames(trialsbgr)) % for each trial
        nextgo = []; bg_matchevs = []; matchevs = []; 
        match = []; bgevs = [];
        
        % if a stop trial, find go trial with similar or same SSD
        if accuracy(it) == 3 || accuracy(it) == 4
            % try to pick matched go with same SSD soon after this
            % trial
            match = find(ssd-ssd(it) == 0 & accuracy == 1); nextgo = match(find(match>it,1,'first'));
            % if failed, pick most recent
            if isempty(nextgo); match = find(ssd-ssd(it) == 0 & accuracy == 1); nextgo = match(find(match<it,1,'last')); end
            % if failed, pick first go trial w/ SSD w/in 50ms
            if isempty(nextgo); nextgo = find(ssd-ssd(it) == 50 | ssd-ssd(it) == -50 & accuracy == 1,1,'first'); end
            eval(['bg_matchevs = trialsbgr.t' num2str(nextgo) ';']);
            if side(it) == 1
                eval(['matchevs = trialsc4.t' num2str(nextgo) ';']);
            else
                eval(['matchevs = trialsc3.t' num2str(nextgo) ';']);
            end
        end
        
        % get events within border (set at 500ms)
        eval(['bgevs = trialsbgr.t' num2str(it) ';']); bgevs(bgevs>border) = []; bgevs(bgevs<=2) = [];
        if side(it) == 1
            eval(['m1evs = trialsc4.t' num2str(it) ';']); m1evs(m1evs>border) = []; m1evs(m1evs<=2) = [];
        else
            eval(['m1evs = trialsc3.t' num2str(it) ';']); m1evs(m1evs>border) = []; m1evs(m1evs<=2) = [];
        end
        matchevs(matchevs>border+ssd(it)) = []; matchevs(matchevs<=2) = [];
        
        % if > 1 event
        if ~isempty(bgevs)
            
            trial = zeros(size(M1bins));
            matchtrial = trial;
            
            for ie = 1 % for first ev
                % find M1 bursts during the appropriate time range
                % surrounding BG burst
                m1pick = find((m1evs-bgevs(ie))<M1bins(end) & (m1evs-bgevs(ie))>M1bins(1),1,'first');
                
                if ~isempty(m1pick)
                    upperbound = find((m1evs(m1pick)-bgevs(ie))<M1bins,1,'first');
                    trial(upperbound) = trial(upperbound) + 1;
                end
            end
            
            % sort based on side and accuracy
            if side(it) == 1 && accuracy(it) == 4
                ifs = ifs + 1;
                ipsi_fs(ifs,:) = trial;
            elseif side(it) == 2 && accuracy(it) == 4
                cfs = cfs + 1;
                contra_fs(cfs,:) = trial;
            end
            if side(it) == 1 && accuracy(it) == 3
                iss = iss + 1;
                ipsi_ss(iss,:) = trial;
            elseif side(it) == 2 && accuracy(it) == 3
                css = css + 1;
                contra_ss(css,:) = trial;
            end
            if side(it) == 1 && accuracy(it) == 1
                ig = ig + 1;
                ipsi_go(ig,:) = trial;
            elseif side(it) == 2 && accuracy(it) == 1
                cg = cg + 1;
                contra_go(cg,:) = trial;
            end
        end
        % if there are events in the matched go trial
        if ~isempty(bg_matchevs)
            for ie = 1:length(bg_matchevs) % for first ev
                % find events in the correct window in motor cortex
                % and classify them in their bins
                matchpick = find((matchevs-bg_matchevs(ie)-ssd(nextgo))<M1bins(end) & (matchevs-bg_matchevs(ie)-ssd(nextgo))>M1bins(1),1,'first');
                
                if ~isempty(matchpick)
                    upperbound = find((matchevs(matchpick)-bg_matchevs(ie)-ssd(nextgo))<M1bins,1,'first');
                    matchtrial(upperbound) = matchtrial(upperbound) + 1;
                end

                % sort by side and accuracy
                if side(nextgo) == 1 && accuracy(nextgo) == 1
                    im = im + 1;
                    ipsi_match(im,:) = matchtrial;
                elseif side(nextgo) == 2 && accuracy(nextgo) == 1
                    cm = cm + 1;
                    contra_match(cm,:) = matchtrial;
                end
            end
        end
    end
    
    % do for left bg
    for it = 1:length(fieldnames(trialsbgl)) % for each trial
        nextgo = []; bg_matchevs = []; matchevs = []; 
        match = []; bgevs = [];
        
        % if a stop trial, find go trial with similar or same SSD
        if accuracy(it) == 3 || accuracy(it) == 4
            % try to pick matched go with same SSD soon after this
            % trial
            match = find(ssd-ssd(it) == 0 & accuracy == 1); nextgo = match(find(match>it,1,'first'));
            % if failed, pick most recent
            if isempty(nextgo); match = find(ssd-ssd(it) == 0 & accuracy == 1); nextgo = match(find(match<it,1,'last')); end
            % if failed, pick first go trial w/ SSD w/in 50ms
            if isempty(nextgo); nextgo = find(ssd-ssd(it) == 50 | ssd-ssd(it) == -50 & accuracy == 1,1,'first'); end
            eval(['bg_matchevs = trialsbgl.t' num2str(nextgo) ';']);
            if side(it) == 2
                eval(['matchevs = trialsc4.t' num2str(nextgo) ';']);
            else
                eval(['matchevs = trialsc3.t' num2str(nextgo) ';']);
            end
        end
        
        % get events within border (set at 500ms)
        eval(['bgevs = trialsbgl.t' num2str(it) ';']); bgevs(bgevs>border) = []; bgevs(bgevs<=2) = [];
        if side(it) == 2
            eval(['m1evs = trialsc4.t' num2str(it) ';']); m1evs(m1evs>border) = []; m1evs(m1evs<=2) = [];
        else
            eval(['m1evs = trialsc3.t' num2str(it) ';']); m1evs(m1evs>border) = []; m1evs(m1evs<=2) = [];
        end
        matchevs(matchevs>border+ssd(nextgo)) = []; matchevs(matchevs<=2) = [];
        bg_matchevs(bg_matchevs>border+ssd(nextgo)) = []; bg_matchevs(bg_matchevs<=2) = [];
        
        % if > 1 event
        if ~isempty(bgevs)
            
            trial = zeros(size(M1bins));
            matchtrial = trial;
            
            for ie = 1 % for first ev
                % find M1 bursts during the appropriate time range
                % surrounding BG burst
                m1pick = find((m1evs-bgevs(ie))<M1bins(end) & (m1evs-bgevs(ie))>M1bins(1),1,'first');
                
                if ~isempty(m1pick)
                    upperbound = find((m1evs(m1pick)-bgevs(ie))<M1bins,1,'first');
                    trial(upperbound) = trial(upperbound) + 1;
                end
            end
            
            % sort based on side and accuracy
            if side(it) == 2 && accuracy(it) == 4
                ifs = ifs + 1;
                ipsi_fs(ifs,:) = trial;
            elseif side(it) == 1 && accuracy(it) == 4
                cfs = cfs + 1;
                contra_fs(cfs,:) = trial;
            end
            if side(it) == 2 && accuracy(it) == 3
                iss = iss + 1;
                ipsi_ss(iss,:) = trial;
            elseif side(it) == 1 && accuracy(it) == 3
                css = css + 1;
                contra_ss(css,:) = trial;
            end
            if side(it) == 2 && accuracy(it) == 1
                ig = ig + 1;
                ipsi_go(ig,:) = trial;
            elseif side(it) == 1 && accuracy(it) == 1
                cg = cg + 1;
                contra_go(cg,:) = trial;
            end
        end
        % if there are events in the matched go trial
        if ~isempty(bg_matchevs)
            for ie = 1:length(bg_matchevs) % for first ev
                % find events in the correct window in motor cortex
                % and classify them in their bins
                matchpick = find((matchevs-bg_matchevs(ie)-ssd(nextgo))<M1bins(end) & (matchevs-bg_matchevs(ie)-ssd(nextgo))>M1bins(1),1,'first');
                
                if ~isempty(matchpick)
                    upperbound = find((matchevs(matchpick)-bg_matchevs(ie)-ssd(nextgo))<M1bins,1,'first');
                    matchtrial(upperbound) = matchtrial(upperbound) + 1;
                end
                
                % sort by side and accuracy
                if side(nextgo) == 2 && accuracy(nextgo) == 1
                    im = im + 1;
                    ipsi_match(im,:) = matchtrial;
                elseif side(nextgo) == 1 && accuracy(nextgo) == 1
                    cm = cm + 1;
                    contra_match(cm,:) = matchtrial;
                end
            end
        end
    end
    
    % dorsal evs if a thalamic DBS case
    if ~isempty(intersect(is,tha([2 4 5 7:end])))
        clear trialevs* trials*
        
        % load eventindices
        load(fullfile(folders.beta,['Subject' num2str(subnum) '_dorsal.mat']));
        
        % assign channels (only main block has depth electrodes)
        % assign VIM [THIS DEFAULT TO STN FOR 104 (which has both VIM and STN)]
        if sum(~cellfun(@isempty,strfind(chanlabels,'rvim'))) == 1
            rbgchan = ~cellfun(@isempty,strfind(chanlabels,'rvim'));
            lbgchan = ~cellfun(@isempty,strfind(chanlabels,'lvim'));
            eval(['trialsbgr = trialevs.' chanlabels{rbgchan} ';']);
            eval(['trialsbgl = trialevs.' chanlabels{lbgchan} ';']);
        end
        
        % combine left and right bg data
        trialnumbers = fieldnames(trialsbgl); clear trials;
        rightmotor = chanlabels{~cellfun(@isempty,strfind(chanlabels,'rm1'))};
        eval(['trialsc4 = trialevs.' rightmotor ';']);
        % assign left motor
        leftmotor = chanlabels{~cellfun(@isempty,strfind(chanlabels,'lm1'))};
        eval(['trialsc3 = trialevs.' leftmotor ';']);
        
        % do right bg first
        
        % presets
        d_ipsi_go = []; d_contra_go = [];
        dig = 0; dcg = 0;
        d_ipsi_ss = []; d_contra_ss = [];
        diss = 0; dcss = 0;
        d_ipsi_fs = []; d_contra_fs = [];
        difs = 0; dcfs = 0;
        d_contra_match = []; d_ipsi_match = [];
        dcm = 0; dim = 0;
        
        for it = 1:length(fieldnames(trialsbgr)) % for each trial
            nextgo = []; bg_matchevs = []; matchevs = [];
            match = []; bgevs = [];
            
            % if a stop trial, find go trial with similar or same SSD
            if accuracy(it) == 3 || accuracy(it) == 4
                % try to pick matched go with same SSD soon after this
                % trial
                match = find(ssd-ssd(it) == 0 & accuracy == 1); nextgo = match(find(match>it,1,'first'));
                % if failed, pick most recent
                if isempty(nextgo); match = find(ssd-ssd(it) == 0 & accuracy == 1); nextgo = match(find(match<it,1,'last')); end
                % if failed, pick first go trial w/ SSD w/in 50ms
                if isempty(nextgo); nextgo = find(ssd-ssd(it) == 50 | ssd-ssd(it) == -50 & accuracy == 1,1,'first'); end
                eval(['bg_matchevs = trialsbgr.t' num2str(nextgo) ';']);
                if side(it) == 1
                    eval(['matchevs = trialsc4.t' num2str(nextgo) ';']);
                else
                    eval(['matchevs = trialsc3.t' num2str(nextgo) ';']);
                end
            end
            
            % get events within border (set at 500ms)
            eval(['bgevs = trialsbgr.t' num2str(it) ';']); bgevs(bgevs>border) = []; bgevs(bgevs<=2) = [];
            if side(it) == 1
                eval(['m1evs = trialsc4.t' num2str(it) ';']); m1evs(m1evs>border) = []; m1evs(m1evs<=2) = [];
            else
                eval(['m1evs = trialsc3.t' num2str(it) ';']); m1evs(m1evs>border) = []; m1evs(m1evs<=2) = [];
            end
            matchevs(matchevs>border+ssd(it)) = []; matchevs(matchevs<=2) = [];
            
            % if > 1 event
            if ~isempty(bgevs)
                
                trial = zeros(size(M1bins));
                matchtrial = trial;
                
                for ie = 1 % for first ev
                    % find M1 bursts during the appropriate time range
                    % surrounding BG burst
                    m1pick = find((m1evs-bgevs(ie))<M1bins(end) & (m1evs-bgevs(ie))>M1bins(1),1,'first');
                    
                    if ~isempty(m1pick)
                        upperbound = find((m1evs(m1pick)-bgevs(ie))<M1bins,1,'first');
                        trial(upperbound) = trial(upperbound) + 1;
                    end
                end
                
                % sort based on side and accuracy
                if side(it) == 1 && accuracy(it) == 4
                    difs = difs + 1;
                    d_ipsi_fs(difs,:) = trial;
                elseif side(it) == 2 && accuracy(it) == 4
                    dcfs = dcfs + 1;
                    d_contra_fs(dcfs,:) = trial;
                end
                if side(it) == 1 && accuracy(it) == 3
                    diss = diss + 1;
                    d_ipsi_ss(diss,:) = trial;
                elseif side(it) == 2 && accuracy(it) == 3
                    dcss = dcss + 1;
                    d_contra_ss(dcss,:) = trial;
                end
                if side(it) == 1 && accuracy(it) == 1
                    dig = dig + 1;
                    d_ipsi_go(dig,:) = trial;
                elseif side(it) == 2 && accuracy(it) == 1
                    dcg = dcg + 1;
                    d_contra_go(dcg,:) = trial;
                end
            end
            % if there are events in the matched go trial
            if ~isempty(bg_matchevs)
                for ie = 1:length(bg_matchevs) % for first ev
                    % find events in the correct window in motor cortex
                    % and classify them in their bins
                    matchpick = find((matchevs-bg_matchevs(ie)-ssd(nextgo))<M1bins(end) & (matchevs-bg_matchevs(ie)-ssd(nextgo))>M1bins(1),1,'first');
                    
                    if ~isempty(matchpick)
                        upperbound = find((matchevs(matchpick)-bg_matchevs(ie)-ssd(nextgo))<M1bins,1,'first');
                        matchtrial(upperbound) = matchtrial(upperbound) + 1;
                    end
                    
                    % sort by side and accuracy
                    if side(nextgo) == 1 && accuracy(nextgo) == 1
                        dim = dim + 1;
                        d_ipsi_match(dim,:) = matchtrial;
                    elseif side(nextgo) == 2 && accuracy(nextgo) == 1
                        dcm = dcm + 1;
                        d_contra_match(dcm,:) = matchtrial;
                    end
                end
            end
        end
        
        % do for left bg
        for it = 1:length(fieldnames(trialsbgl)) % for each trial
            nextgo = []; bg_matchevs = []; matchevs = [];
            match = []; bgevs = [];
            
            % if a stop trial, find go trial with similar or same SSD
            if accuracy(it) == 3 || accuracy(it) == 4
                % try to pick matched go with same SSD soon after this
                % trial
                match = find(ssd-ssd(it) == 0 & accuracy == 1); nextgo = match(find(match>it,1,'first'));
                % if failed, pick most recent
                if isempty(nextgo); match = find(ssd-ssd(it) == 0 & accuracy == 1); nextgo = match(find(match<it,1,'last')); end
                % if failed, pick first go trial w/ SSD w/in 50ms
                if isempty(nextgo); nextgo = find(ssd-ssd(it) == 50 | ssd-ssd(it) == -50 & accuracy == 1,1,'first'); end
                eval(['bg_matchevs = trialsbgl.t' num2str(nextgo) ';']);
                if side(it) == 2
                    eval(['matchevs = trialsc4.t' num2str(nextgo) ';']);
                else
                    eval(['matchevs = trialsc3.t' num2str(nextgo) ';']);
                end
            end
            
            % get events within border (set at 500ms)
            eval(['bgevs = trialsbgl.t' num2str(it) ';']); bgevs(bgevs>border) = []; bgevs(bgevs<=2) = [];
            if side(it) == 2
                eval(['m1evs = trialsc4.t' num2str(it) ';']); m1evs(m1evs>border) = []; m1evs(m1evs<=2) = [];
            else
                eval(['m1evs = trialsc3.t' num2str(it) ';']); m1evs(m1evs>border) = []; m1evs(m1evs<=2) = [];
            end
            matchevs(matchevs>border+ssd(nextgo)) = []; matchevs(matchevs<=2) = [];
            bg_matchevs(bg_matchevs>border+ssd(nextgo)) = []; bg_matchevs(bg_matchevs<=2) = [];
            
            % if > 1 event
            if ~isempty(bgevs)
                
                trial = zeros(size(M1bins));
                matchtrial = trial;
                
                for ie = 1 % for first ev
                    % find M1 bursts during the appropriate time range
                    % surrounding BG burst
                    m1pick = find((m1evs-bgevs(ie))<M1bins(end) & (m1evs-bgevs(ie))>M1bins(1),1,'first');
                    
                    if ~isempty(m1pick)
                        upperbound = find((m1evs(m1pick)-bgevs(ie))<M1bins,1,'first');
                        trial(upperbound) = trial(upperbound) + 1;
                    end
                end
                
                % sort based on side and accuracy
                if side(it) == 2 && accuracy(it) == 4
                    difs = difs + 1;
                    d_ipsi_fs(difs,:) = trial;
                elseif side(it) == 1 && accuracy(it) == 4
                    dcfs = dcfs + 1;
                    d_contra_fs(dcfs,:) = trial;
                end
                if side(it) == 2 && accuracy(it) == 3
                    diss = diss + 1;
                    d_ipsi_ss(diss,:) = trial;
                elseif side(it) == 1 && accuracy(it) == 3
                    dcss = dcss + 1;
                    d_contra_ss(dcss,:) = trial;
                end
                if side(it) == 2 && accuracy(it) == 1
                    dig = dig + 1;
                    d_ipsi_go(dig,:) = trial;
                elseif side(it) == 1 && accuracy(it) == 1
                    dcg = dcg + 1;
                    d_contra_go(dcg,:) = trial;
                end
            end
            % if there are events in the matched go trial
            if ~isempty(bg_matchevs)
                for ie = 1:length(bg_matchevs) % for first ev
                    % find events in the correct window in motor cortex
                    % and classify them in their bins
                    matchpick = find((matchevs-bg_matchevs(ie)-ssd(nextgo))<M1bins(end) & (matchevs-bg_matchevs(ie)-ssd(nextgo))>M1bins(1),1,'first');
                    
                    if ~isempty(matchpick)
                        upperbound = find((matchevs(matchpick)-bg_matchevs(ie)-ssd(nextgo))<M1bins,1,'first');
                        matchtrial(upperbound) = matchtrial(upperbound) + 1;
                    end
                    
                    % sort by side and accuracy
                    if side(nextgo) == 2 && accuracy(nextgo) == 1
                        dim = dim + 1;
                        d_ipsi_match(dim,:) = matchtrial;
                    elseif side(nextgo) == 1 && accuracy(nextgo) == 1
                        dcm = dcm + 1;
                        d_contra_match(dcm,:) = matchtrial;
                    end
                end
            end
        end
    end
    
    % delete the first bins to prevent baseline accumulation
    ipsi_go(:,1) = []; contra_go(:,1) = [];
    if ~isempty(ipsi_fs); ipsi_fs(:,1) = []; end
    if ~isempty(contra_fs); contra_fs(:,1) = []; end
    ipsi_ss(:,1) = []; contra_ss(:,1) = [];
    ipsi_match(:,1) = []; contra_match(:,1) = [];
    if ~isempty(intersect(is,tha([2 4 5 7:end])))
        d_ipsi_go(:,1) = []; d_contra_go(:,1) = [];
        if ~isempty(d_ipsi_fs); d_ipsi_fs(:,1) = []; end
        if ~isempty(d_contra_fs); d_contra_fs(:,1) = []; end
        d_ipsi_ss(:,1) = []; d_contra_ss(:,1) = [];
        d_ipsi_match(:,1) = []; d_contra_match(:,1) = [];
    end
    
    % store percentages (avg num of evs per trial)
    CONTRAGO_main(is,:) = sum(contra_go)/size(contra_go,1);
    IPSIGO_main(is,:) = sum(ipsi_go)/size(ipsi_go,1);
    CONTRAFAIL_main(is,:) = sum(contra_fs)/size(contra_fs,1);
    IPSIFAIL_main(is,:) = sum(ipsi_fs)/size(ipsi_fs,1);
    CONTRASUCC_main(is,:) = sum(contra_ss)/size(contra_ss,1);
    IPSISUCC_main(is,:) = sum(ipsi_ss)/size(ipsi_ss,1);
    IPSIMATCH_main(is,:) = sum(ipsi_match)/size(ipsi_match,1);
    CONTRAMATCH_main(is,:) = sum(contra_match)/size(contra_match,1);
    if ~isempty(intersect(is,tha([2 4 5 7:end])))
        D_CONTRAGO_main(is,:) = sum(d_contra_go)/size(d_contra_go,1);
        D_IPSIGO_main(is,:) = sum(d_ipsi_go)/size(d_ipsi_go,1);
        D_CONTRAFAIL_main(is,:) = sum(d_contra_fs)/size(d_contra_fs,1);
        D_IPSIFAIL_main(is,:) = sum(d_ipsi_fs)/size(d_ipsi_fs,1);
        D_CONTRASUCC_main(is,:) = sum(d_contra_ss)/size(d_contra_ss,1);
        D_IPSISUCC_main(is,:) = sum(d_ipsi_ss)/size(d_ipsi_ss,1);
        D_IPSIMATCH_main(is,:) = sum(d_ipsi_match)/size(d_ipsi_match,1);
        D_CONTRAMATCH_main(is,:) = sum(d_contra_match)/size(d_contra_match,1);
    end
end
thaplt = tha([2 4 5 7:end]); 
% barweb for stops
h = figure('Position',[1 1 1000 1000],'Color','w');
subplot(1,3,1);
barweb([nanmean(IPSISUCC_main(stn,:));nanmean(CONTRASUCC_main(stn,:))]',[sem(IPSISUCC_main(stn,:)); sem(CONTRASUCC_main(stn,:))]',.8,cellfun(@num2str,num2cell(M1bins(2:end)),'UniformOutput',0),'Beta in STN on stop trials', 'time (ms) after BG burst', 'proportion of trials', '', '', {'ipsilateral stop','contralateral stop'});
subplot(1,3,2);
barweb([nanmean(IPSISUCC_main(thaplt,:));nanmean(CONTRASUCC_main(thaplt,:))]',[sem(IPSISUCC_main(thaplt,:)); sem(CONTRASUCC_main(thaplt,:))]',.8,cellfun(@num2str,num2cell(M1bins(2:end)),'UniformOutput',0),'Beta in VIM on stop trials', 'time (ms) after BG burst', 'proportion of trials', '', '', {'ipsilateral stop','contralateral stop'});
subplot(1,3,3);
barweb([nanmean(D_IPSISUCC_main(thaplt,:));nanmean(D_CONTRASUCC_main(thaplt,:))]',[sem(D_IPSISUCC_main(thaplt,:)); sem(D_CONTRASUCC_main(thaplt,:))]',.8,cellfun(@num2str,num2cell(M1bins(2:end)),'UniformOutput',0),'Beta in Vop on stop trials', 'time (ms) after BG burst', 'proportion of trials', '', '', {'ipsilateral stop','contralateral stop'});
% fails
h = figure('Position',[1 1 1000 1000],'Color','w');
subplot(1,3,1);
barweb([nanmean(IPSIFAIL_main(stn,:));nanmean(CONTRAFAIL_main(stn,:))]',[sem(IPSIFAIL_main(stn,:)); sem(CONTRAFAIL_main(stn,:))]',.8,cellfun(@num2str,num2cell(M1bins(2:end)),'UniformOutput',0),'Beta in STN on fail trials', 'time (ms) after BG burst', 'proportion of trials', '', '', {'ipsilateral stop','contralateral stop'});
subplot(1,3,2);
barweb([nanmean(IPSIFAIL_main(thaplt,:));nanmean(CONTRAFAIL_main(thaplt,:))]',[sem(IPSIFAIL_main(thaplt,:)); sem(CONTRAFAIL_main(thaplt,:))]',.8,cellfun(@num2str,num2cell(M1bins(2:end)),'UniformOutput',0),'Beta in VIM on fail trials', 'time (ms) after BG burst', 'proportion of trials', '', '', {'ipsilateral stop','contralateral stop'});
subplot(1,3,3);
barweb([nanmean(D_IPSIFAIL_main(thaplt,:));nanmean(D_CONTRAFAIL_main(thaplt,:))]',[sem(D_IPSIFAIL_main(thaplt,:)); sem(D_CONTRAFAIL_main(thaplt,:))]',.8,cellfun(@num2str,num2cell(M1bins(2:end)),'UniformOutput',0),'Beta in Vop on fail trials', 'time (ms) after BG burst', 'proportion of trials', '', '', {'ipsilateral stop','contralateral stop'});
% matched go
h = figure('Position',[1 1 1000 1000],'Color','w');
subplot(1,3,1);
barweb([nanmean(IPSIMATCH_main(stn,:));nanmean(CONTRAMATCH_main(stn,:))]',[sem(IPSIMATCH_main(stn,:)); sem(CONTRAMATCH_main(stn,:))]',.8,cellfun(@num2str,num2cell(M1bins(2:end)),'UniformOutput',0),'Beta in STN on go trials', 'time (ms) after BG burst', 'proportion of trials', '', '', {'ipsilateral stop','contralateral stop'});
subplot(1,3,2);
barweb([nanmean(IPSIMATCH_main(thaplt,:));nanmean(CONTRAMATCH_main(thaplt,:))]',[sem(IPSIMATCH_main(thaplt,:)); sem(CONTRAMATCH_main(thaplt,:))]',.8,cellfun(@num2str,num2cell(M1bins(2:end)),'UniformOutput',0),'Beta in VIM on go trials', 'time (ms) after BG burst', 'proportion of trials', '', '', {'ipsilateral stop','contralateral stop'});
subplot(1,3,3);
barweb([nanmean(D_IPSIMATCH_main(thaplt,:));nanmean(D_CONTRAMATCH_main(thaplt,:))]',[sem(D_IPSIMATCH_main(thaplt,:)); sem(D_CONTRAMATCH_main(thaplt,:))]',.8,cellfun(@num2str,num2cell(M1bins(2:end)),'UniformOutput',0),'Beta in Vop on go trials', 'time (ms) after BG burst', 'proportion of trials', '', '', {'ipsilateral stop','contralateral stop'});

% stats
for it = 1:length(M1bins)-1
    [STN_succp(it)] = mc_ttest(CONTRASUCC_main(stn,it),IPSISUCC_main(stn,it),10000);
    [VIM_succp(it)] = mc_ttest(CONTRASUCC_main(thaplt,it),IPSISUCC_main(thaplt,it),10000);    
    [VOP_succp(it)] = mc_ttest(D_CONTRASUCC_main(thaplt,it),D_IPSISUCC_main(thaplt,it),10000);    
    [STN_failp(it)] = mc_ttest(CONTRAFAIL_main(stn,it),IPSIFAIL_main(stn,it),10000);
    [VIM_failp(it)] = mc_ttest(CONTRAFAIL_main(thaplt,it),IPSIFAIL_main(thaplt,it),10000);  
    [VOP_failp(it)] = mc_ttest(D_CONTRAFAIL_main(thaplt,it),D_IPSIFAIL_main(thaplt,it),10000);  
    [STN_gop(it)] = mc_ttest(CONTRAGO_main(stn,it),IPSIGO_main(stn,it),10000);
    [VIM_gop(it)] = mc_ttest(CONTRAGO_main(thaplt,it),IPSIGO_main(thaplt,it),10000);    
    [VOP_gop(it)] = mc_ttest(D_CONTRAGO_main(thaplt,it),D_IPSIGO_main(thaplt,it),10000);    
    [STN_matchp(it)] = mc_ttest(CONTRAMATCH_main(stn,it),IPSIMATCH_main(stn,it),10000);
    [VIM_matchp(it)] = mc_ttest(CONTRAMATCH_main(thaplt,it),IPSIMATCH_main(thaplt,it),10000); 
    [VOP_matchp(it)] = mc_ttest(D_CONTRAMATCH_main(thaplt,it),D_IPSIMATCH_main(thaplt,it),10000); 
end
corrected_succ_STNp = bonf_holm(STN_succp); corrected_succ_VIMp = bonf_holm(VIM_succp); corrected_succ_VOPp = bonf_holm(VOP_succp);
corrected_fail_STNp = bonf_holm(STN_failp); corrected_fail_VIMp = bonf_holm(VIM_failp); corrected_fail_VOPp = bonf_holm(VOP_failp);
corrected_go_STNp = bonf_holm(STN_gop); corrected_go_VIMp = bonf_holm(VIM_gop); corrected_go_VOPp = bonf_holm(VOP_gop);
corrected_match_STNp = bonf_holm(STN_matchp); corrected_match_VIMp = bonf_holm(VIM_matchp); corrected_match_VOPp = bonf_holm(VOP_matchp);
disp('STN sample - Significant burst differences were seen for succ at these time points:');
for it = 1:length(M1bins)-1
    if corrected_succ_STNp(it)<=.05; disp([num2str(M1bins(it)) ' to ' num2str(M1bins(it+1)) 'ms: p = ' num2str(corrected_succ_STNp(it))]); end
end
disp('VIM sample - Significant burst differences were seen for succ at these time points:');
for it = 1:length(M1bins)-1
    if corrected_succ_VIMp(it)<=.05; disp([num2str(M1bins(it)) ' to ' num2str(M1bins(it+1)) 'ms: p = ' num2str(corrected_succ_VIMp(it))]); end
end
disp('VOP sample - Significant burst differences were seen for succ at these time points:');
for it = 1:length(M1bins)-1
    if corrected_succ_VOPp(it)<=.05; disp([num2str(M1bins(it)) ' to ' num2str(M1bins(it+1)) 'ms: p = ' num2str(corrected_succ_VOPp(it))]); end
end
disp('STN sample - Significant burst differences were seen for fail at these time points:');
for it = 1:length(M1bins)-1
    if corrected_fail_STNp(it)<=.05; disp([num2str(M1bins(it)) ' to ' num2str(M1bins(it+1)) 'ms: p = ' num2str(corrected_fail_STNp(it))]); end
end
disp('VIM sample - Significant burst differences were seen for fail at these time points:');
for it = 1:length(M1bins)-1
    if corrected_fail_VIMp(it)<=.05; disp([num2str(M1bins(it)) ' to ' num2str(M1bins(it+1)) 'ms: p = ' num2str(corrected_fail_VIMp(it))]); end
end
disp('VOP sample - Significant burst differences were seen for fail at these time points:');
for it = 1:length(M1bins)-1
    if corrected_fail_VOPp(it)<=.05; disp([num2str(M1bins(it)) ' to ' num2str(M1bins(it+1)) 'ms: p = ' num2str(corrected_fail_VOPp(it))]); end
end
disp('STN sample - Significant burst differences were seen for go at these time points:');
for it = 1:length(M1bins)-1
    if corrected_go_STNp(it)<=.05; disp([num2str(M1bins(it)) ' to ' num2str(M1bins(it+1)) 'ms: p = ' num2str(corrected_go_STNp(it))]); end
end
disp('VIM sample - Significant burst differences were seen for go at these time points:');
for it = 1:length(M1bins)-1
    if corrected_go_VIMp(it)<=.05; disp([num2str(M1bins(it)) ' to ' num2str(M1bins(it+1)) 'ms: p = ' num2str(corrected_go_VIMp(it))]); end
end
disp('VOP sample - Significant burst differences were seen for go at these time points:');
for it = 1:length(M1bins)-1
    if corrected_go_VOPp(it)<=.05; disp([num2str(M1bins(it)) ' to ' num2str(M1bins(it+1)) 'ms: p = ' num2str(corrected_go_VOPp(it))]); end
end
disp('STN sample - Significant burst differences were seen for match at these time points:');
for it = 1:length(M1bins)-1
    if corrected_match_STNp(it)<=.05; disp([num2str(M1bins(it)) ' to ' num2str(M1bins(it+1)) 'ms: p = ' num2str(corrected_match_STNp(it))]); end
end
disp('VIM sample - Significant burst differences were seen for match at these time points:');
for it = 1:length(M1bins)-1
    if corrected_match_VIMp(it)<=.05; disp([num2str(M1bins(it)) ' to ' num2str(M1bins(it+1)) 'ms: p = ' num2str(corrected_match_VIMp(it))]); end
end
disp('VOP sample - Significant burst differences were seen for match at these time points:');
for it = 1:length(M1bins)-1
    if corrected_match_VOPp(it)<=.05; disp([num2str(M1bins(it)) ' to ' num2str(M1bins(it+1)) 'ms: p = ' num2str(corrected_match_VOPp(it))]); end
end