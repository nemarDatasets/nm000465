function [datasets] = create_datasets_structure(folders)
% This function takes folder paths as inputs and searches those folders for
% datasets with all required file types (ephys, behavior). It outputs a
% structure that stores subject numbers and file names for loading.

% pull lists  of all relevant files
temp = dir(fullfile(folders.behav,'*.mat'));
files.behav.stopor = {temp.name};
temp = dir(fullfile(folders.behavloc,'*.mat'));
files.behav.localizer = {temp.name};
temp = dir(fullfile(folders.raw,'*.mat'));
files.raw.stopor = {temp.name};

lcnt = 0;
for itbm = 1:length(files.behav.stopor) % for each behavioral file
    % Send filenames for corresponding localizer and eeg to new datasets structure
    datasets(itbm).behav = files.behav.stopor(1,itbm);
    if isempty(intersect(itbm,[7 11 23]))
        lcnt = lcnt + 1;
        datasets(itbm).localizer = files.behav.localizer(1,lcnt);
    end
    datasets(itbm).eeg = files.raw.stopor(1,itbm);
    
    % Extract subnums from behavioral filename
    behavnum = char(datasets(itbm).behav);
    behavnum = behavnum(9:11);
    datasets(itbm).subnum = behavnum;   
    
end