%% Test difference in beta counts for ss vs fs in SSD-SSRT delay
% This section counts the number of bursts between SSD and SSRT for each
% trial type. 

% preassign
StoptoSSRT = zeros(length(datasets),5);
dorsal_StoptoSSRT = zeros(length(datasets),5);

for is = 1:length(datasets) % for each subject
     clear trials dorsal_trials;
    % load
    subnum = datasets(is).subnum;
    load(fullfile(folders.beta,['Subject' num2str(subnum) '.mat']));
    
    sub_SSRT = SSRT; 
    
    % identify channels
    % assign VIM [THIS DEFAULTS TO STN FOR 104 (which has both VIM and STN)]
    if sum(~cellfun(@isempty,strfind(chanlabels,'rvim'))) == 1
        rbgchan = ~cellfun(@isempty,strfind(chanlabels,'rvim'));
        lbgchan = ~cellfun(@isempty,strfind(chanlabels,'lvim'));
        eval(['trialsbgl = trialevs.' chanlabels{rbgchan} ';']);
        eval(['trialsbgr = trialevs.' chanlabels{lbgchan} ';']);
    end
    % assign STN [THIS DEFAULTS TO STN FOR 104 (which has both VIM and STN)]
    if sum(~cellfun(@isempty,strfind(chanlabels,'rstn'))) == 1
        rbgchan = ~cellfun(@isempty,strfind(chanlabels,'rstn'));
        lbgchan = ~cellfun(@isempty,strfind(chanlabels,'lstn'));
        eval(['trialsbgl = trialevs.' chanlabels{rbgchan} ';']);
        eval(['trialsbgr = trialevs.' chanlabels{lbgchan} ';']);
    end
    % combine left and right bg
    trialnumbers = fieldnames(trialsbgl);
    for itt = 1:length(trialnumbers)
        eval(['trials.' trialnumbers{itt} ' = [trialsbgl.' trialnumbers{itt} ' trialsbgr.' trialnumbers{itt} '];']);
    end

    if ~isempty(intersect(is,tha))
        load(fullfile(folders.beta,['Subject' num2str(subnum) '_dorsal.mat']));
    
        if sum(~cellfun(@isempty,strfind(chanlabels,'lvim'))) == 1
            if is~= 2; rbgchan = ~cellfun(@isempty,strfind(chanlabels,'rvim')); end
            lbgchan = ~cellfun(@isempty,strfind(chanlabels,'lvim'));
            if is~= 2; eval(['dorsal_trialsbgl = trialevs.' chanlabels{rbgchan} ';']); end
            eval(['dorsal_trialsbgr = trialevs.' chanlabels{lbgchan} ';']);
        end
        for itt = 1:length(trialnumbers)
            if is~=2
                eval(['dorsal_trials.' trialnumbers{itt} ' = [dorsal_trialsbgl.' trialnumbers{itt} ' dorsal_trialsbgr.' trialnumbers{itt} '];']);
            else
                eval(['dorsal_trials.' trialnumbers{itt} ' = [dorsal_trialsbgr.' trialnumbers{itt} '];']);
            end
        end
    end
    % preassign
    pre_SSRT = zeros(length(fieldnames(trials)),1);
    dorsal_pre_SSRT = pre_SSRT;
    
    % go through trials
    for it = 1:length(fieldnames(trials))

        % get events
        eval(['evs = trials.t' num2str(it) ';']);
        evs(evs<=2) = [];
        if ~isempty(intersect(is,tha))
            eval(['devs = dorsal_trials.t' num2str(it) ';']);
            devs(devs<=2) = [];
        end
        % if there are events
        if ~isempty(evs)
            
            % get pre-SSRT data (timewindow from event to SSRT)
            % if a go trial, grab ssd to SSRT
            if accuracy(it) == 1
                pre_SSRT(it) = sum(evs>ssd(it) & evs<ssd(it)+sub_SSRT);
            else
                pre_SSRT(it) = sum(evs<sub_SSRT);
            end
            
        end
        % if there are events in dorsal thal
        if ~isempty(intersect(is,tha))
            if ~isempty(devs)
                
                % get pre-SSRT data (timewindow from event to SSRT)
                % if a go trial, grab ssd to SSRT
                if accuracy(it) == 1
                    dorsal_pre_SSRT(it) = sum(devs>ssd(it) & devs<ssd(it)+sub_SSRT);
                else
                    dorsal_pre_SSRT(it) = sum(devs<sub_SSRT);
                end
                
            end
        end
    end
    % sort by accuracy
    StoptoSSRT(is,1) = mean(pre_SSRT(accuracy==3,1));
    StoptoSSRT(is,2) = mean(pre_SSRT(accuracy==4,1));
    if ~isempty(intersect(is,tha))
    dorsal_StoptoSSRT(is,1) = mean(dorsal_pre_SSRT(accuracy==3,1));
    dorsal_StoptoSSRT(is,2) = mean(dorsal_pre_SSRT(accuracy==4,1));
    end
    stops = find(accuracy == 3 | accuracy == 4);
    
    slowcnt = 0; fastcnt = 0; slowdcnt = 0; fastdcnt = 0;
    for ie = 1:length(stops) % get count for the matched go trial
        match = find(ssd-ssd(stops(ie)) == 0 & accuracy == 1); nextgo = match(find(match>stops(ie),1,'first'));
        % if fails, flip and find most recent before
        if isempty(nextgo); match = find(ssd-ssd(stops(ie)) == 0 & accuracy == 1); nextgo = match(find(match<stops(ie),1,'last')); end
        % if failed, pick first go trial w/ SSD w/in 50ms
        if isempty(nextgo); nextgo = find(ssd-ssd(stops(ie)) == 50 | ssd-ssd(stops(ie)) == -50 & accuracy == 1,1,'first'); end
        %matched_gos(ie) = pre_SSRT(nextgo);
        gorts = rt(accuracy==1);
        if rt(nextgo) > median(gorts) % slow rt
            slowcnt = slowcnt + 1;
            slow_matched_gos(slowcnt) = pre_SSRT(nextgo);
        else % fast rt
            fastcnt = fastcnt + 1;
            fast_matched_gos(fastcnt) = pre_SSRT(nextgo);
        end
        if ~isempty(intersect(is,tha))
            if rt(nextgo) > median(gorts) % slow rt
                slowdcnt = slowdcnt + 1;
                slow_dorsal_matched_gos(slowdcnt) = dorsal_pre_SSRT(nextgo);
            else
                fastdcnt = fastdcnt + 1;
                fast_dorsal_matched_gos(fastdcnt) = dorsal_pre_SSRT(nextgo);
            end
        end
    end
    StoptoSSRT(is,3) = mean(slow_matched_gos);
    StoptoSSRT(is,4) = mean(fast_matched_gos);
    StoptoSSRT(is,5) = sub_SSRT;
    if ~isempty(intersect(is,tha))
    dorsal_StoptoSSRT(is,3) = mean(slow_dorsal_matched_gos);
    dorsal_StoptoSSRT(is,4) = mean(fast_dorsal_matched_gos);
    dorsal_StoptoSSRT(is,5) = sub_SSRT;    
    end
end 

% figure: STN
figure('Color','w'); 
subplot(2,1,1);
clear s; 
s.ss = StoptoSSRT(stn,1); s.fs = StoptoSSRT(stn,2); s.slowgo = StoptoSSRT(stn,3); s.fastgo = StoptoSSRT(stn,4); barplot(s);
xlabel('Trialtype'); ylabel('Beta bursts before SSRT'); title('STN');
% color lines
c = get(gca,'Children'); for ic = 1:length(c); if strcmpi(class(c(ic)),'matlab.graphics.primitive.Line') && c(ic).Color(1) == .7; set(c(ic),'Color',[1 .5 0]); end; end
c = get(gca,'Children'); for ic = 1:length(c); if strcmpi(class(c(ic)),'matlab.graphics.chart.primitive.Scatter') && c(ic).MarkerEdgeColor(1) == .7; set(c(ic),'MarkerEdgeColor',[1 .5 0]); end; end
set(gca,'Ylim',[0 2.5]);

% figure: VIM
subplot(2,1,2);
clear s; 
s.ss = StoptoSSRT(tha,1); s.fs = StoptoSSRT(tha,2); s.slowgo = StoptoSSRT(tha,3); s.fastgo = StoptoSSRT(tha,4); barplot(s);
xlabel('Trialtype'); ylabel('Beta bursts before SSRT'); title('VIM');
% color lines
c = get(gca,'Children'); for ic = 1:length(c); if strcmpi(class(c(ic)),'matlab.graphics.primitive.Line') && c(ic).Color(1) == .7; set(c(ic),'Color',[0 .3 0]); end; end
c = get(gca,'Children'); for ic = 1:length(c); if strcmpi(class(c(ic)),'matlab.graphics.chart.primitive.Scatter') && c(ic).MarkerEdgeColor(1) == .7; set(c(ic),'MarkerEdgeColor',[0 .3 0]); end; end
set(gca,'Ylim',[0 2.5]);

% figure: dorsal thalamus
figure('Color','w'); 
clear s; 
s.ss = dorsal_StoptoSSRT(tha,1); s.fs = dorsal_StoptoSSRT(tha,2); s.slowgo = dorsal_StoptoSSRT(tha,3); s.fastgo = dorsal_StoptoSSRT(tha,4); barplot(s);
xlabel('Trialtype'); ylabel('Beta bursts before SSRT'); title('Dorsal thalamus');
% color lines
c = get(gca,'Children'); for ic = 1:length(c); if strcmpi(class(c(ic)),'matlab.graphics.primitive.Line') && c(ic).Color(1) == .7; set(c(ic),'Color',[0 .3 0]); end; end
c = get(gca,'Children'); for ic = 1:length(c); if strcmpi(class(c(ic)),'matlab.graphics.chart.primitive.Scatter') && c(ic).MarkerEdgeColor(1) == .7; set(c(ic),'MarkerEdgeColor',[0 .3 0]); end; end
set(gca,'Ylim',[0 2.5]);

% stats
% Set up and run one-way ANOVA with bootstrapping
% set up ANOVA - subjects as lines, factors as columns (column 1 is DV val,
% 2 is IV code, 3 is subnum)
STN_mat = StoptoSSRT(stn,1:4);
VIM_mat = StoptoSSRT(tha,1:4);
dorsalthal_mat = dorsal_StoptoSSRT(tha,1:4);
perm = 10000;
disp(['Please wait... completing permutation...']);
for ip = 1:perm
    permstats = [];
    STN_mat_rand = reshape(STN_mat(randperm(numel(STN_mat))),size(STN_mat));
    VIM_mat_rand = reshape(VIM_mat(randperm(numel(VIM_mat))),size(VIM_mat));
    dor_mat_rand = reshape(dorsalthal_mat(randperm(numel(dorsalthal_mat))),size(dorsalthal_mat));

    perm_stats = rm_anova1(STN_mat_rand);
    STN_typeF(ip) = perm_stats.F;
    
    perm_stats = rm_anova1(VIM_mat_rand);
    VIM_typeF(ip) = perm_stats.F;
    
    perm_stats = rm_anova1(dor_mat_rand);
    dorsal_typeF(ip) = perm_stats.F;
end
% define sig cutoff based on permutations
STN_typecutoff = quantile(STN_typeF,0.95); VIM_typecutoff = quantile(VIM_typeF,0.95);
dor_typecutoff = quantile(dorsal_typeF,0.95);
% do real ANOVA
final_STNstats = rm_anova1(STN_mat);
final_VIMstats = rm_anova1(VIM_mat);
final_dorsalstats = rm_anova1(dorsalthal_mat);

disp('Significant effects in STN sample: ');
if final_STNstats.F > STN_typecutoff
    disp(['Trial type: F = ' num2str(final_STNstats.F) ', p = ' num2str(final_STNstats.p)]);
end
disp('Significant effects in VIM sample: ');
if final_VIMstats.F > VIM_typecutoff
    disp(['Trial type: F = ' num2str(final_VIMstats.F) ', p = ' num2str(final_VIMstats.p)]);
end
disp('Significant effects in dorsal thalamus sample: ');
if final_dorsalstats.F > dor_typecutoff
    disp(['Trial type: F = ' num2str(final_dorsalstats.F) ', p = ' num2str(final_dorsalstats.p)]);
end
% follow up with paired tests
[~,STN_gop] = ttest(StoptoSSRT(stn,1),StoptoSSRT(stn,3));
[~,VIM_gop] = ttest(StoptoSSRT(tha,1),StoptoSSRT(tha,3));
[~,STN_fastgop] = ttest(StoptoSSRT(stn,2),StoptoSSRT(stn,4));
[~,VIM_fastgop] = ttest(StoptoSSRT(tha,2),StoptoSSRT(tha,4));
[~,STN_failp] = ttest(StoptoSSRT(stn,1),StoptoSSRT(stn,2));
[~,VIM_failp] = ttest(StoptoSSRT(tha,1),StoptoSSRT(tha,2));
[~,dorsal_gop] = ttest(dorsal_StoptoSSRT(tha,1),dorsal_StoptoSSRT(tha,3));
[~,dorsal_fastgop] = ttest(dorsal_StoptoSSRT(tha,2),dorsal_StoptoSSRT(tha,4));
[~,dorsal_failp] = ttest(dorsal_StoptoSSRT(tha,1),dorsal_StoptoSSRT(tha,2));

if STN_gop < .05
    disp(['STN sample: More beta bursts in SSD-SSRT delay for SS compared to slow go: p = ' num2str(STN_gop)]);
end
if STN_fastgop < .05
    disp(['STN sample: More beta bursts in SSD-SSRT delay for FS compared to fast go: p = ' num2str(STN_fastgop)]);
end
if STN_failp < .05
    disp(['STN sample: More beta bursts in SSD-SSRT delay for SS compared to FS: p = ' num2str(STN_failp)]);
end
if VIM_gop < .05
    disp(['VIM sample: More beta bursts in SSD-SSRT delay for SS compared to slow go: p = ' num2str(VIM_gop)]);
end
if VIM_fastgop < .05
    disp(['VIM sample: More beta bursts in SSD-SSRT delay for FS compared to fast go: p = ' num2str(VIM_fastgop)]);
end
if VIM_failp < .05
    disp(['VIM sample: More beta bursts in SSD-SSRT delay for SS compared to FS: p = ' num2str(VIM_failp)]);
end
if dorsal_gop < .05
    disp(['Dorsal thalamus: More beta bursts in SSD-SSRT delay for SS compared to slow go: p = ' num2str(dorsal_gop)]);
end
if dorsal_fastgop < .05
    disp(['Dorsal thalamus: More beta bursts in SSD-SSRT delay for FS compared to fast go: p = ' num2str(dorsal_fastgop)]);
end
if dorsal_failp < .05
    disp(['Dorsal thalamus: More beta bursts in SSD-SSRT delay for SS compared to FS: p = ' num2str(dorsal_failp)]);
end