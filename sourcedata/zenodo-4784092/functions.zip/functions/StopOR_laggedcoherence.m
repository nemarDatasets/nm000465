%% Initialize
ftfolder = fullfile(folders.base,'fieldtrip');

%% Convert data to FT format
for is = 1:length(datasets)
    dataRSTN = []; dataLSTN = [];
    dataRVOP = []; dataLVOP = [];
    dataRVIM = []; dataLVIM = [];
    dataC3 = []; dataC4 = [];
    
    % load epoched data from beta ev file
    load(fullfile(folders.beta,['Subject' datasets(is).subnum '.mat']));
    
    % SMC
    % right
    RM1 = pop_rmbase(RM1,[-500 0]);
    % convert to field trip
    dataC4 = eeglab2fieldtrip(RM1,'preprocessing','none');
    dataC4.cfg.channel = {'RM1'};
    
    % left
    LM1 = pop_rmbase(LM1,[-500 0]);
    % convert to field trip
    dataC3 = eeglab2fieldtrip(LM1,'preprocessing','none');
    dataC3.cfg.channel = {'LM1'}; 
    
    if ~isempty(intersect(is,stn))
    
        % STN
        % right
        RSTN = pop_rmbase(RSTN,[-500 0]);
        % convert to field trip
        dataRSTN = eeglab2fieldtrip(RSTN,'preprocessing','none');
        dataRSTN.cfg.channel = {'RSTN'}; 
        % left
        LSTN = pop_rmbase(LSTN,[-500 0]);
        % convert to field trip
        dataLSTN = eeglab2fieldtrip(LSTN,'preprocessing','none');
        dataLSTN.cfg.channel = {'LSTN'}; 
        
    else
        
        % ventral thal
        % right
        RVIM = pop_rmbase(RVIM,[-500 0]);
        % convert to field trip
        dataRVIM = eeglab2fieldtrip(RVIM,'preprocessing','none');
        dataRVIM.cfg.channel = {'RVIM'}; 
        
        % left
        LVIM = pop_rmbase(LVIM,[-500 0]);
        % convert to field trip
        dataLVIM = eeglab2fieldtrip(LVIM,'preprocessing','none');
        dataLVIM.cfg.channel = {'LVIM'}; 
        
        % load data for dorsal thal
        load(fullfile(folders.beta,['Subject' datasets(is).subnum '_dorsal.mat']));
        
        % dorsal thal
        % right
        RVOP = pop_rmbase(RVIM,[-500 0]);
        % convert to field trip
        dataRVOP = eeglab2fieldtrip(RVOP,'preprocessing','none');
        dataRVOP.cfg.channel = {'RVOP'};
        
        % left
        LVOP = pop_rmbase(LVIM,[-500 0]);
        % convert to field trip
        dataLVOP = eeglab2fieldtrip(LVOP,'preprocessing','none');
        dataLVOP.cfg.channel = {'LVOP'}; 
        
    end
    
    % save
    save(fullfile(ftfolder,['Subject' datasets(is).subnum '-ft_new.mat']),'dataLSTN','dataRSTN','dataRVIM','dataLVIM','dataLVOP','dataRVOP','dataC3','dataC4');
    % delete new and rerun
end

%% Computation of lagged coherence spectrum (workaround wrapper function to account for not-yet-optimized fieldtrip implementation)
% Works on data matrix (data, dataC3, dataC4) in FT format. Files prepped
% for lagged coherence only contain data from chans to be analyzed.
% settings
cfg = [];
cfg.method = 'wavelet';
cfg.output = 'fourier';
cfg.foi    = 5:1:40;
%cfg.t_ftimwin = ones(1,numel(cfg.foi))./2;
cfg.taper  = 'hanning';
fs = 500;
cycles = 1:3;
% preassign
laggedCohRSTN = zeros(length(datasets),length(cfg.foi),length(cycles));
laggedCohLSTN = laggedCohRSTN; laggedCohRVIM = laggedCohRSTN;
laggedCohLVIM = laggedCohRSTN; laggedCohRVOP = laggedCohRSTN;
laggedCohC3 = laggedCohRSTN; laggedCohC4 = laggedCohRSTN;
laggedCohLVOP = laggedCohRSTN; 

% go through subj
for is = 1:length(datasets)
    
    % load
    load(fullfile(ftfolder,['Subject' datasets(is).subnum '-ft_new.mat'])); % delete new
    
    % go through cycles
    for ic = 1:length(cycles)

        % go through freq
        for ifr = 1:length(cfg.foi)

            % C3
            % freq
            width = cycles(ic)/cfg.foi(ifr); cfg.width = width;
            cfg.toi = dataC3.time{1}(1) + ceil(fs*width/2)/fs : ...  
                 width : ...                      
                 dataC3.time{1}(end) - ceil(fs*width/2)/fs; 
            freq = ft_freqanalysis(cfg, dataC3);

            % lagged coherence
            cfg_LC = [];
            cfg_LC.method = 'laggedcoherence';
            cfg_LC.laggedcoherence.lags = width;
            lcoh = ft_connectivityanalysis(cfg_LC, freq);

            % store coherence at custom lag
            laggedCohC3(is,ifr,ic) = lcoh.lcohspctrm(ifr);

            % C4
            % freq
            width = cycles(ic)/cfg.foi(ifr); cfg.width = width;
            cfg.toi = dataC4.time{1}(1) + ceil(fs*width/2)/fs : ...  
                 width : ...                      
                 dataC4.time{1}(end) - ceil(fs*width/2)/fs; 
            freq = ft_freqanalysis(cfg, dataC4);

            % lagged coherence
            cfg_LC = [];
            cfg_LC.method = 'laggedcoherence';
            cfg_LC.laggedcoherence.lags = width;
            lcoh = ft_connectivityanalysis(cfg_LC, freq);

            % store coherence at custom lag
            laggedCohC4(is,ifr,ic) = lcoh.lcohspctrm(ifr);
            
            if ~isempty(intersect(is,stn))
                % RSTN
                % freq
                width = cycles(ic)/cfg.foi(ifr); cfg.width = width;
                cfg.toi = dataRSTN.time{1}(1) + ceil(fs*width/2)/fs : ...
                    width : ...
                    dataRSTN.time{1}(end) - ceil(fs*width/2)/fs;
                freq = ft_freqanalysis(cfg, dataRSTN);
                
                % lagged coherence
                cfg_LC = [];
                cfg_LC.method = 'laggedcoherence';
                cfg_LC.laggedcoherence.lags = width;
                lcoh = ft_connectivityanalysis(cfg_LC, freq);
                
                % store coherence at custom lag
                laggedCohRSTN(is,ifr,ic) = lcoh.lcohspctrm(ifr);
                
                % LSTN
                % freq
                width = cycles(ic)/cfg.foi(ifr); cfg.width = width;
                cfg.toi = dataLSTN.time{1}(1) + ceil(fs*width/2)/fs : ...
                    width : ...
                    dataLSTN.time{1}(end) - ceil(fs*width/2)/fs;
                freq = ft_freqanalysis(cfg, dataLSTN);
                
                % lagged coherence
                cfg_LC = [];
                cfg_LC.method = 'laggedcoherence';
                cfg_LC.laggedcoherence.lags = width;
                lcoh = ft_connectivityanalysis(cfg_LC, freq);
                
                % store coherence at custom lag
                laggedCohLSTN(is,ifr,ic) = lcoh.lcohspctrm(ifr);
                
            else
                
                % RVIM
                % freq
                width = cycles(ic)/cfg.foi(ifr); cfg.width = width;
                cfg.toi = dataRVIM.time{1}(1) + ceil(fs*width/2)/fs : ...
                    width : ...
                    dataRVIM.time{1}(end) - ceil(fs*width/2)/fs;
                freq = ft_freqanalysis(cfg, dataRVIM);
                
                % lagged coherence
                cfg_LC = [];
                cfg_LC.method = 'laggedcoherence';
                cfg_LC.laggedcoherence.lags = width;
                lcoh = ft_connectivityanalysis(cfg_LC, freq);
                
                % store coherence at custom lag
                laggedCohRVIM(is,ifr,ic) = lcoh.lcohspctrm(ifr);
                
                % LVIM
                % freq
                width = cycles(ic)/cfg.foi(ifr); cfg.width = width;
                cfg.toi = dataLVIM.time{1}(1) + ceil(fs*width/2)/fs : ...
                    width : ...
                    dataLVIM.time{1}(end) - ceil(fs*width/2)/fs;
                freq = ft_freqanalysis(cfg, dataLVIM);
                
                % lagged coherence
                cfg_LC = [];
                cfg_LC.method = 'laggedcoherence';
                cfg_LC.laggedcoherence.lags = width;
                lcoh = ft_connectivityanalysis(cfg_LC, freq);
                
                % store coherence at custom lag
                laggedCohLVIM(is,ifr,ic) = lcoh.lcohspctrm(ifr);
                
                % RVOP
                % freq
                width = cycles(ic)/cfg.foi(ifr); cfg.width = width;
                cfg.toi = dataRVOP.time{1}(1) + ceil(fs*width/2)/fs : ...
                    width : ...
                    dataRVOP.time{1}(end) - ceil(fs*width/2)/fs;
                freq = ft_freqanalysis(cfg, dataRVOP);
                
                % lagged coherence
                cfg_LC = [];
                cfg_LC.method = 'laggedcoherence';
                cfg_LC.laggedcoherence.lags = width;
                lcoh = ft_connectivityanalysis(cfg_LC, freq);
                
                % store coherence at custom lag
                laggedCohRVOP(is,ifr,ic) = lcoh.lcohspctrm(ifr);
                
                % LVOP
                % freq
                width = cycles(ic)/cfg.foi(ifr); cfg.width = width;
                cfg.toi = dataLVOP.time{1}(1) + ceil(fs*width/2)/fs : ...
                    width : ...
                    dataLVOP.time{1}(end) - ceil(fs*width/2)/fs;
                freq = ft_freqanalysis(cfg, dataLVOP);
                
                % lagged coherence
                cfg_LC = [];
                cfg_LC.method = 'laggedcoherence';
                cfg_LC.laggedcoherence.lags = width;
                lcoh = ft_connectivityanalysis(cfg_LC, freq);
                
                % store coherence at custom lag
                laggedCohLVOP(is,ifr,ic) = lcoh.lcohspctrm(ifr);
            end

        end % of freq
        
    end % of cycles

end % of subjects
% save
save(fullfile(ftfolder,'laggedCohCOMPLETE_new.mat'),'laggedCohLSTN','laggedCohRSTN','laggedCohRVIM','laggedCohLVIM','laggedCohRVOP','laggedCohLVOP','laggedCohC3','laggedCohC4');

%% figure
h = figure('Position',[1 1 1000 400],'color','w'); clim = zeros(3,2);
% subplot
subplot(2,4,1); imagesc(squeeze(mean(laggedCohRSTN,1))); title('RSTN'); clim(1,:) = get(gca,'Clim');
subplot(2,4,2); imagesc(squeeze(mean(laggedCohLSTN,1))); title('LSTN'); clim(1,:) = get(gca,'Clim');
subplot(2,4,3); imagesc(squeeze(mean(laggedCohRSTN,1))); title('RVIM'); clim(1,:) = get(gca,'Clim');
subplot(2,4,4); imagesc(squeeze(mean(laggedCohLSTN,1))); title('LVIM'); clim(1,:) = get(gca,'Clim');
subplot(2,4,5); imagesc(squeeze(mean(laggedCohRSTN,1))); title('RVOP'); clim(1,:) = get(gca,'Clim');
subplot(2,4,6); imagesc(squeeze(mean(laggedCohLSTN,1))); title('LVOP'); clim(1,:) = get(gca,'Clim');
subplot(2,4,7); imagesc(squeeze(mean(laggedCohC3,1))); title('C3'); clim(2,:) = get(gca,'Clim');
subplot(2,4,8); imagesc(squeeze(mean(laggedCohC4,1))); title('C4'); clim(3,:) = get(gca,'Clim');
% format
for ip = 1:8; subplot(2,4,ip);
    set(gca,'Ytick',1:2:length(cfg.foi),'Yticklabel',num2cell(cfg.foi(1:2:end)),'YDir','normal','Clim',[0 max(max(abs(clim)))]);
    xlabel('Cycles'); ylabel('Frequency (Hz)'); colorbar('EastOutside');
end
%% figure
h = figure('Position',[1 1 1000 400],'color','w'); 
% subplot
subplot(2,4,1); plot(squeeze(mean(laggedCohRSTN(:,:,3),1))); title('RSTN'); 
subplot(2,4,2); plot(squeeze(mean(laggedCohLSTN(:,:,3),1))); title('LSTN'); 
subplot(2,4,3); plot(squeeze(mean(laggedCohRVIM(:,:,3),1))); title('RVIM'); 
subplot(2,4,4); plot(squeeze(mean(laggedCohLVIM(:,:,3),1))); title('LVIM'); 
subplot(2,4,5); plot(squeeze(mean(laggedCohRVOP(:,:,3),1))); title('RVOP'); 
subplot(2,4,6); plot(squeeze(mean(laggedCohLVOP(:,:,3),1))); title('LVOP'); 
subplot(2,4,7); plot(squeeze(mean(laggedCohC3(:,:,3),1))); title('C3'); 
subplot(2,4,8); plot(squeeze(mean(laggedCohC4(:,:,3),1))); title('C4'); 
% format
for ip = 1:8; subplot(2,4,ip);
    set(gca,'Xtick',1:8:length(cfg.foi),'Xticklabel',num2cell(cfg.foi(1:8:end)),'YLim',[0 .5]);
    xlabel('Frequency (Hz)'); ylabel('Coherence');
end