%% Determine first occurrence of event at each recording site
% This section finds the first beta bursts occuring at each recording site
% and sorts them by trial type.
% preallocations
BG_EV = zeros(length(datasets),4);
BG_EV_SSRT = BG_EV; M1_EV_SSRT = BG_EV;
VOP_EV_SSRT = BG_EV; M1_EV = BG_EV;
sub_SSRT = zeros(length(datasets),1);
VIM_EV = zeros(1,4);
VOP_EV = BG_EV;

for is = 1:length(datasets) % for each subject
    
    clear trials* trialevs* blevs* d_trials* 
    subnum = datasets(is).subnum;
    
    % load beta event indices
    load(fullfile(folders.beta,['Subject' num2str(subnum) '.mat']));
            
    % assign channels
    % assign VIM [THIS DEFAULT TO STN FOR 104 (which has both VIM and STN)]
    if sum(~cellfun(@isempty,strfind(chanlabels,'rvim'))) == 1
        rbgchan = ~cellfun(@isempty,strfind(chanlabels,'rvim'));
        lbgchan = ~cellfun(@isempty,strfind(chanlabels,'lvim'));
        eval(['trialsbgl = trialevs.' chanlabels{rbgchan} ';']);
        eval(['trialsbgr = trialevs.' chanlabels{lbgchan} ';']);
    end
    % assign STN [THIS DEFAULT TO STN FOR 104 (which has both VIM and STN)]
    if sum(~cellfun(@isempty,strfind(chanlabels,'rstn'))) == 1
        rbgchan = ~cellfun(@isempty,strfind(chanlabels,'rstn'));
        lbgchan = ~cellfun(@isempty,strfind(chanlabels,'lstn'));
        eval(['trialsbgl = trialevs.' chanlabels{rbgchan} ';']);
        eval(['trialsbgr = trialevs.' chanlabels{lbgchan} ';']);
    end
    
    % combine left and right bg
    trialnumbers = fieldnames(trialsbgl); clear trials;
    for itt = 1:length(trialnumbers)
        eval(['trialsbg.' trialnumbers{itt} ' = [trialsbgl.' trialnumbers{itt} ' trialsbgr.' trialnumbers{itt} '];']);
    end
    
    % get SMC channels
    rightmotor = chanlabels{~cellfun(@isempty,strfind(chanlabels,'rm1'))};
    leftmotor = chanlabels{~cellfun(@isempty,strfind(chanlabels,'lm1'))};
    eval(['trialsc3 = trialevs.' leftmotor ';']);
    eval(['trialsc4 = trialevs.' rightmotor ';']);
    % combine left and right m1 because stopping-related bursts are likely
    % to be bilateral
    trialnumbers = fieldnames(trialsc3); clear trials;
    for itt = 1:length(trialnumbers)
        eval(['trialsm1.' trialnumbers{itt} ' = [trialsc3.' trialnumbers{itt} ' trialsc4.' trialnumbers{itt} '];']);
    end
    
    if ~isempty(intersect(is,tha))
        load(fullfile(folders.beta,['Subject' num2str(subnum) '_dorsal.mat']));
        if sum(~cellfun(@isempty,strfind(chanlabels,'lvim'))) == 1
            if is ~= 2; rbgchan = ~cellfun(@isempty,strfind(chanlabels,'rvim')); end
            lbgchan = ~cellfun(@isempty,strfind(chanlabels,'lvim'));
            eval(['d_trialsbgl = trialevs.' chanlabels{rbgchan} ';']);
            if is ~= 2; eval(['d_trialsbgr = trialevs.' chanlabels{lbgchan} ';']); end
        end
        trialnumbers = fieldnames(d_trialsbgl); clear trials;
        for itt = 1:length(trialnumbers)
            if is~= 2
                eval(['d_trialsbg.' trialnumbers{itt} ' = [d_trialsbgl.' trialnumbers{itt} ' d_trialsbgr.' trialnumbers{itt} '];']);
            else
                eval(['d_trialsbg.' trialnumbers{itt} ' = [d_trialsbgl.' trialnumbers{itt} '];']);
            end
        end
    end
    
    % presets
    bg_ss_ev = []; ssev = 0; bg_fs_ev = []; fsev = 0;
    bg_go_ev = []; goev = 0; bg_m_ev = []; mev = 0;
    m1_ss_ev = []; m1ssev = 0; m1_fs_ev = []; m1fsev = 0;
    m1_go_ev = []; m1goev = 0; m1_m_ev = []; m1mev = 0;
    d_bg_ss_ev = []; dssev = 0; d_bg_fs_ev = []; dfsev = 0;
    d_bg_go_ev = []; dgoev = 0; d_bg_m_ev = []; dmev = 0;    
    
    for it = 1:length(fieldnames(trialsbg)) % for each trial where there were bg bursts
        nextgo = []; match_evs = []; match = [];
        
        % if a stop trial, identify a go trial w/ similar or same
        % SSD
        if accuracy(it) == 3 || accuracy(it) == 4
            % try to pick matched go with same SSD soon after this
            % trial
            match = find(ssd-ssd(it) == 0 & accuracy == 1); nextgo = match(find(match>it,1,'first'));
            % if failed, pick first go trial w/ same SSD in exp
            if isempty(nextgo); nextgo = find(ssd-ssd(it) == 0 & accuracy == 1,1,'first'); end
            % if failed, pick first go trial w/ SSD w/in 50ms
            if isempty(nextgo); nextgo = find(ssd-ssd(it) == 50 | ssd-ssd(it) == -50 & accuracy == 1,1,'first'); end
            eval(['match_evs = trialsbg.t' num2str(nextgo) ';']);
        end
        
        % get events from that trial
        eval(['evs = trialsbg.t' num2str(it) ';']); evs(evs<=2)  = [];

        if ~isempty(evs)
            
            % store latency of first burst for each trial
            if accuracy(it) == 4
                fsev = fsev + 1;
                bg_fs_ev(fsev,:) = evs(1);
            end
            if accuracy(it) == 3
                ssev = ssev + 1;
                bg_ss_ev(ssev,:) = evs(1);
            end
            if accuracy(it) == 1
                goev = goev+1;
                bg_go_ev(goev) = evs(1);
            end
        end
        
        % if there are events during a matched go trial
        match_evs = match_evs(match_evs>ssd(nextgo)); match_evs(match_evs<=2) = [];
        if ~isempty(match_evs)
            % sort according to accuracy and side
            if accuracy(nextgo) == 1
                mev = mev+1;
                bg_m_ev(mev) = match_evs(1)-ssd(nextgo);
            end
        end
    end
    
    for it = 1:length(fieldnames(trialsm1)) % for each trial where there were m1 bursts
        nextgo = []; match_evs = []; match = [];
        
        % if a stop trial, identify a go trial w/ similar or same
        % SSD
        if accuracy(it) == 3 || accuracy(it) == 4
            % try to pick matched go with same SSD soon after this
            % trial
            match = find(ssd-ssd(it) == 0 & accuracy == 1); nextgo = match(find(match>it,1,'first'));
            % if failed, pick first go trial w/ same SSD in exp
            if isempty(nextgo); nextgo = find(ssd-ssd(it) == 0 & accuracy == 1,1,'first'); end
            % if failed, pick first go trial w/ SSD w/in 50ms
            if isempty(nextgo); nextgo = find(ssd-ssd(it) == 50 | ssd-ssd(it) == -50 & accuracy == 1,1,'first'); end
            eval(['match_evs = trialsm1.t' num2str(nextgo) ';']);
        end
        
        % get events from that trial
        eval(['evs = trialsm1.t' num2str(it) ';']); evs(evs<=2)  = [];

        if ~isempty(evs)
            
            % store latency of first burst for each trial
            if accuracy(it) == 4
                m1fsev = m1fsev + 1;
                m1_fs_ev(m1fsev,:) = evs(1);
            end
            if accuracy(it) == 3
                m1ssev = m1ssev + 1;
                m1_ss_ev(m1ssev,:) = evs(1);
            end
            if accuracy(it) == 1
                m1goev = m1goev+1;
                m1_go_ev(m1goev) = evs(1);
            end
        end
        
        % if there are events during a matched go trial
        match_evs = match_evs(match_evs>ssd(nextgo)); match_evs(match_evs<=2) = [];
        if ~isempty(match_evs)
            % sort according to accuracy and side
            if accuracy(nextgo) == 1
                m1mev = m1mev+1;
                m1_m_ev(m1mev) = match_evs(1)-ssd(nextgo);
            end
        end
    end    
    
    % do again for dorsal thalamus channels
    if ~isempty(intersect(is,tha))
        for it = 1:length(fieldnames(d_trialsbg)) % for each trial where there were bg bursts
            nextgo = []; match_evs = []; match = [];
            
            % if a stop trial, identify a go trial w/ similar or same
            % SSD
            if accuracy(it) == 3 || accuracy(it) == 4
                % try to pick matched go with same SSD soon after this
                % trial
                match = find(ssd-ssd(it) == 0 & accuracy == 1); nextgo = match(find(match>it,1,'first'));
                % if failed, pick first go trial w/ same SSD in exp
                if isempty(nextgo); nextgo = find(ssd-ssd(it) == 0 & accuracy == 1,1,'first'); end
                % if failed, pick first go trial w/ SSD w/in 50ms
                if isempty(nextgo); nextgo = find(ssd-ssd(it) == 50 | ssd-ssd(it) == -50 & accuracy == 1,1,'first'); end
                eval(['match_evs = d_trialsbg.t' num2str(nextgo) ';']);
            end
            
            % get events from that trial
            eval(['evs = d_trialsbg.t' num2str(it) ';']); evs(evs<=2)  = [];
            
            if ~isempty(evs)
                
                % store latency of first burst for each trial
                if accuracy(it) == 4
                    dfsev = dfsev + 1;
                    d_bg_fs_ev(dfsev,:) = evs(1);
                end
                if accuracy(it) == 3
                    dssev = dssev + 1;
                    d_bg_ss_ev(dssev,:) = evs(1);
                end
                if accuracy(it) == 1
                    dgoev = dgoev+1;
                    d_bg_go_ev(dgoev) = evs(1);
                end
            end
            
            % if there are events during a matched go trial
            match_evs = match_evs(match_evs>ssd(nextgo)); match_evs(match_evs<=2) = [];
            if ~isempty(match_evs)
                % sort according to accuracy and side
                if accuracy(nextgo) == 1
                    dmev = dmev+1;
                    d_bg_m_ev(dmev) = match_evs(1)-ssd(nextgo);
                end
            end
        end
    end
    
    % store percentages (get value of avg beta events per trial for each
    % trial type)
    BG_EV(is,1) = mean(bg_ss_ev); 
    BG_EV(is,2) = mean(bg_fs_ev); 
    BG_EV(is,3) = mean(bg_go_ev); 
    BG_EV(is,4) = mean(bg_m_ev); 
    M1_EV(is,1) = mean(m1_ss_ev); 
    M1_EV(is,2) = mean(m1_fs_ev); 
    M1_EV(is,3) = mean(m1_go_ev); 
    M1_EV(is,4) = mean(m1_m_ev); 
    BG_EV_SSRT(is,1) = mean(bg_ss_ev)-SSRT;
    BG_EV_SSRT(is,2) = mean(bg_fs_ev)-SSRT; 
    BG_EV_SSRT(is,3) = mean(bg_go_ev)-SSRT; 
    BG_EV_SSRT(is,4) = mean(bg_m_ev)-SSRT; 
    M1_EV_SSRT(is,1) = mean(m1_ss_ev)-SSRT;
    M1_EV_SSRT(is,2) = mean(m1_fs_ev)-SSRT; 
    M1_EV_SSRT(is,3) = mean(m1_go_ev)-SSRT; 
    M1_EV_SSRT(is,4) = mean(m1_m_ev)-SSRT; 
    if ~isempty(intersect(is,tha))
        VOP_EV(is,1) = mean(d_bg_ss_ev);
        VOP_EV(is,2) = mean(d_bg_fs_ev);
        VOP_EV(is,3) = mean(d_bg_go_ev);
        VOP_EV(is,4) = mean(d_bg_m_ev);
        VOP_EV_SSRT(is,1) = mean(d_bg_ss_ev)-SSRT;
        VOP_EV_SSRT(is,2) = mean(d_bg_fs_ev)-SSRT;
        VOP_EV_SSRT(is,3) = mean(d_bg_go_ev)-SSRT;
        VOP_EV_SSRT(is,4) = mean(d_bg_m_ev)-SSRT;
    end
    % if participant with both STN and VIM, save all trials
    if is == 2
        STN_104_SS = bg_ss_ev; STN_104_SS_SSRT = bg_ss_ev-SSRT;
        STN_104_FS = bg_fs_ev; STN_104_FS_SSRT = bg_fs_ev-SSRT;
        VOP_104_SS = d_bg_ss_ev; VOP_104_SS_SSRT = d_bg_ss_ev-SSRT;
        VOP_104_FS = d_bg_fs_ev; VOP_104_FS_SSRT = d_bg_fs_ev-SSRT;
        M1_104_SS = m1_ss_ev; M1_104_SS_SSRT = m1_ss_ev-SSRT;
        M1_104_FS = m1_fs_ev; M1_104_FS_SSRT = m1_fs_ev-SSRT;
    end
end

% for participant with both STN and VIM, grab VIM bursts
for is = 2 % for each subject
    
    clear trials* trialevs* blevs*
    subnum = datasets(is).subnum;
    
    % load beta event indices
    load(fullfile(folders.beta,['Subject' num2str(subnum) '.mat']));
    
    % assign channels
    % assign VIM [THIS DEFAULT TO STN FOR 104 (which has both VIM and STN)]
    if sum(~cellfun(@isempty,strfind(chanlabels,'lvim'))) == 1
        lbgchan = ~cellfun(@isempty,strfind(chanlabels,'lvim'));
        eval(['trialsbg = trialevs.' chanlabels{lbgchan} ';']);
    end
    
    % presets
    bg_ss_ev = []; ssev = 0; bg_fs_ev = []; fsev = 0;
    bg_go_ev = []; goev = 0; bg_m_ev = []; mev = 0;
    
    for it = 1:length(fieldnames(trialsbg)) % for each trial where there were bg bursts
        nextgo = []; match_evs = []; match = [];
        
        % if a stop trial, identify a go trial w/ similar or same
        % SSD
        if accuracy(it) == 3 || accuracy(it) == 4
            % try to pick matched go with same SSD soon after this
            % trial
            match = find(ssd-ssd(it) == 0 & accuracy == 1); nextgo = match(find(match>it,1,'first'));
            % if failed, pick first go trial w/ same SSD in exp
            if isempty(nextgo); nextgo = find(ssd-ssd(it) == 0 & accuracy == 1,1,'first'); end
            % if failed, pick first go trial w/ SSD w/in 50ms
            if isempty(nextgo); nextgo = find(ssd-ssd(it) == 50 | ssd-ssd(it) == -50 & accuracy == 1,1,'first'); end
            eval(['match_evs = trialsbg.t' num2str(nextgo) ';']);
        end
        
        % get events from that trial
        eval(['evs = trialsbg.t' num2str(it) ';']); evs(evs<=2)  = [];
        % if there's an event during this trial

        if ~isempty(evs)
            
            % store event counts for this trial according to
            % accuracy and side of response to be made
            if accuracy(it) == 4
                fsev = fsev + 1;
                bg_fs_ev(fsev,:) = evs(1);
            end
            if accuracy(it) == 3
                ssev = ssev + 1;
                bg_ss_ev(ssev,:) = evs(1);
            end
            if accuracy(it) == 1
                goev = goev+1;
                bg_go_ev(goev) = evs(1);
            end
        end
        
        % if there are events during a matched go trial
        match_evs = match_evs(match_evs>ssd(nextgo)); match_evs(match_evs<=2) = [];
        if ~isempty(match_evs)
            % sort according to accuracy and side
            if accuracy(nextgo) == 1
                mev = mev+1;
                bg_m_ev(mev) = match_evs(1)-ssd(nextgo);
            end
        end
    end

    % store percentages (get value of avg beta events per trial for each
    % trial type)
    VIM_EV(:,1) = mean(bg_ss_ev);
    VIM_EV(:,2) = mean(bg_fs_ev);
    VIM_EV(:,3) = mean(bg_go_ev);
    VIM_EV(:,4) = mean(bg_m_ev);
    % also store all trial values
    VIM_104_SS = bg_ss_ev; VIM_104_SS_SSRT = bg_ss_ev-SSRT;
    VIM_104_FS = bg_fs_ev; VIM_104_FS_SSRT = bg_fs_ev-SSRT;
end

stnplt = stn([1 3:end]);
thaplt = tha(2:end);
% stats
% run mc ttest on stn-vim diff for diff trial types
[~,succ_p] = ttest2(BG_EV_SSRT(stnplt,1),BG_EV_SSRT(thaplt,1));
[~,fail_p] = ttest2(BG_EV_SSRT(stnplt,2),BG_EV_SSRT(thaplt,2));
disp('Differences between STN and VIM timing, sample-level:')
if succ_p<=.05; disp(['Bursts significantly differ in timing across regions during SS: p = ' num2str(succ_p)]); end
if fail_p<=.05; disp(['Bursts significantly differ in timing across regions during SS: p = ' num2str(fail_p)]); end
% test for stn-vop diff
[~,succ_vop_p] = ttest2(BG_EV_SSRT(stnplt,1),VOP_EV_SSRT(thaplt,1));
[~,fail_vop_p] = ttest2(BG_EV_SSRT(stnplt,2),VOP_EV_SSRT(thaplt,2));
disp('Differences between STN and Vop timing, sample-level:')
if succ_vop_p<=.05; disp(['Bursts significantly differ in timing across regions during SS: p = ' num2str(succ_vop_p)]); end
if fail_vop_p<=.05; disp(['Bursts significantly differ in timing across regions during SS: p = ' num2str(fail_vop_p)]); end
% Run t tests for single sub
[~,single_succ_p] = ttest2(STN_104_SS,VIM_104_SS);
[~,single_fail_p] = ttest2(STN_104_FS,VIM_104_FS);
disp('Differences between STN and VIM timing, single subject:')
if single_succ_p<=.05; disp(['Bursts significantly differ in timing across regions during SS: p = ' num2str(single_succ_p)]); end
if single_fail_p<=.05; disp(['Bursts significantly differ in timing across regions during SS: p = ' num2str(single_fail_p)]); end
[~,single_vop_succ_p] = ttest2(STN_104_SS,VOP_104_SS);
[~,single_vop_fail_p] = ttest2(STN_104_FS,VOP_104_FS);
disp('Differences between STN and Vop timing, single subject:')
if single_vop_succ_p<=.05; disp(['Bursts significantly differ in timing across regions during SS: p = ' num2str(single_vop_succ_p)]); end
if single_vop_fail_p<=.05; disp(['Bursts significantly differ in timing across regions during SS: p = ' num2str(single_vop_fail_p)]); end
% Run t tests for single sub, SSRT-locked
[~,single_succ_p] = ttest2(STN_104_SS_SSRT,VIM_104_SS_SSRT);
[~,single_fail_p] = ttest2(STN_104_FS_SSRT,VIM_104_FS_SSRT);
disp('Differences between STN and VIM timing, single subject, SSRT-LOCKED:')
if single_succ_p<=.05; disp(['Bursts significantly differ in timing across regions during SS: p = ' num2str(single_succ_p)]); end
if single_fail_p<=.05; disp(['Bursts significantly differ in timing across regions during SS: p = ' num2str(single_fail_p)]); end
[~,single_vop_succ_p] = ttest2(STN_104_SS_SSRT,VOP_104_SS_SSRT);
[~,single_vop_fail_p] = ttest2(STN_104_FS_SSRT,VOP_104_FS_SSRT);
disp('Differences between STN and Vop timing, single subject,SSRT-LOCKED:')
if single_vop_succ_p<=.05; disp(['Bursts significantly differ in timing across regions during SS: p = ' num2str(single_vop_succ_p)]); end
if single_vop_fail_p<=.05; disp(['Bursts significantly differ in timing across regions during SS: p = ' num2str(single_vop_fail_p)]); end

% set up 2x2 anova to test effects of location and trial type across sample
Y = []; S = []; F1 = []; F2 = [];
for is = 1:length(datasets)
    subs = repmat(is,1,2)'; % label subject num for both entries for each subject
    f2 = [1 2]'; % factor 2 is trial type, SS=1,FS=2
    
    if isempty(Y)
        Y = [BG_EV_SSRT(is,1) BG_EV_SSRT(is,2)]';
        S = subs; F1 = [1 1]'; F2 = f2;
    else
        if ~isempty(intersect(is,stnplt))
            F1 = [F1; [1 1]']; % factor one is location, stn=1; tha=2
        else
            F1 = [F1; [2 2]'];
        end
        Y = [Y; [BG_EV_SSRT(is,1) BG_EV_SSRT(is,2)]'];
        S = [S; subs];
        F2 = [F2; f2];
    end
    
end
X_ANOVA = [Y F1 F2 S];
[~,~,~,final_Fs,final_ps] = rm_anova3(X_ANOVA,1);
factnames = {'location','trialtype'};
perm = 10000; % how many times to run

% set up second matrix for stn-vop comparison
VOP_Y = []; % subject, f1, f2 info will be the same
for is = 1:length(datasets)
    if isempty(VOP_Y)
        VOP_Y = [BG_EV_SSRT(is,1) BG_EV_SSRT(is,2)]';
    else
        if ~isempty(intersect(is,stnplt))
            VOP_Y = [VOP_Y; [BG_EV_SSRT(is,1) BG_EV_SSRT(is,2)]'];
        else
            VOP_Y = [VOP_Y; [VOP_EV_SSRT(is,1) VOP_EV_SSRT(is,2)]'];
        end
    end
end
X_VOP_ANOVA = [VOP_Y F1 F2 S];
[~,~,~,VOP_final_Fs,VOP_final_ps] = rm_anova3(X_VOP_ANOVA,1);

% run permutations to bootstrap
disp(['Please wait... completing permutation...']);
for ip = 1:perm
    permstats = [];
    Y_rand = Y(randperm(length(Y)));
    Y_VOP_rand = VOP_Y(randperm(length(VOP_Y)));
    
    [~,~,~,perm_stats] = rm_anova3([Y_rand F1 F2 S],1);
    [~,~,~,VOP_perm_stats] = rm_anova3([Y_VOP_rand F1 F2 S],1);
    locF(ip) = perm_stats{1};
    typeF(ip) = perm_stats{3};
    intF(ip) = perm_stats{4};
    VOP_locF(ip) = VOP_perm_stats{1};
    VOP_typeF(ip) = VOP_perm_stats{3};
    VOP_intF(ip) = VOP_perm_stats{4};    
end
% define sig cutoff based on permutations
loccutoff = quantile(locF,0.95); 
typecutoff = quantile(typeF,0.95); 
intcutoff = quantile(intF,0.95); 
VOP_loccutoff = quantile(VOP_locF,0.95); 
VOP_typecutoff = quantile(VOP_typeF,0.95); 
VOP_intcutoff = quantile(VOP_intF,0.95); 

% run actual value ANOVA
disp('Significant effects STN-Vim comparison: ');
if final_Fs{1} > loccutoff
    disp(['Location: F = ' num2str(final_Fs{1}) ', p = ' num2str(final_ps{1})]);
end
if final_Fs{3} > typecutoff
    disp(['Trial type: F = ' num2str(final_Fs{3}) ', p = ' num2str(final_ps{3})]);
end
if final_Fs{4} > intcutoff
    disp(['Trial x loc interaction: F = ' num2str(final_Fs{4}) ', p = ' num2str(final_ps{4})]);
end
disp('Significant effects STN-VOP comparison: ');
if VOP_final_Fs{1} > VOP_loccutoff
    disp(['Location: F = ' num2str(VOP_final_Fs{1}) ', p = ' num2str(VOP_final_ps{1})]);
end
if VOP_final_Fs{3} > VOP_typecutoff
    disp(['Trial type: F = ' num2str(VOP_final_Fs{3}) ', p = ' num2str(VOP_final_ps{3})]);
end
if VOP_final_Fs{4} > VOP_intcutoff
    disp(['Trial x loc interaction: F = ' num2str(VOP_final_Fs{4}) ', p = ' num2str(VOP_final_ps{4})]);
end

% make figures
clear ssdata
ssdata.stn = BG_EV(stnplt,1);
ssdata.vim = BG_EV(thaplt,1);
ssdata.vop = VOP_EV(thaplt,1);
ssdata.M1 = M1_EV(:,1);
h = figure('Color','w');
subplot(2,1,1); barplot(ssdata); hold on;
set(gca,'Ylim',[0 1000]); title('Sample-wide: Successful stops'); ylabel('Avg burst timing');

clear fsdata
fsdata.stn = BG_EV(stnplt,2);
fsdata.vim = BG_EV(thaplt,2);
fsdata.vop = VOP_EV(thaplt,2);
fsdata.m1 = M1_EV(:,2);
subplot(2,1,2); barplot(fsdata)
set(gca,'Ylim',[0 1000]); title('Sample-wide: Failed stops'); ylabel('Avg burst timing');

clear ssdata
ssdata.stn = BG_EV_SSRT(stnplt,1);
ssdata.vim = BG_EV_SSRT(thaplt,1);
ssdata.vop = VOP_EV_SSRT(thaplt,1);
ssdata.m1 = M1_EV_SSRT(:,1);
h = figure('Color','w');
subplot(2,1,1); barplot(ssdata); hold on;
set(gca,'Ylim',[-500 500]); title('Sample-wide: Successful stops locked to SSRT'); ylabel('Avg burst timing-SSRT');

clear fsdata
fsdata.stn = BG_EV_SSRT(stnplt,2);
fsdata.vim = BG_EV_SSRT(thaplt,2);
fsdata.vop = VOP_EV_SSRT(thaplt,2);
fsdata.m1 = M1_EV_SSRT(:,2);
subplot(2,1,2); barplot(fsdata)
set(gca,'Ylim',[-500 500]); title('Sample-wide: Failed stops locked to SSRT'); ylabel('Avg burst timing-SSRT');

clear ssdata
ssdata.stn = STN_104_SS;
ssdata.vim = VIM_104_SS;
ssdata.vop = VOP_104_SS;
ssdata.m1 = M1_104_SS;
h = figure('Color','w');
subplot(2,1,1); barplot(ssdata); hold on;
set(gca,'Ylim',[0 1000]); title('Single subject: Successful stops'); ylabel('Avg burst timing');

clear fsdata
fsdata.stn = STN_104_FS;
fsdata.vim = VIM_104_FS;
fsdata.vop = VOP_104_FS;
fsdata.m1 = M1_104_FS;
subplot(2,1,2); barplot(fsdata)
set(gca,'Ylim',[0 1000]); title('Single subject: Failed stops'); ylabel('Avg burst timing');