%% tPull all beta bursts in each region to extract avg freq band, duration
set(0,'DefaultFigureWindowStyle','docked')
% which participants contribute tha (exclude patient with both STN and tha)
tha_to_do = tha(2:end);
% preallocations
BG_FREQ = NaN(length(datasets),1); BG_LENGTH = BG_FREQ;
DORSAL_FREQ = BG_FREQ; DORSAL_LENGTH = BG_FREQ;
SMC_FREQ = BG_FREQ; SMC_LENGTH = BG_FREQ;

% Get avg over all, but also avg for characteristics following ss for go/stop/fail
for is = 1:length(datasets)
    subnum = datasets(is).subnum;
    clear freqs* durs* blev* all_* trial* dorsal*
    
    % load eventindices
    load(fullfile(folders.beta,['Subject' num2str(subnum) '.mat'])); 
    
    % All bg events
    % assign VIM [THIS DEFAULT TO STN FOR 104 (which has both VIM and STN)]
    if sum(~cellfun(@isempty,strfind(chanlabels,'rvim'))) == 1
        rbgchan = ~cellfun(@isempty,strfind(chanlabels,'rvim'));
        lbgchan = ~cellfun(@isempty,strfind(chanlabels,'lvim'));
        eval(['freqsbgl = evfreqs.' chanlabels{lbgchan} ';']); eval(['dursbgl = evlength.' chanlabels{lbgchan} ';']);
        eval(['freqsbgr = evfreqs.' chanlabels{rbgchan} ';']); eval(['dursbgr = evlength.' chanlabels{rbgchan} ';']);
        trialnumbers = fieldnames(freqsbgl);
        for itt = 1:length(trialnumbers)
        eval(['all_freqsbgl.' trialnumbers{itt} ' = [blevfreqs.' chanlabels{lbgchan} '.' trialnumbers{itt} ' evfreqs.' chanlabels{lbgchan} '.' trialnumbers{itt} '];']);
        eval(['all_freqsbgr.' trialnumbers{itt} ' = [blevfreqs.' chanlabels{rbgchan} '.' trialnumbers{itt} ' evfreqs.' chanlabels{rbgchan} '.' trialnumbers{itt} '];']);
        eval(['all_dursbgl.' trialnumbers{itt} ' = [blevlength.' chanlabels{lbgchan} '.' trialnumbers{itt} ' evlength.' chanlabels{lbgchan} '.' trialnumbers{itt} '];']);
        eval(['all_dursbgr.' trialnumbers{itt} ' = [blevlength.' chanlabels{rbgchan} '.' trialnumbers{itt} ' evlength.' chanlabels{rbgchan} '.' trialnumbers{itt} '];']);
        end
    end
    % assign STN [THIS DEFAULTS TO STN FOR 104 (which has both VIM and STN)]
    if sum(~cellfun(@isempty,strfind(chanlabels,'rstn'))) == 1
        rbgchan = ~cellfun(@isempty,strfind(chanlabels,'rstn'));
        lbgchan = ~cellfun(@isempty,strfind(chanlabels,'lstn'));
        eval(['freqsbgl = evfreqs.' chanlabels{lbgchan} ';']); eval(['dursbgl = evlength.' chanlabels{lbgchan} ';']);
        eval(['freqsbgr = evfreqs.' chanlabels{rbgchan} ';']); eval(['dursbgr = evlength.' chanlabels{rbgchan} ';']);
        trialnumbers = fieldnames(freqsbgl);
        for itt = 1:length(trialnumbers)
        eval(['all_freqsbgl.' trialnumbers{itt} ' = [blevfreqs.' chanlabels{lbgchan} '.' trialnumbers{itt} ' evfreqs.' chanlabels{lbgchan} '.' trialnumbers{itt} '];']);
        eval(['all_freqsbgr.' trialnumbers{itt} ' = [blevfreqs.' chanlabels{rbgchan} '.' trialnumbers{itt} ' evfreqs.' chanlabels{rbgchan} '.' trialnumbers{itt} '];']);
        eval(['all_dursbgl.' trialnumbers{itt} ' = [blevlength.' chanlabels{lbgchan} '.' trialnumbers{itt} ' evlength.' chanlabels{lbgchan} '.' trialnumbers{itt} '];']);
        eval(['all_dursbgr.' trialnumbers{itt} ' = [blevlength.' chanlabels{rbgchan} '.' trialnumbers{itt} ' evlength.' chanlabels{rbgchan} '.' trialnumbers{itt} '];']);
        end
    end
        
    % combine left and right bg data
    trialnumbers = fieldnames(freqsbgl);
    for itt = 1:length(trialnumbers)
        eval(['freqsbg.' trialnumbers{itt} ' = [freqsbgl.' trialnumbers{itt} ' freqsbgr.' trialnumbers{itt} '];']);
        eval(['all_freqsbg.' trialnumbers{itt} ' = [all_freqsbgl.' trialnumbers{itt} ' all_freqsbgr.' trialnumbers{itt} '];']);
        eval(['dursbg.' trialnumbers{itt} ' = [dursbgl.' trialnumbers{itt} ' dursbgr.' trialnumbers{itt} '];']);
        eval(['all_dursbg.' trialnumbers{itt} ' = [all_dursbgl.' trialnumbers{itt} ' all_dursbgr.' trialnumbers{itt} '];']);
    end
    
    % all SMC events
    rightmotor = chanlabels{~cellfun(@isempty,strfind(chanlabels,'rm1'))};
    eval(['freqsc4 = evfreqs.' rightmotor ';']); eval(['dursc4 = evlength.' rightmotor ';']);
    trialnumbers = fieldnames(freqsc4);
    for itt = 1:length(trialnumbers)
    eval(['all_freqsc4.' trialnumbers{itt} ' = [blevfreqs.' rightmotor '.' trialnumbers{itt} ' evfreqs.' rightmotor '.' trialnumbers{itt} '];']);
    eval(['all_dursc4.' trialnumbers{itt} ' = [blevlength.' rightmotor '.' trialnumbers{itt} ' evlength.' rightmotor '.' trialnumbers{itt} '];']);
    end
    % assign left motor
    leftmotor = chanlabels{~cellfun(@isempty,strfind(chanlabels,'lm1'))};
    eval(['freqsc3 = evfreqs.' leftmotor ';']); eval(['dursc3 = evlength.' leftmotor ';']);
    trialnumbers = fieldnames(freqsc3);
    for itt = 1:length(trialnumbers)
    eval(['all_freqsc3.' trialnumbers{itt} '= [blevfreqs.' leftmotor '.' trialnumbers{itt} ' blevfreqs.' leftmotor '.' trialnumbers{itt} '];']); 
    eval(['all_dursc3.' trialnumbers{itt} '= [blevlength.' leftmotor '.' trialnumbers{itt} ' blevlength.' leftmotor '.' trialnumbers{itt} '];']); 
    end
    
    % combine left and right SMC for all evs
    trialnumbers = fieldnames(all_freqsc3);
    for itt = 1:length(trialnumbers)
        eval(['all_freqsSMC.' trialnumbers{itt} ' = [all_freqsc3.' trialnumbers{itt} ' all_freqsc4.' trialnumbers{itt} '];']);
        eval(['all_dursSMC.' trialnumbers{itt} ' = [all_dursc3.' trialnumbers{itt} ' all_dursc4.' trialnumbers{itt} '];']);
    end
    
    % for thal patients, all dorsal events
    if ~isempty(intersect(is,tha)) % if a thalamus case, load dorsal thal 
        % load dorsal thalamus bursts
        load(fullfile(folders.beta,['Subject' num2str(subnum) '_dorsal.mat']));
        if sum(~cellfun(@isempty,strfind(chanlabels,'lvim'))) == 1
            if is ~= 2; lbgchan = ~cellfun(@isempty,strfind(chanlabels,'lvim'));end
            rbgchan = ~cellfun(@isempty,strfind(chanlabels,'rvim'));
            eval(['dorsal_freqsbgl = evfreqs.' chanlabels{lbgchan} ';']); eval(['dorsal_dursbgl = evlength.' chanlabels{lbgchan} ';']);
            if is ~= 2; eval(['dorsal_freqsbgr = evfreqs.' chanlabels{rbgchan} ';']); eval(['dorsal_dursbgr = evlength.' chanlabels{rbgchan} ';']); end
            trialnumbers = fieldnames(dorsal_freqsbgl);
            for itt = 1:length(trialnumbers)
            eval(['dorsal_all_freqsbgl.' trialnumbers{itt} ' = [blevfreqs.' chanlabels{lbgchan} '.' trialnumbers{itt} ' evfreqs.' chanlabels{lbgchan} '.' trialnumbers{itt} '];']);
            eval(['dorsal_all_dursbgl.' trialnumbers{itt} ' = [blevlength.' chanlabels{lbgchan} '.' trialnumbers{itt} ' evlength.' chanlabels{lbgchan} '.' trialnumbers{itt} '];']);
            if is ~= 2
                eval(['dorsal_all_freqsbgr.' trialnumbers{itt} '= [blevfreqs.' chanlabels{rbgchan} '.' trialnumbers{itt} ' evfreqs.' chanlabels{rbgchan} '.' trialnumbers{itt} '];']); 
                eval(['dorsal_all_dursbgr.' trialnumbers{itt} '= [blevlength.' chanlabels{rbgchan} '.' trialnumbers{itt} ' evlength.' chanlabels{rbgchan} '.' trialnumbers{itt} '];']); 
            end
            end
        end
        trialnumbers = fieldnames(dorsal_all_freqsbgl);
        for itt = 1:length(trialnumbers)
            if is ~= 2 
                eval(['dorsal_freqsbg.' trialnumbers{itt} ' = [dorsal_freqsbgl.' trialnumbers{itt} ' dorsal_freqsbgr.' trialnumbers{itt} '];']);
                eval(['dorsal_all_freqsbg.' trialnumbers{itt} ' = [dorsal_all_freqsbgl.' trialnumbers{itt} ' dorsal_all_freqsbgr.' trialnumbers{itt} '];']);
                eval(['dorsal_dursbg.' trialnumbers{itt} ' = [dorsal_dursbgl.' trialnumbers{itt} ' dorsal_dursbgr.' trialnumbers{itt} '];']);
                eval(['dorsal_all_dursbg.' trialnumbers{itt} ' = [dorsal_all_dursbgl.' trialnumbers{itt} ' dorsal_all_dursbgr.' trialnumbers{itt} '];']);
            else
                eval(['dorsal_freqsbg.' trialnumbers{itt} ' = [dorsal_freqsbgl.' trialnumbers{itt} '];']);
                eval(['dorsal_all_freqsbg.' trialnumbers{itt} ' = [dorsal_all_freqsbgl.' trialnumbers{itt} '];']);
                eval(['dorsal_dursbg.' trialnumbers{itt} ' = [dorsal_dursbgl.' trialnumbers{itt} '];']);
                eval(['dorsal_all_dursbg.' trialnumbers{itt} ' = [dorsal_all_dursbgl.' trialnumbers{itt} '];']);
            end
        end
    end
    
    % cycle through all the stn/ventral thal bursts
    betaduration = []; betafreq = []; 
    
    for it = 1:length(fieldnames(all_freqsbg))
         evfreqs = []; evlength = [];
        % get events
        eval(['evfreqs = all_freqsbg.t' num2str(it) ';']);
        eval(['evlength = all_dursbg.t' num2str(it) ';']);
        if ~isempty(evfreqs)

            % add each event to bin
            for ie = 1:length(evfreqs)
                % count trials
                betaduration = [betaduration evlength]; % for R1: other beta properties
                betafreq = [betafreq evfreqs]; % for R1: other beta properties
            end
        end
    end
    
    % store
    BG_FREQ(is) = mean(betafreq);
    BG_LENGTH(is) = mean(betaduration);
     
    % cycle through all the SMC bursts
    betaduration = []; betafreq = []; 
    
    for it = 1:length(fieldnames(all_freqsSMC))
        
        evfreqs = []; evlength = [];
        % get events
        eval(['evfreqs = all_freqsSMC.t' num2str(it) ';']);
        eval(['evlength = all_dursSMC.t' num2str(it) ';']);
        if ~isempty(evfreqs)

            % add each event to bin
            for ie = 1:length(evfreqs)
                % count trials
                betaduration = [betaduration evlength]; % for R1: other beta properties
                betafreq = [betafreq evfreqs]; % for R1: other beta properties
            end
        end
    end
    
    % store
    SMC_FREQ(is) = mean(betafreq);
    SMC_LENGTH(is) = mean(betaduration);

    if ~isempty(intersect(tha,is))
        % dorsal thal
        betaduration = []; betafreq = [];

        for it = 1:length(fieldnames(dorsal_all_freqsbg))
            evfreqs = []; evlength = [];
            % get events
            eval(['evfreqs = dorsal_all_freqsbg.t' num2str(it) ';']);
            eval(['evlength = dorsal_all_dursbg.t' num2str(it) ';']);
            if ~isempty(evfreqs)

                % add each event to bin
                for ie = 1:length(evfreqs)
                    % count trials
                    betaduration = [betaduration evlength]; % for R1: other beta properties
                    betafreq = [betafreq evfreqs]; % for R1: other beta properties
                end
            end
        end

        % store
        DORSAL_FREQ(is) = mean(betafreq);
        DORSAL_LENGTH(is) = mean(betaduration);
    end
end

disp('Characteristics of all beta bursts in each region:');
disp(['STN: Avg. freq - ' num2str(mean(BG_FREQ(stn))) ', Average duration - ' num2str(mean(BG_LENGTH(stn))) 'ms.']);
disp(['Ventral thalamus: Avg. freq - ' num2str(mean(BG_FREQ(tha(2:end)))) ', Average duration - ' num2str(mean(BG_LENGTH(tha(2:end)))) 'ms.']);
disp(['Dorsal thalamus: Avg. freq - ' num2str(mean(DORSAL_FREQ(tha))) ', Average duration - ' num2str(mean(DORSAL_LENGTH(tha))) 'ms.']);
disp(['SMC: Avg. freq - ' num2str(mean(SMC_FREQ)) ', Average duration - ' num2str(mean(SMC_LENGTH)) 'ms.']);
