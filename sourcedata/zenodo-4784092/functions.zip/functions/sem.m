function y = sem(x)
% This function computes standard error of the mean from a vector of data
% (x).
y = std(x) / sqrt(size(x,2));