%% M1 bursts after BG bursts
% This section evaluates the timing of M1 bursts time-locked to bursts in
% VIM or STN in 500ms after stimulus (whether stopsignal or gosignal).
% This analysis done only for subjects with both depth and M1
% electrodes (STN/VIM included as STN).
border = 500; % max events in ms after stop-signal
M1bins = [-100:50:100]; %set bins
clear STN* VIM*
% preallocate
GRT = zeros(length(datasets),1);
CONTRASUCC_main= NaN(length(datasets),length(M1bins)-1);
IPSISUCC_main = CONTRASUCC_main;
CONTRAFAIL_main = CONTRASUCC_main; IPSIFAIL_main = CONTRASUCC_main;
CONTRAGO_main = CONTRASUCC_main; IPSIGO_main = CONTRASUCC_main;
CONTRAMATCH_main = CONTRASUCC_main; IPSIMATCH_main = CONTRASUCC_main;
D_CONTRASUCC_main = CONTRASUCC_main; D_IPSISUCC_main = CONTRASUCC_main;
D_CONTRAFAIL_main = CONTRASUCC_main; D_IPSIFAIL_main = CONTRASUCC_main;
D_CONTRAGO_main = CONTRASUCC_main; D_IPSIGO_main = CONTRASUCC_main;
D_CONTRAMATCH_main = CONTRASUCC_main; D_IPSIMATCH_main = CONTRASUCC_main;

for is = 1:length(datasets)
    
    subnum = datasets(is).subnum;
    clear trialevs* trials* dorsal*
    
    % load eventindices
    load(fullfile(folders.beta,['Subject' num2str(subnum) '.mat']));
    
    % assign VIM [THIS DEFAULTS TO STN FOR 104 (which has both VIM and STN)]
    if sum(~cellfun(@isempty,strfind(chanlabels,'rvim'))) == 1
        rvimchan = ~cellfun(@isempty,strfind(chanlabels,'rvim'));
        lvimchan = ~cellfun(@isempty,strfind(chanlabels,'lvim'));
        eval(['trialsvimr = trialevs.' chanlabels{rvimchan} ';']);
        eval(['trialsviml = trialevs.' chanlabels{lvimchan} ';']);
    end
    % assign STN [THIS DEFAULTS TO STN FOR 104 (which has both VIM and STN)]
    if sum(~cellfun(@isempty,strfind(chanlabels,'rstn'))) == 1
        rstnchan = ~cellfun(@isempty,strfind(chanlabels,'rstn'));
        lstnchan = ~cellfun(@isempty,strfind(chanlabels,'lstn'));
        eval(['trialsstnr = trialevs.' chanlabels{rstnchan} ';']);
        eval(['trialsstnl = trialevs.' chanlabels{lstnchan} ';']);
    end
    % combine left and right bg
    if strcmpi(datasets(is).loc,'VIM')
        trialnumbers = fieldnames(trialsviml);
        for itt = 1:length(trialnumbers)
            eval(['trialsbg.' trialnumbers{itt} ' = [trialsviml.' trialnumbers{itt} ' trialsvimr.' trialnumbers{itt} '];']);
        end
    else
        trialnumbers = fieldnames(trialsstnl); 
        for itt = 1:length(trialnumbers)
            eval(['trialsbg.' trialnumbers{itt} ' = [trialsstnl.' trialnumbers{itt} ' trialsstnr.' trialnumbers{itt} '];']);
        end
    end
    rightmotor = chanlabels{~cellfun(@isempty,strfind(chanlabels,'rm1'))};
    eval(['trialsc4 = trialevs.' rightmotor ';']);
    % assign left motor
    leftmotor = chanlabels{~cellfun(@isempty,strfind(chanlabels,'lm1'))};
    eval(['trialsc3 = trialevs.' leftmotor ';']);
    
    % load in dorsal thal chans
    if ~isempty(intersect(tha,is))      
        load(fullfile(folders.beta,['Subject' num2str(subnum) '_dorsal.mat']));
        rvimchan = ~cellfun(@isempty,strfind(chanlabels,'rvim'));
        lvimchan = ~cellfun(@isempty,strfind(chanlabels,'lvim'));
        if is~= 2; eval(['dorsal_trialsvimr = trialevs.' chanlabels{rvimchan} ';']); end
        eval(['dorsal_trialsviml = trialevs.' chanlabels{lvimchan} ';']);
        for itt = 1:length(trialnumbers)
            if is~=2
                eval(['dorsal_trialsbg.' trialnumbers{itt} ' = [dorsal_trialsviml.' trialnumbers{itt} ' dorsal_trialsvimr.' trialnumbers{itt} '];']);
            else
                 eval(['dorsal_trialsbg.' trialnumbers{itt} ' = [dorsal_trialsviml.' trialnumbers{itt} '];']);
           end
        end        
    end
    
    % presets
    ipsi_go = []; contra_go = []; d_ipsi_go = []; d_contra_go = [];
    ig = 0; cg = 0; dig = 0; dcg = 0;
    ipsi_ss = []; contra_ss = []; d_ipsi_ss = []; d_contra_ss = [];
    iss = 0; css = 0; diss = 0; dcss = 0;
    ipsi_fs = []; contra_fs = []; d_ipsi_fs = []; d_contra_fs = [];
    ifs = 0; cfs = 0; difs = 0; dcfs = 0;
    contra_match = []; ipsi_match = []; d_contra_match = []; d_ipsi_match = [];
    cm = 0; im = 0; dcm = 0; dim = 0;
    
    for it = 1:length(fieldnames(trialsbg)) % for each trial
        nextgo = []; bg_matchevs = []; rm1_matchevs = []; lm1_matchevs = [];
        match = []; bgevs = []; devs = []; d_matchevs = []; lm1evs = []; rm1evs = [];
        
        % if a stop trial, find go trial with similar or same SSD
        if accuracy(it) == 3 || accuracy(it) == 4
            % try to pick matched go with same SSD soon after this
            % trial
            match = find(ssd-ssd(it) == 0 & accuracy == 1); nextgo = match(find(match>it,1,'first'));
            % if failed, pick most recent
            if isempty(nextgo); match = find(ssd-ssd(it) == 0 & accuracy == 1); nextgo = match(find(match<it,1,'last')); end
            % if failed, pick first go trial w/ SSD w/in 50ms
            if isempty(nextgo); nextgo = find(ssd-ssd(it) == 50 | ssd-ssd(it) == -50 & accuracy == 1,1,'first'); end
            eval(['bg_matchevs = trialsbg.t' num2str(nextgo) ';']);
            if ~isempty(intersect(is,tha)); eval(['d_matchevs = dorsal_trialsbg.t' num2str(nextgo) ';']); end
            eval(['lm1_matchevs = trialsc3.t' num2str(nextgo) ';']);
            eval(['rm1_matchevs = trialsc4.t' num2str(nextgo) ';']);
        end
        
        % get events within border (set at 500ms)
        bg_matchevs(bg_matchevs>border+ssd(nextgo)) = []; bg_matchevs(bg_matchevs<=2) = [];
        lm1_matchevs(lm1_matchevs>border+ssd(nextgo)) = []; lm1_matchevs(lm1_matchevs<=2) = [];
        rm1_matchevs(rm1_matchevs>border+ssd(nextgo)) = []; rm1_matchevs(rm1_matchevs<=2) = [];
        if ~isempty(intersect(tha,is)); d_matchevs(d_matchevs>border+ssd(nextgo)) = []; d_matchevs(d_matchevs<=2) = []; end
        eval(['bgevs = trialsbg.t' num2str(it) ';']); bgevs(bgevs>border) = []; bgevs(bgevs<=2) = [];
        if ~isempty(intersect(tha,is)); eval(['devs = dorsal_trialsbg.t' num2str(it) ';']); devs(devs>border) = []; devs(devs<=2) = []; end
        eval(['lm1evs = trialsc3.t' num2str(it) ';']); lm1evs(lm1evs>border) = []; lm1evs(lm1evs<=2) = [];
        eval(['rm1evs = trialsc4.t' num2str(it) ';']); rm1evs(rm1evs>border) = []; rm1evs(rm1evs<=2) = [];
        
        % if > 1 event
        if ~isempty(bgevs)
            
            l_trial = zeros(size(M1bins));
            r_trial = zeros(size(M1bins));
            l_matchtrial = l_trial; l_m1pick = [];
            r_matchtrial = l_trial; r_m1pick = [];
            r_matchpick = []; l_matchpick = [];
            
            for ie = 1 % for first ev
                % find M1 bursts during the appropriate time range
                % surrounding BG burst
                l_m1pick = find((lm1evs-bgevs(ie))<M1bins(end) & (lm1evs-bgevs(ie))>M1bins(1));
                r_m1pick = find((rm1evs-bgevs(ie))<M1bins(end) & (rm1evs-bgevs(ie))>M1bins(1));
                
                if ~isempty(l_m1pick)
                    for ip = 1:length(l_m1pick)
                        l_upperbound = find(lm1evs(l_m1pick(ip))-bgevs(ie)<M1bins,1,'first');
                        l_trial(l_upperbound) = l_trial(l_upperbound) + 1;
                    end
                end
                if ~isempty(r_m1pick)
                    for ip = 1:length(r_m1pick)
                        r_upperbound = find(rm1evs(r_m1pick(ip))-bgevs(ie)<M1bins,1,'first');
                        r_trial(r_upperbound) = r_trial(r_upperbound) + 1;
                    end
                end
            end
            
            % sort based on side and accuracy
            if side(it) == 1 && accuracy(it) == 4
                cfs = cfs + 1;
                contra_fs(cfs,:) = r_trial;
                ifs = ifs + 1;
                ipsi_fs(ifs,:) = l_trial;
            elseif side(it) == 2 && accuracy(it) == 4
                cfs = cfs + 1;
                contra_fs(cfs,:) = l_trial;
                ifs = ifs + 1;
                ipsi_fs(ifs,:) = r_trial;
            end
            if side(it) == 1 && accuracy(it) == 3
                css = css + 1;
                contra_ss(css,:) = r_trial;
                iss = iss + 1;
                ipsi_ss(iss,:) = l_trial;
            elseif side(it) == 2 && accuracy(it) == 3
                css = css + 1;
                contra_ss(css,:) = l_trial;
                iss = iss + 1;
                ipsi_ss(iss,:) = r_trial;
            end
            if side(it) == 1 && accuracy(it) == 1
                cg = cg + 1;
                contra_go(cg,:) = r_trial;
                ig = ig + 1;
                ipsi_go(ig,:) = l_trial;
            elseif side(it) == 2 && accuracy(it) == 1
                cg = cg + 1;
                contra_go(cg,:) = l_trial;
                ig = ig + 1;
                ipsi_go(ig,:) = r_trial;
            end
        end
        
        % if there are events in the matched go trial
        if ~isempty(bg_matchevs)
            for ie = 1
                % find events in the correct window in motor cortex
                % and classify them in their bins
                l_matchpick = find((lm1_matchevs-bg_matchevs(ie))<M1bins(end) & (lm1_matchevs-bg_matchevs(ie))>M1bins(1));
                r_matchpick = find((rm1_matchevs-bg_matchevs(ie))<M1bins(end) & (rm1_matchevs-bg_matchevs(ie))>M1bins(1));
                
                if ~isempty(l_matchpick)
                    for ip = 1:length(l_matchpick)
                        l_upperbound = find((lm1_matchevs(l_matchpick(ip))-bg_matchevs(ie))<M1bins,1,'first');
                        l_matchtrial(l_upperbound) = l_matchtrial(l_upperbound) + 1;
                    end
                end
                if ~isempty(r_matchpick)
                    for ip = 1:length(r_matchpick)
                        r_upperbound = find((rm1_matchevs(r_matchpick(ip))-bg_matchevs(ie))<M1bins,1,'first');
                        r_matchtrial(r_upperbound) = r_matchtrial(r_upperbound) + 1;
                    end
                end
                % sort by side and accuracy
                if side(nextgo) == 1 && accuracy(nextgo) == 1
                    cm = cm + 1;
                    contra_match(cm,:) = r_matchtrial;
                    im = im + 1;
                    ipsi_match(im,:) = l_matchtrial;
                elseif side(nextgo) == 2 && accuracy(nextgo) == 1
                    cm = cm + 1;
                    contra_match(cm,:) = l_matchtrial;
                    im = im + 1;
                    ipsi_match(im,:) = r_matchtrial;
                end
            end
        end
        
        % if > 1 event
        if ~isempty(intersect(is,tha))
            if ~isempty(devs) 
                
                l_trial = zeros(size(M1bins));
                r_trial = zeros(size(M1bins));
                l_matchtrial = l_trial; l_m1pick = [];
                r_matchtrial = l_trial; r_m1pick = [];
                r_matchpick = []; l_matchpick = [];
                
                for ie = 1 % for first ev
                    % find M1 bursts during the appropriate time range
                    % surrounding BG burst
                    l_m1pick = find((lm1evs-devs(ie))<M1bins(end) & (lm1evs-devs(ie))>M1bins(1));
                    r_m1pick = find((rm1evs-devs(ie))<M1bins(end) & (rm1evs-devs(ie))>M1bins(1));
                    
                    if ~isempty(l_m1pick)
                        for ip = 1:length(l_m1pick)
                            l_upperbound = find(lm1evs(l_m1pick(ip))-devs(ie)<M1bins,1,'first');
                            l_trial(l_upperbound) = l_trial(l_upperbound) + 1;
                        end
                    end
                    if ~isempty(r_m1pick)
                        for ip = 1:length(r_m1pick)
                            r_upperbound = find(rm1evs(r_m1pick(ip))-devs(ie)<M1bins,1,'first');
                            r_trial(r_upperbound) = r_trial(r_upperbound) + 1;
                        end
                    end
                end
                
                % sort based on side and accuracy
                if side(it) == 1 && accuracy(it) == 4
                    dcfs = dcfs + 1;
                    d_contra_fs(dcfs,:) = r_trial;
                    difs = difs + 1;
                    d_ipsi_fs(difs,:) = l_trial;
                elseif side(it) == 2 && accuracy(it) == 4
                    dcfs = dcfs + 1;
                    d_contra_fs(dcfs,:) = l_trial;
                    difs = difs + 1;
                    d_ipsi_fs(difs,:) = r_trial;
                end
                if side(it) == 1 && accuracy(it) == 3
                    dcss = dcss + 1;
                    d_contra_ss(dcss,:) = r_trial;
                    diss = diss + 1;
                    d_ipsi_ss(diss,:) = l_trial;
                elseif side(it) == 2 && accuracy(it) == 3
                    dcss = dcss + 1;
                    d_contra_ss(dcss,:) = l_trial;
                    diss = diss + 1;
                    d_ipsi_ss(diss,:) = r_trial;
                end
                if side(it) == 1 && accuracy(it) == 1
                    dcg = dcg + 1;
                    d_contra_go(dcg,:) = r_trial;
                    dig = dig + 1;
                    d_ipsi_go(dig,:) = l_trial;
                elseif side(it) == 2 && accuracy(it) == 1
                    dcg = dcg + 1;
                    d_contra_go(dcg,:) = l_trial;
                    dig = dig + 1;
                    d_ipsi_go(dig,:) = r_trial;
                end
            end
            
            % if there are events in the matched go trial
            if ~isempty(d_matchevs)
                for ie = 1
                    % find events in the correct window in motor cortex
                    % and classify them in their bins
                    l_matchpick = find((lm1_matchevs-d_matchevs(ie))<M1bins(end) & (lm1_matchevs-d_matchevs(ie))>M1bins(1));
                    r_matchpick = find((rm1_matchevs-d_matchevs(ie))<M1bins(end) & (rm1_matchevs-d_matchevs(ie))>M1bins(1));
                    
                    if ~isempty(l_matchpick)
                        for ip = 1:length(l_matchpick)
                            l_upperbound = find((lm1_matchevs(l_matchpick(ip))-d_matchevs(ie))<M1bins,1,'first');
                            l_matchtrial(l_upperbound) = l_matchtrial(l_upperbound) + 1;
                        end
                    end
                    if ~isempty(r_matchpick)
                        for ip = 1:length(r_matchpick)
                            r_upperbound = find((rm1_matchevs(r_matchpick(ip))-d_matchevs(ie))<M1bins,1,'first');
                            r_matchtrial(r_upperbound) = r_matchtrial(r_upperbound) + 1;
                        end
                    end
                    % sort by side and accuracy
                    if side(nextgo) == 1 && accuracy(nextgo) == 1
                        dcm = dcm + 1;
                        d_contra_match(dcm,:) = r_matchtrial;
                        dim = dim + 1;
                        d_ipsi_match(dim,:) = l_matchtrial;
                    elseif side(nextgo) == 2 && accuracy(nextgo) == 1
                        dcm = dcm + 1;
                        d_contra_match(dcm,:) = l_matchtrial;
                        dim = dim + 1;
                        d_ipsi_match(dim,:) = r_matchtrial;
                    end
                end
            end
        end
        
    end
    % delete the first bins to prevent baseline accumulation
    ipsi_go(:,1) = []; contra_go(:,1) = [];
    if ~isempty(ipsi_fs); ipsi_fs(:,1) = []; end
    if ~isempty(contra_fs); contra_fs(:,1) = []; end
    ipsi_ss(:,1) = []; contra_ss(:,1) = [];
    ipsi_match(:,1) = []; contra_match(:,1) = [];
    if ~isempty(intersect(is,tha))
        d_ipsi_go(:,1) = []; d_contra_go(:,1) = [];
        d_ipsi_fs(:,1) = []; d_contra_fs(:,1) = [];
        d_ipsi_ss(:,1) = []; d_contra_ss(:,1) = [];
        d_ipsi_match(:,1) = []; d_contra_match(:,1) = [];
    end
    
    % store percentages (avg num of evs per trial)
    CONTRAGO_main(is,:) = sum(contra_go)/size(contra_go,1);
    IPSIGO_main(is,:) = sum(ipsi_go)/size(ipsi_go,1);
    CONTRAFAIL_main(is,:) = sum(contra_fs)/size(contra_fs,1);
    IPSIFAIL_main(is,:) = sum(ipsi_fs)/size(ipsi_fs,1);
    CONTRASUCC_main(is,:) = sum(contra_ss)/size(contra_ss,1);
    IPSISUCC_main(is,:) = sum(ipsi_ss)/size(ipsi_ss,1);
    IPSIMATCH_main(is,:) = sum(ipsi_match)/size(ipsi_match,1);
    CONTRAMATCH_main(is,:) = sum(contra_match)/size(contra_match,1);
    if ~isempty(intersect(is,tha))
        D_CONTRAGO_main(is,:) = sum(d_contra_go)/size(d_contra_go,1);
        D_IPSIGO_main(is,:) = sum(d_ipsi_go)/size(d_ipsi_go,1);
        D_CONTRAFAIL_main(is,:) = sum(d_contra_fs)/size(d_contra_fs,1);
        D_IPSIFAIL_main(is,:) = sum(d_ipsi_fs)/size(d_ipsi_fs,1);
        D_CONTRASUCC_main(is,:) = sum(d_contra_ss)/size(d_contra_ss,1);
        D_IPSISUCC_main(is,:) = sum(d_ipsi_ss)/size(d_ipsi_ss,1);
        D_IPSIMATCH_main(is,:) = sum(d_ipsi_match)/size(d_ipsi_match,1);
        D_CONTRAMATCH_main(is,:) = sum(d_contra_match)/size(d_contra_match,1);
    end
end

% set up 2-way (condition x time) ANOVA w/permutations
% set up matrices
Y_STN = []; S_STN = []; F1_STN = []; F2_STN = [];
Y_VIM = []; S_VIM = []; F1_VIM = []; F2_VIM = [];
for is = [1:5 7:length(datasets)] % 6 didn't have failed trials with both burst types
    subs = repmat(is,1,(length(M1bins)-1)*3)'; f1 = [ones(1,length(M1bins)-1) repmat(2,1,length(M1bins)-1) repmat(3,1,length(M1bins)-1)]';
    f2 = repmat(1:length(M1bins)-1,1,3)';
    if strcmpi(datasets(is).loc,'STN') || strcmpi(datasets(is).loc,'both')
        if isempty(Y_STN)
            Y_STN = [CONTRAFAIL_main(is,:) CONTRASUCC_main(is,:) CONTRAMATCH_main(is,:)]';
            S_STN = subs; F1_STN = f1; F2_STN = f2;
        else
            Y_STN = [Y_STN; [CONTRAFAIL_main(is,:) CONTRASUCC_main(is,:) CONTRAMATCH_main(is,:)]'];
            S_STN = [S_STN; subs]; F1_STN = [F1_STN; f1];
            F2_STN = [F2_STN; f2];
        end
    else
        if isempty(Y_VIM)
            Y_VIM = [CONTRAFAIL_main(is,:) CONTRASUCC_main(is,:) CONTRAMATCH_main(is,:)]';
            S_VIM = subs; F1_VIM = f1; F2_VIM = f2;
        else
            Y_VIM = [Y_VIM; [CONTRAFAIL_main(is,:) CONTRASUCC_main(is,:) CONTRAMATCH_main(is,:)]'];
            S_VIM = [S_VIM; subs]; F1_VIM = [F1_VIM; f1];
            F2_VIM = [F2_VIM; f2];
        end
    end
end
factnames = {'trialtype','timepoint'};
perm = 10000; % how many times to run
% run permutations to bootstrap
disp(['Please wait... completing permutation...']);
for ip = 1:perm
    permstats = [];
    Y_STN_rand = Y_STN(randperm(length(Y_STN)));
    Y_VIM_rand = Y_VIM(randperm(length(Y_VIM)));
    
    perm_stats = rm_anova2(Y_STN_rand,S_STN,F1_STN,F2_STN,factnames);
    STN_typeF(ip) = perm_stats{2,5};
    STN_timeF(ip) = perm_stats{3,5};
    STN_intF(ip) = perm_stats{4,5};
    
    perm_stats = rm_anova2(Y_VIM_rand,S_VIM,F1_VIM,F2_VIM,factnames);
    VIM_typeF(ip) = perm_stats{2,5};
    VIM_timeF(ip) = perm_stats{3,5};
    VIM_intF(ip) = perm_stats{4,5};
end
% define sig cutoff based on permutations
STN_typecutoff = quantile(STN_typeF,0.95); VIM_typecutoff = quantile(VIM_typeF,0.95);
STN_timecutoff = quantile(STN_timeF,0.95); VIM_timecutoff = quantile(VIM_timeF,0.95);
STN_intcutoff = quantile(STN_intF,0.95); VIM_intcutoff = quantile(VIM_intF,0.95);

% run actual value ANOVA
STN_final_stats = rm_anova2(Y_STN,S_STN,F1_STN,F2_STN,factnames);
VIM_final_stats = rm_anova2(Y_VIM,S_VIM,F1_VIM,F2_VIM,factnames);
disp('M1 bursts locked to subcortical bursts: ');
disp('Significant effects in STN sample: ');
if STN_final_stats{2,5} > STN_typecutoff
    disp(['Trial type: F = ' num2str(STN_final_stats{2,5}) ', p = ' num2str(STN_final_stats{2,6})]);
end
if STN_final_stats{3,5} > STN_timecutoff
    disp(['Timepoint: F = ' num2str(STN_final_stats{3,5}) ', p = ' num2str(STN_final_stats{3,6})]);
end
if STN_final_stats{4,5} > STN_intcutoff
    disp(['Trial x time interaction: F = ' num2str(STN_final_stats{4,5}) ', p = ' num2str(STN_final_stats{4,6})]);
end

disp('Significant effects in VIM sample: ');
if VIM_final_stats{2,5} > VIM_typecutoff
    disp(['Trial type: F = ' num2str(VIM_final_stats{2,5}) ', p = ' num2str(VIM_final_stats{2,6})]);
end
if VIM_final_stats{3,5} > VIM_timecutoff
    disp(['Timepoint: F = ' num2str(VIM_final_stats{3,5}) ', p = ' num2str(VIM_final_stats{3,6})]);
end
if VIM_final_stats{4,5} > VIM_intcutoff
    disp(['Trial x time interaction: F = ' num2str(VIM_final_stats{4,5}) ', p = ' num2str(VIM_final_stats{4,6})]);
end
% which to plot for each sample
thaplt = tha(2:end);
% parse individual time points using Monte-Carlo t-tests
for it = 1:length(M1bins)-1
    [~,STN_gop(it)] = ttest(CONTRASUCC_main(stn,it),CONTRAMATCH_main(stn,it));
    [~,VIM_gop(it)] = ttest(CONTRASUCC_main(thaplt,it),CONTRAMATCH_main(thaplt,it));
    [~,STN_failp(it)] = ttest(CONTRASUCC_main(stn,it),CONTRAFAIL_main(stn,it));
    [~,VIM_failp(it)] = ttest(CONTRASUCC_main(thaplt([1 3:end]),it),CONTRAFAIL_main(thaplt([1 3:end]),it));    
end
corrected_go_STNp = bonf_holm(STN_gop); corrected_fail_STNp = bonf_holm(STN_failp);
corrected_go_VIMp = bonf_holm(VIM_gop); corrected_fail_VIMp = bonf_holm(VIM_failp);
disp('STN sample - Significant burst differences were seen between SS and Go trials at these time points:');
for it = 1:length(M1bins)-1
    if corrected_go_STNp(it)<=.05; disp([num2str(M1bins(it)) ' to ' num2str(M1bins(it+1)) 'ms: p = ' num2str(corrected_go_STNp(it))]); end
end
disp('STN sample - Significant burst differences were seen between SS and FS trials at these time points:');
for it = 1:length(M1bins)-1
    if corrected_fail_STNp(it)<=.05; disp([num2str(M1bins(it)) ' to ' num2str(M1bins(it+1)) 'ms: p = ' num2str(corrected_fail_STNp(it))]); end
end
disp('VIM sample - Significant burst differences were seen between SS and Go trials at these time points:');
for it = 1:length(M1bins)-1
    if corrected_go_VIMp(it)<=.05; disp([num2str(M1bins(it)) ' to ' num2str(M1bins(it+1)) 'ms: p = ' num2str(corrected_go_VIMp(it))]); end
end
disp('VIM sample - Significant burst differences were seen between SS and FS trials at these time points:');
for it = 1:length(M1bins)-1
    if corrected_fail_VIMp(it)<=.05; disp([num2str(M1bins(it)) ' to ' num2str(M1bins(it+1)) 'ms: p = ' num2str(corrected_fail_VIMp(it))]); end
end


% Do stats for dorsal thalamus
% set up 2-way (condition x time) ANOVA w/permutations
% set up matrices
Y_VIM = []; S_VIM = []; F1_VIM = []; F2_VIM = [];
for is = tha
    subs = repmat(is,1,(length(M1bins)-1)*3)'; f1 = [ones(1,length(M1bins)-1) repmat(2,1,length(M1bins)-1) repmat(3,1,length(M1bins)-1)]';
    f2 = repmat(1:length(M1bins)-1,1,3)';
    if isempty(Y_VIM)
        Y_VIM = [D_CONTRAFAIL_main(is,:) D_CONTRASUCC_main(is,:) D_CONTRAMATCH_main(is,:)]';
        S_VIM = subs; F1_VIM = f1; F2_VIM = f2;
    else
        Y_VIM = [Y_VIM; [D_CONTRAFAIL_main(is,:) D_CONTRASUCC_main(is,:) D_CONTRAMATCH_main(is,:)]'];
        S_VIM = [S_VIM; subs]; F1_VIM = [F1_VIM; f1];
        F2_VIM = [F2_VIM; f2];
    end
end
factnames = {'trialtype','timepoint'};
perm = 10000; % how many times to run
% run permutations to bootstrap
disp(['Please wait... completing permutation...']);
for ip = 1:perm
    permstats = [];
    Y_VIM_rand = Y_VIM(randperm(length(Y_VIM)));

    perm_stats = rm_anova2(Y_VIM_rand,S_VIM,F1_VIM,F2_VIM,factnames);
    VIM_typeF(ip) = perm_stats{2,5};
    VIM_timeF(ip) = perm_stats{3,5};
    VIM_intF(ip) = perm_stats{4,5};
end
% define sig cutoff based on permutations
VIM_typecutoff = quantile(VIM_typeF,0.95);
VIM_timecutoff = quantile(VIM_timeF,0.95);
VIM_intcutoff = quantile(VIM_intF,0.95);

% run actual value ANOVA
VIM_final_stats = rm_anova2(Y_VIM,S_VIM,F1_VIM,F2_VIM,factnames);
disp('Significant effects in dorsal thal sample: ');
if VIM_final_stats{2,5} > VIM_typecutoff
    disp(['Trial type: F = ' num2str(VIM_final_stats{2,5}) ', p = ' num2str(VIM_final_stats{2,6})]);
end
if VIM_final_stats{3,5} > VIM_timecutoff
    disp(['Timepoint: F = ' num2str(VIM_final_stats{3,5}) ', p = ' num2str(VIM_final_stats{3,6})]);
end
if VIM_final_stats{4,5} > VIM_intcutoff
    disp(['Trial x time interaction: F = ' num2str(VIM_final_stats{4,5}) ', p = ' num2str(VIM_final_stats{4,6})]);
end
% which to plot for each sample
thaplt = tha(2:end);
% parse individual time points using Monte-Carlo t-tests
for it = 1:length(M1bins)-1
    [~,VIM_gop(it)] = ttest(D_CONTRASUCC_main(tha,it),D_CONTRAMATCH_main(tha,it));
    [~,VIM_failp(it)] = ttest(D_CONTRASUCC_main(tha([1 3:end]),it),D_CONTRAFAIL_main(tha([1 3:end]),it));    
end
corrected_go_VIMp = bonf_holm(VIM_gop); corrected_fail_VIMp = bonf_holm(VIM_failp);
disp('VIM sample - Significant burst differences were seen between SS and Go trials at these time points:');
for it = 1:length(M1bins)-1
    if corrected_go_VIMp(it)<=.05; disp([num2str(M1bins(it)) ' to ' num2str(M1bins(it+1)) 'ms: p = ' num2str(corrected_go_VIMp(it))]); end
end
disp('VIM sample - Significant burst differences were seen between SS and FS trials at these time points:');
for it = 1:length(M1bins)-1
    if corrected_fail_VIMp(it)<=.05; disp([num2str(M1bins(it)) ' to ' num2str(M1bins(it+1)) 'ms: p = ' num2str(corrected_fail_VIMp(it))]); end
end

% barweb fig - m1 after bg, gos
h = figure('Position',[1 1 1000 1000],'Color','w');
subplot(2,1,1);
barweb([mean(CONTRASUCC_main(stn,:),1);mean(CONTRAMATCH_main(stn,:),1)]',[sem(CONTRASUCC_main(stn,:));sem(CONTRAMATCH_main(stn,:))]',.8,cellfun(@num2str,num2cell(M1bins(2:end)),'UniformOutput',0),'Beta bursts at M1 following STN bursts', 'time (ms) from BG burst', 'proportion of trials', '', '', {'Stop','Matched go'});
hold on;
for ib = 1:length(M1bins)-1
    scatter(repmat(ib-.15,1,length(CONTRASUCC_main(stn,ib))),CONTRASUCC_main(stn,ib),64,'Jitter','on','JitterAmount',0.05,'MarkerEdgeColor','k','MarkerFaceColor',[.7 .7 .7],'MarkerFaceAlpha',0.5);
    scatter(repmat(ib+.15,1,length(CONTRAMATCH_main(stn,ib))),CONTRAMATCH_main(stn,ib),64,'Jitter','on','JitterAmount',0.05,'MarkerEdgeColor','k','MarkerFaceColor',[.7 .7 .7],'MarkerFaceAlpha',0.5);
end
set(gca,'Ylim',[0 .3]);

% for VIM
subplot(2,1,2);
barweb([mean(CONTRASUCC_main(thaplt,:),1);mean(CONTRAMATCH_main(thaplt,:),1)]',[sem(CONTRASUCC_main(thaplt,:));sem(CONTRAMATCH_main(thaplt,:))]',.8,cellfun(@num2str,num2cell(M1bins(2:end)),'UniformOutput',0),'Beta bursts at M1 following VIM bursts', 'time (ms) from BG burst', 'proportion of trials', '', '', {'Stop','Matched go'});
hold on;
for ib = 1:length(M1bins)-1
    scatter(repmat(ib-.15,1,length(CONTRASUCC_main(thaplt,ib))),CONTRASUCC_main(thaplt,ib),64,'Jitter','on','JitterAmount',0.05,'MarkerEdgeColor','k','MarkerFaceColor',[.7 .7 .7],'MarkerFaceAlpha',0.5);
    scatter(repmat(ib+.15,1,length(CONTRAMATCH_main(thaplt,ib))),CONTRAMATCH_main(thaplt,ib),64,'Jitter','on','JitterAmount',0.05,'MarkerEdgeColor','k','MarkerFaceColor',[.7 .7 .7],'MarkerFaceAlpha',0.5);
end
set(gca,'Ylim',[0 .3]);

% barweb fig for dorsal thalamus
h = figure('Position',[1 1 1000 1000],'Color','w');
barweb([mean(CONTRASUCC_main(tha,:),1);mean(CONTRAMATCH_main(tha,:),1)]',[sem(CONTRASUCC_main(tha,:));sem(CONTRAMATCH_main(tha,:))]',.8,cellfun(@num2str,num2cell(M1bins(2:end)),'UniformOutput',0),'Beta bursts at M1 following dorsal thal bursts', 'time (ms) from BG burst', 'proportion of trials', '', '', {'Stop','Matched go'});
hold on;
for ib = 1:length(M1bins)-1
    scatter(repmat(ib-.15,1,length(CONTRASUCC_main(tha,ib))),CONTRASUCC_main(tha,ib),64,'Jitter','on','JitterAmount',0.05,'MarkerEdgeColor','k','MarkerFaceColor',[.7 .7 .7],'MarkerFaceAlpha',0.5);
    scatter(repmat(ib+.15,1,length(CONTRAMATCH_main(tha,ib))),CONTRAMATCH_main(tha,ib),64,'Jitter','on','JitterAmount',0.05,'MarkerEdgeColor','k','MarkerFaceColor',[.7 .7 .7],'MarkerFaceAlpha',0.5);
end
set(gca,'Ylim',[0 .3]);

% Redo the analysis for M1-locked BG bursts
% preallocate
GRT = zeros(length(datasets),1);
SUCC_main = NaN(length(datasets),length(M1bins)-1); D_SUCC_main = SUCC_main;
FAIL_main = SUCC_main; D_FAIL_main = SUCC_main;
GO_main = SUCC_main; D_GO_main = SUCC_main;
MATCH_main = SUCC_main; D_MATCH_main = SUCC_main;

for is = 1:length(datasets) % for each dataset
    
    subnum = datasets(is).subnum;
    clear trialevs* trials* dorsal*
    
    % load event indices
    load(fullfile(folders.beta,['Subject' num2str(subnum) '.mat']));
    
    % assign VIM [THIS DEFAULT TO STN FOR 104 (which has both VIM and STN)]
    if sum(~cellfun(@isempty,strfind(chanlabels,'rvim'))) == 1
        rvimchan = ~cellfun(@isempty,strfind(chanlabels,'rvim'));
        lvimchan = ~cellfun(@isempty,strfind(chanlabels,'lvim'));
        eval(['trialsbgr = trialevs.' chanlabels{rvimchan} ';']);
        eval(['trialsbgl = trialevs.' chanlabels{lvimchan} ';']);
    end
    % assign STN [THIS DEFAULT TO STN FOR 104 (which has both VIM and STN)]
    if sum(~cellfun(@isempty,strfind(chanlabels,'rstn'))) == 1
        rstnchan = ~cellfun(@isempty,strfind(chanlabels,'rstn'));
        lstnchan = ~cellfun(@isempty,strfind(chanlabels,'lstn'));
        eval(['trialsbgr = trialevs.' chanlabels{rstnchan} ';']);
        eval(['trialsbgl = trialevs.' chanlabels{lstnchan} ';']);
    end
    % combine left and right bg
    trialnumbers = fieldnames(trialsbgl); 
    for itt = 1:length(trialnumbers)
        eval(['trialsbg.' trialnumbers{itt} ' = [trialsbgl.' trialnumbers{itt} ' trialsbgr.' trialnumbers{itt} '];']);
    end
    
    rightmotor = chanlabels{~cellfun(@isempty,strfind(chanlabels,'rm1'))};
    eval(['trialsc4 = trialevs.' rightmotor ';']);
    % assign left motor
    leftmotor = chanlabels{~cellfun(@isempty,strfind(chanlabels,'lm1'))};
    eval(['trialsc3 = trialevs.' leftmotor ';']);
    
    % load in dorsal thal chans
    if ~isempty(intersect(tha,is))   
        load(fullfile(folders.beta,['Subject' num2str(subnum) '_dorsal.mat']));
        rvimchan = ~cellfun(@isempty,strfind(chanlabels,'rvim'));
        lvimchan = ~cellfun(@isempty,strfind(chanlabels,'lvim'));
        if is~= 2; eval(['dorsal_trialsvimr = trialevs.' chanlabels{rvimchan} ';']); end
        eval(['dorsal_trialsviml = trialevs.' chanlabels{lvimchan} ';']);
        for itt = 1:length(trialnumbers)
            if is~=2
                eval(['dorsal_trialsbg.' trialnumbers{itt} ' = [dorsal_trialsviml.' trialnumbers{itt} ' dorsal_trialsvimr.' trialnumbers{itt} '];']);
            else
                 eval(['dorsal_trialsbg.' trialnumbers{itt} ' = [dorsal_trialsviml.' trialnumbers{itt} '];']);
           end
        end        
    end
    
    % presets
    go = []; d_go = [];
    g = 0; dg = 0;
    ss = []; d_ss = [];
    s = 0; ds = 0;
    fs = []; d_fs = [];
    f = 0; df = 0;
    go_match = []; d_go_match = [];
    m = 0; dm = 0;
    
    for it = 1:length(fieldnames(trialsbg)) % for each trial
        nextgo = []; bg_matchevs = []; m1_matchevs = []; m1evs = []; bgevs = [];
        match = []; devs = []; d_matchevs = [];
        % if it's a stop trial, find go trial with same or similar
        % SSD
        if accuracy(it) == 3 || accuracy(it) == 4
            % try to pick matched go with same SSD soon after this
            % trial
            match = find(ssd-ssd(it) == 0 & accuracy == 1); nextgo = match(find(match>it,1,'first'));
            % if failed, pick most recent
            if isempty(nextgo); match = find(ssd-ssd(it) == 0 & accuracy == 1); nextgo = match(find(match<it,1,'last')); end
            % if failed, pick first go trial w/ SSD w/in 50ms
            if isempty(nextgo); nextgo = find(ssd-ssd(it) == 50 | ssd-ssd(it) == -50 & accuracy == 1,1,'first'); end
            eval(['bg_matchevs = trialsbg.t' num2str(nextgo) ';']);
            if ~isempty(intersect(is,tha)); eval(['dorsal_matchevs = dorsal_trialsbg.t' num2str(nextgo) ';']); end
            if side(nextgo) == 1
                eval(['m1_matchevs = trialsc4.t' num2str(nextgo) ';']);
            else
                eval(['m1_matchevs = trialsc3.t' num2str(nextgo) ';']);
            end
        end
        % get events within border (500ms after stimulus)
        bg_matchevs(bg_matchevs>border+ssd(nextgo) & bg_matchevs<border+ssd(nextgo)) = []; bg_matchevs(bg_matchevs<=2) = [];
        m1_matchevs(m1_matchevs>border+ssd(nextgo) & m1_matchevs<border+ssd(nextgo)) = []; m1_matchevs(m1_matchevs<=2) = [];
        eval(['bgevs = trialsbg.t' num2str(it) ';']); bgevs(bgevs>border) = []; bgevs(bgevs<=2) = [];
        if ~isempty(intersect(is,tha)); eval(['devs = dorsal_trialsbg.t' num2str(it) ';']); devs(devs>border) = []; devs(devs<=2) = []; end
        if side(it) == 1
            eval(['m1evs = trialsc4.t' num2str(it) ';']);
        else
            eval(['m1evs = trialsc3.t' num2str(it) ';']);
        end
        m1evs(m1evs>border) = []; m1evs(m1evs<=2) = [];
        
        if ~isempty(m1evs)% if m1 evs in the trial
            
            % add each event to bin
            trial = zeros(size(M1bins));
            matchtrial = trial;
            d_trial = trial;
            d_matchtrial = trial;
            
            for ie = 1 % for first ev following SS
                % count trial
                % find M1 bursts during the appropriate time range
                % surrounding BG burst
                bgpick = find((bgevs-m1evs(ie))<M1bins(end) & (bgevs-m1evs(ie))>M1bins(1));
                
                if ~isempty(bgpick)
                    for ip = 1:length(bgpick)
                        upperbound = find((bgevs(bgpick(ip))-m1evs(ie))<M1bins,1,'first');
                        trial(upperbound) = trial(upperbound) + 1;
                    end
                end
                
                if ~isempty(intersect(tha,is))
                    d_bgpick = find((devs-m1evs(ie))<M1bins(end) & (devs-m1evs(ie))>M1bins(1));
                    
                    if ~isempty(d_bgpick)
                        for ip = 1:length(d_bgpick)
                            upperbound = find((devs(d_bgpick(ip))-m1evs(ie))<M1bins,1,'first');
                            d_trial(upperbound) = trial(upperbound) + 1;
                        end
                    end
                end
                
            end
            
            % sort by side and acc
            if accuracy(it) == 4
                f = f + 1;
                fs(f,:) = trial;
            end
            if accuracy(it) == 3
                s = s + 1;
                ss(s,:) = trial;
            end
            if accuracy(it) == 1
                g = g + 1;
                go(g,:) = trial;
            end
            
            if ~isempty(intersect(is,tha))
                if accuracy(it) == 4
                    df = df + 1;
                    d_fs(df,:) = d_trial;
                end
                if accuracy(it) == 3
                    ds = ds + 1;
                    d_ss(ds,:) = d_trial;
                end
                if accuracy(it) == 1
                    dg = dg + 1;
                    d_go(dg,:) = d_trial;
                end
            end
        end
        
        % if > 1 ev in the matched go trial
        if ~isempty(m1_matchevs)
            for ie = 1:length(m1_matchevs)
                % sort evs into bins
                bg_matchpick = find((bg_matchevs-m1_matchevs(ie)-ssd(nextgo))<M1bins(end) & (bg_matchevs-m1_matchevs(ie)-ssd(nextgo))>M1bins(1));
                
                if ~isempty(bg_matchpick)
                    for ip = 1:length(bg_matchpick)
                        upperbound = find((bg_matchevs(bg_matchpick(ip))-m1_matchevs(ie)-ssd(nextgo))<M1bins,1,'first');
                        matchtrial(upperbound) = matchtrial(upperbound) + 1;
                    end
                end
                
                if ~isempty(intersect(is,tha))
                    d_matchpick = find((dorsal_matchevs-m1_matchevs(ie)-ssd(nextgo))<M1bins(end) & (dorsal_matchevs-m1_matchevs(ie)-ssd(nextgo))>M1bins(1));
                    
                    if ~isempty(d_matchpick)
                        for ip = 1:length(d_matchpick)
                            upperbound = find((dorsal_matchevs(d_matchpick(ip))-m1_matchevs(ie)-ssd(nextgo))<M1bins,1,'first');
                            d_matchtrial(upperbound) = d_matchtrial(upperbound) + 1;
                        end
                    end
                end
                
                if accuracy(nextgo) == 1
                    m = m + 1;
                    go_match(m,:) = matchtrial;
                end
                
                if ~isempty(intersect(is,tha))
                    if accuracy(nextgo) == 1
                        dm = dm + 1;
                        d_go_match(m,:) = d_matchtrial;
                    end
                end
            end
        end
        
    end
    % delete first bin to prevent baseline accumulation
    go(:,1) = []; fs(:,1) = []; 
    ss(:,1) = []; go_match(:,1) = []; 
    if ~isempty(intersect(is,tha))
        d_go(:,1) = []; d_ss(:,1) = [];
        d_fs(:,1) = []; d_go_match(:,1) = [];
    end
    % store percentages (avg num of evs per trial)
    GO_main(is,:) = sum(go)/size(go,1);
    FAIL_main(is,:) = sum(fs)/size(fs,1);
    SUCC_main(is,:) = sum(ss)/size(ss,1);
    MATCH_main(is,:) = sum(go_match)/size(go_match,1);
    if ~isempty(intersect(is,tha))
    D_GO_main(is,:) = sum(d_go)/size(d_go,1);
    D_FAIL_main(is,:) = sum(d_fs)/size(d_fs,1);
    D_SUCC_main(is,:) = sum(d_ss)/size(d_ss,1);
    D_MATCH_main(is,:) = sum(d_go_match)/size(d_go_match,1);    
    end
end

% set up 2-way (condition x time) ANOVA w/permutations
% set up matrices
Y_STN = []; S_STN = []; F1_STN = []; F2_STN = [];
Y_VIM = []; S_VIM = []; F1_VIM = []; F2_VIM = [];
for is = 1:length(datasets)
    subs = repmat(is,1,(length(M1bins)-1)*3)'; f1 = [ones(1,length(M1bins)-1) repmat(2,1,length(M1bins)-1) repmat(3,1,length(M1bins)-1)]';
    f2 = repmat(1:length(M1bins)-1,1,3)';
    if strcmpi(datasets(is).loc,'STN') || strcmpi(datasets(is).loc,'both')
        if isempty(Y_STN)
            Y_STN = [FAIL_main(is,:) SUCC_main(is,:) MATCH_main(is,:)]';
            S_STN = subs; F1_STN = f1; F2_STN = f2;
        else
            Y_STN = [Y_STN; [FAIL_main(is,:) SUCC_main(is,:) MATCH_main(is,:)]'];
            S_STN = [S_STN; subs]; F1_STN = [F1_STN; f1];
            F2_STN = [F2_STN; f2];
        end
    else
        if isempty(Y_VIM)
            Y_VIM = [FAIL_main(is,:) SUCC_main(is,:) MATCH_main(is,:)]';
            S_VIM = subs; F1_VIM = f1; F2_VIM = f2;
        else
            Y_VIM = [Y_VIM; [FAIL_main(is,:) SUCC_main(is,:) MATCH_main(is,:)]'];
            S_VIM = [S_VIM; subs]; F1_VIM = [F1_VIM; f1];
            F2_VIM = [F2_VIM; f2];
        end
    end
end
factnames = {'trialtype','timepoint'};
perm = 10000; % how many times to run
disp(['Please wait... completing permutation...']);
% run permutations to bootstrap
for ip = 1:perm
    permstats = [];
    Y_STN_rand = Y_STN(randperm(length(Y_STN)));
    Y_VIM_rand = Y_VIM(randperm(length(Y_VIM)));
    
    perm_stats = rm_anova2(Y_STN_rand,S_STN,F1_STN,F2_STN,factnames);
    STN_typeF(ip) = perm_stats{2,5};
    STN_timeF(ip) = perm_stats{3,5};
    STN_intF(ip) = perm_stats{4,5};
    
    perm_stats = rm_anova2(Y_VIM_rand,S_VIM,F1_VIM,F2_VIM,factnames);
    VIM_typeF(ip) = perm_stats{2,5};
    VIM_timeF(ip) = perm_stats{3,5};
    VIM_intF(ip) = perm_stats{4,5};
end
% define sig cutoff based on permutations
STN_typecutoff = quantile(STN_typeF,0.95); VIM_typecutoff = quantile(VIM_typeF,0.95);
STN_timecutoff = quantile(STN_timeF,0.95); VIM_timecutoff = quantile(VIM_timeF,0.95);
STN_intcutoff = quantile(STN_intF,0.95); VIM_intcutoff = quantile(VIM_intF,0.95);

% run actual value ANOVA
STN_final_stats = rm_anova2(Y_STN,S_STN,F1_STN,F2_STN,factnames);
VIM_final_stats = rm_anova2(Y_VIM,S_VIM,F1_VIM,F2_VIM,factnames);
disp('Subcortical bursts locked to M1 bursts: ');
disp('Significant effects in STN sample: ');
if STN_final_stats{2,5} > STN_typecutoff
    disp(['Trial type: F = ' num2str(STN_final_stats{2,5}) ', p = ' num2str(STN_final_stats{2,6})]);
end
if STN_final_stats{3,5} > STN_timecutoff
    disp(['Timepoint: F = ' num2str(STN_final_stats{3,5}) ', p = ' num2str(STN_final_stats{3,6})]);
end
if STN_final_stats{4,5} > STN_intcutoff
    disp(['Trial x time interaction: F = ' num2str(STN_final_stats{4,5}) ', p = ' num2str(STN_final_stats{4,6})]);
end

disp('Significant effects in VIM sample: ');
if VIM_final_stats{2,5} > VIM_typecutoff
    disp(['Trial type: F = ' num2str(VIM_final_stats{2,5}) ', p = ' num2str(VIM_final_stats{2,6})]);
end
if VIM_final_stats{3,5} > VIM_timecutoff
    disp(['Timepoint: F = ' num2str(VIM_final_stats{3,5}) ', p = ' num2str(VIM_final_stats{3,6})]);
end
if VIM_final_stats{4,5} > VIM_intcutoff
    disp(['Trial x time interaction: F = ' num2str(VIM_final_stats{4,5}) ', p = ' num2str(VIM_final_stats{4,6})]);
end

% parse individual time points using monte carlo t tests
for it = 1:length(M1bins)-1
    [~,STN_gop(it)] = ttest(SUCC_main(stn,it),MATCH_main(stn,it));
    [~,VIM_gop(it)] = ttest(SUCC_main(thaplt,it),MATCH_main(thaplt,it));
    [~,STN_failp(it)] = ttest(SUCC_main(stn,it),FAIL_main(stn,it));
    [~,VIM_failp(it)] = ttest(SUCC_main(thaplt,it),FAIL_main(thaplt,it));
end
corrected_go_STNp = bonf_holm(STN_gop); corrected_fail_STNp = bonf_holm(STN_failp);
corrected_go_VIMp = bonf_holm(VIM_gop); corrected_fail_VIMp = bonf_holm(VIM_failp);
disp('STN sample - Significant burst differences were seen between SS and Go trials at these time points:');
for it = 1:length(M1bins)-1
    if corrected_go_STNp(it)<=.05; disp([num2str(M1bins(it)) ' to ' num2str(M1bins(it+1)) 'ms: p = ' num2str(corrected_go_STNp(it))]); end
end
disp('STN sample - Significant burst differences were seen between SS and FS trials at these time points:');
for it = 1:length(M1bins)-1
    if corrected_fail_STNp(it)<=.05; disp([num2str(M1bins(it)) ' to ' num2str(M1bins(it+1)) 'ms: p = ' num2str(corrected_fail_STNp(it))]); end
end
disp('VIM sample - Significant burst differences were seen between SS and Go trials at these time points:');
for it = 1:length(M1bins)-1
    if corrected_go_VIMp(it)<=.05; disp([num2str(M1bins(it)) ' to ' num2str(M1bins(it+1)) 'ms: p = ' num2str(corrected_go_VIMp(it))]); end
end
disp('VIM sample - Significant burst differences were seen between SS and FS trials at these time points:');
for it = 1:length(M1bins)-1
    if corrected_fail_VIMp(it)<=.05; disp([num2str(M1bins(it)) ' to ' num2str(M1bins(it+1)) 'ms: p = ' num2str(corrected_fail_VIMp(it))]); end
end

% do stats for dorsal thalamus
% set up 2-way (condition x time) ANOVA w/permutations
% set up matrices
Y_VIM = []; S_VIM = []; F1_VIM = []; F2_VIM = [];
for is = tha
    subs = repmat(is,1,(length(M1bins)-1)*3)'; f1 = [ones(1,length(M1bins)-1) repmat(2,1,length(M1bins)-1) repmat(3,1,length(M1bins)-1)]';
    f2 = repmat(1:length(M1bins)-1,1,3)';
    if isempty(Y_VIM)
        Y_VIM = [D_FAIL_main(is,:) D_SUCC_main(is,:) D_MATCH_main(is,:)]';
        S_VIM = subs; F1_VIM = f1; F2_VIM = f2;
    else
        Y_VIM = [Y_VIM; [D_FAIL_main(is,:) D_SUCC_main(is,:) D_MATCH_main(is,:)]'];
        S_VIM = [S_VIM; subs]; F1_VIM = [F1_VIM; f1];
        F2_VIM = [F2_VIM; f2];
    end
end
factnames = {'trialtype','timepoint'};
perm = 10000; % how many times to run
disp(['Please wait... completing permutation...']);
% run permutations to bootstrap
for ip = 1:perm
    permstats = [];
    Y_VIM_rand = Y_VIM(randperm(length(Y_VIM)));

    perm_stats = rm_anova2(Y_VIM_rand,S_VIM,F1_VIM,F2_VIM,factnames);
    VIM_typeF(ip) = perm_stats{2,5};
    VIM_timeF(ip) = perm_stats{3,5};
    VIM_intF(ip) = perm_stats{4,5};
end
% define sig cutoff based on permutations
VIM_typecutoff = quantile(VIM_typeF,0.95);
VIM_timecutoff = quantile(VIM_timeF,0.95);
VIM_intcutoff = quantile(VIM_intF,0.95);

% run actual value ANOVA
VIM_final_stats = rm_anova2(Y_VIM,S_VIM,F1_VIM,F2_VIM,factnames);

disp('Significant effects in dorsal thal: ');
if VIM_final_stats{2,5} > VIM_typecutoff
    disp(['Trial type: F = ' num2str(VIM_final_stats{2,5}) ', p = ' num2str(VIM_final_stats{2,6})]);
end
if VIM_final_stats{3,5} > VIM_timecutoff
    disp(['Timepoint: F = ' num2str(VIM_final_stats{3,5}) ', p = ' num2str(VIM_final_stats{3,6})]);
end
if VIM_final_stats{4,5} > VIM_intcutoff
    disp(['Trial x time interaction: F = ' num2str(VIM_final_stats{4,5}) ', p = ' num2str(VIM_final_stats{4,6})]);
end

% parse individual time points using monte carlo t tests
for it = 1:length(M1bins)-1
    [~,VIM_gop(it)] = ttest(D_SUCC_main(thaplt,it),D_MATCH_main(thaplt,it));
    [~,VIM_failp(it)] = ttest(D_SUCC_main(thaplt,it),D_FAIL_main(thaplt,it));
end
corrected_go_VIMp = bonf_holm(VIM_gop); corrected_fail_VIMp = bonf_holm(VIM_failp);
disp('Dorsal thal - Significant burst differences were seen between SS and Go trials at these time points:');
for it = 1:length(M1bins)-1
    if corrected_go_VIMp(it)<=.05; disp([num2str(M1bins(it)) ' to ' num2str(M1bins(it+1)) 'ms: p = ' num2str(corrected_go_VIMp(it))]); end
end
disp('Dorsal thal - Significant burst differences were seen between SS and FS trials at these time points:');
for it = 1:length(M1bins)-1
    if corrected_fail_VIMp(it)<=.05; disp([num2str(M1bins(it)) ' to ' num2str(M1bins(it+1)) 'ms: p = ' num2str(corrected_fail_VIMp(it))]); end
end

% barweb fig - bg after m1, gos
h = figure('Position',[1 1 1000 1000],'Color','w');
subplot(2,1,1); 
barweb([mean(SUCC_main(stn,:),1);mean(MATCH_main(stn,:),1)]',[sem(SUCC_main(stn,:));sem(MATCH_main(stn,:))]',.8,cellfun(@num2str,num2cell(M1bins(2:end)),'UniformOutput',0),'Beta bursts at STN following M1 bursts', 'time (ms) from M1 burst', 'proportion of trials', '', '', {'Stop','Matched go'});
hold on;
for ib = 1:length(M1bins)-1
    scatter(repmat(ib-.15,1,length(SUCC_main(stn,ib))),SUCC_main(stn,ib),64,'Jitter','on','JitterAmount',0.05,'MarkerEdgeColor','k','MarkerFaceColor',[.7 .7 .7],'MarkerFaceAlpha',0.5);
    scatter(repmat(ib+.15,1,length(MATCH_main(stn,ib))),MATCH_main(stn,ib),64,'Jitter','on','JitterAmount',0.05,'MarkerEdgeColor','k','MarkerFaceColor',[.7 .7 .7],'MarkerFaceAlpha',0.5);
end
set(gca,'Ylim',[0 .6]);

% barweb fig - vim after m1, gos
subplot(2,1,2); 
barweb([mean(SUCC_main(thaplt,:),1);mean(MATCH_main(thaplt,:),1)]',[sem(SUCC_main(thaplt,:));sem(MATCH_main(thaplt,:))]',.8,cellfun(@num2str,num2cell(M1bins(2:end)),'UniformOutput',0),'Beta bursts at VIM following M1 bursts', 'time (ms) from M1 burst', 'proportion of trials', '', '', {'Stop','Matched go'});
hold on;
for ib = 1:length(M1bins)-1
    scatter(repmat(ib-.15,1,length(SUCC_main(thaplt,ib))),SUCC_main(thaplt,ib),64,'Jitter','on','JitterAmount',0.05,'MarkerEdgeColor','k','MarkerFaceColor',[.7 .7 .7],'MarkerFaceAlpha',0.5);
    scatter(repmat(ib+.15,1,length(MATCH_main(thaplt,ib))),MATCH_main(thaplt,ib),64,'Jitter','on','JitterAmount',0.05,'MarkerEdgeColor','k','MarkerFaceColor',[.7 .7 .7],'MarkerFaceAlpha',0.5);
end
set(gca,'Ylim',[0 .6]);

% Figure for dorsal thal
h = figure('Position',[1 1 1000 1000],'Color','w');
barweb([mean(D_SUCC_main(tha,:),1);mean(D_MATCH_main(tha,:),1)]',[sem(D_SUCC_main(tha,:));sem(D_MATCH_main(tha,:))]',.8,cellfun(@num2str,num2cell(M1bins(2:end)),'UniformOutput',0),'Beta bursts at dorsal thalamus following M1 bursts', 'time (ms) from M1 burst', 'proportion of trials', '', '', {'Stop','Matched go'});
hold on;
for ib = 1:length(M1bins)-1
    scatter(repmat(ib-.15,1,length(D_SUCC_main(tha,ib))),D_SUCC_main(tha,ib),64,'Jitter','on','JitterAmount',0.05,'MarkerEdgeColor','k','MarkerFaceColor',[.7 .7 .7],'MarkerFaceAlpha',0.5);
    scatter(repmat(ib+.15,1,length(D_MATCH_main(tha,ib))),D_MATCH_main(tha,ib),64,'Jitter','on','JitterAmount',0.05,'MarkerEdgeColor','k','MarkerFaceColor',[.7 .7 .7],'MarkerFaceAlpha',0.5);
end
set(gca,'Ylim',[0 .5]);