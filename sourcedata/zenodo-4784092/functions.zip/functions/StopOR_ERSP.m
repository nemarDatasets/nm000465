%% Make average ERSPs at subgaleal electrodes
% This script makes and plots broadband ERSPs following go trials in the
% localizer and main blocks. The figures will open in a separate window.
% Setup
plotlimits = [-500 1500];
baseline = [-500 -200];
minRT = 200;
freqs = 1:50;
method = 'db';

% Subgaleal ERSPs - localizer block only
for is = [1:6 8:20]
   
    subnum = datasets(is).subnum;
    load(fullfile(folders.pp,['Subject' num2str(subnum) '-localizer.mat'])); LFP.etc = [];
    load(fullfile(folders.pp,['ManualRej' num2str(subnum) '_localizer.mat']),'rejpoints','rejections');

    rm1_chans = find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'R subgaleal'))); % R M1 channels
    lm1_chans = find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'L subgaleal'))); % L M1 channels
    locations = {'rm1','lm1'}; % all possible contacts
    
    % go through locations and make bipolar data with contacts available
    newchanlocs = []; % will be appended
    newdata = []; % will be appended
    for il = 1:length(locations)
        % check if location is present in subject
        loclabel = [locations{il} '_chans'];
        eval(['locchans = ' loclabel ';']);
        if ~isempty(locchans)
            % go through location channels and make data and chanlabel
            locdata = zeros(length(locchans)-1,LFP.pnts);
            locchanlocs = LFP.chanlocs(1);  % will be overwritten, adopt structure layout
            for ilc = 1:length(locchans)-1
                locdata(ilc,:) = LFP.data(locchans(ilc),:) - LFP.data(locchans(ilc+1),:);
                locchanlocs(ilc).labels = [locations{il} '_' num2str(ilc)];
            end
            % identify new channel indices
            eval([loclabel ' = [' num2str(length(newchanlocs)+1:length(newchanlocs)+length(locchanlocs)) '];']);
            % append data and chanlocs
            newchanlocs = [newchanlocs locchanlocs];
            newdata = [newdata; locdata];
        end
    end
    
    % insert bipolar arrays into main EEGLab structure
    LFP.data = newdata; LFP.chanlocs = newchanlocs; LFP.nbchan = length(LFP.chanlocs);

    % reject segments marked for rejection due to artifact
    LFP = pop_select(LFP,'nopoint',rejpoints);
    
    % identify chans to use from which were used in burst analyses
    load(fullfile('/data/backed_up/StopOR/beta',['Subject' num2str(subnum) '.mat']));
    rightchan = str2num(chanlabels{3}(5));
    if is == 2
        chans = [2 1];
    else
        leftchan = str2num(chanlabels{4}(5))+3;
        rightchan = str2num(chanlabels{3}(5));
        chans = [rightchan leftchan];
    end

    % get evs
    evs = LFP.event;
    
    % pick correct go trials only
    goevs = evs(strcmpi({evs.type},'GoStimulus'));
    gocorevs = goevs([goevs.acc]==1); % acc only
    gocorevs = gocorevs([gocorevs.rt]>minRT); % > minRT

    clear elats
    elats.go_L = [gocorevs([gocorevs.resp_side]==1).latency];
    elats.go_R = [gocorevs([gocorevs.resp_side]==3).latency]; % this task has right paddle = 3 
    for ic = 1:length(chans)
        eval(['gooutput.c' num2str(ic) ' = ersp(LFP,2,' num2str(chans(ic)) ',elats,plotlimits,baseline,freqs,.5,method);']);
    end
   
    savfile = ['Subject' num2str(subnum) '_ERSP-motor_localizer.mat'];
    erspfolder = '/data/backed_up/StopOR/ersp';
    save(fullfile(folders.ersp,savfile),'gooutput');
    
end

%% Subgaleal ERSP matrices - main block
respplotlimits = [-1000 1000]; respbaseline = [-1100 -1000];
for is = 1:length(datasets)
    
    subnum = datasets(is).subnum;
    load(fullfile(folders.pp,['Subject' num2str(subnum) '-LFP.mat'])); LFP.etc = [];
    load(fullfile(folders.pp,['ManualRej' num2str(subnum) '.mat']),'rejpoints','rejections');
    
    rm1_chans = find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'R subgaleal'))); % R M1 channels
    lm1_chans = find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'L subgaleal'))); % L M1 channels
    number_of_locations = ~isempty(rm1_chans) + ~isempty(lm1_chans);
    locations = {'rm1','lm1'}; % all possible contacts
    
    % go through locations and make bipolar data with contacts available
    newchanlocs = []; % will be appended
    newdata = []; % will be appended
    for il = 1:length(locations)
        % check if location is present in subject
        loclabel = [locations{il} '_chans'];
        eval(['locchans = ' loclabel ';']);
        if ~isempty(locchans)
            % go through location channels and make data and chanlabel
            locdata = zeros(length(locchans)-1,LFP.pnts);
            locchanlocs = LFP.chanlocs(1);  % will be overwritten, adopt structure layout
            for ilc = 1:length(locchans)-1
                locdata(ilc,:) = LFP.data(locchans(ilc),:) - LFP.data(locchans(ilc+1),:);
                locchanlocs(ilc).labels = [locations{il} '_' num2str(ilc)];
            end
            % identify new channel indices
            eval([loclabel ' = [' num2str(length(newchanlocs)+1:length(newchanlocs)+length(locchanlocs)) '];']);
            % append data and chanlocs
            newchanlocs = [newchanlocs locchanlocs];
            newdata = [newdata; locdata];
        end
    end
    
    % insert bipolar arrays into main EEGLab structure
    LFP.data = newdata; LFP.chanlocs = newchanlocs; LFP.nbchan = length(LFP.chanlocs);

    % reject segments marked for rejection due to artifact
    LFP = pop_select(LFP,'nopoint',rejpoints);
    
    % identify chans to use from which were used in burst analyses
    load(fullfile('/data/backed_up/StopOR/beta',['Subject' num2str(subnum) '.mat']));
    if ~isempty(intersect(is,stn))
        rightchan = str2num(chanlabels{3}(5));
        leftchan = str2num(chanlabels{4}(5))+3;
    else
        rightchan = str2num(chanlabels{1}(5));
        leftchan = str2num(chanlabels{2}(5))+3;
    end
    if is == 2
        chans = [2 1];
        allchans = [2 1];
    else
        chans = [rightchan leftchan];
        rightchannels = []; leftchannels = [];
        if rightchan > 1 && lm1_chans(1)-rightchan > 1
            rightchannels = [rightchan-1 rightchan rightchan+1];
        elseif rightchan > 1 && lm1_chans(1)-rightchan <= 1
            rightchannels = [rightchan-1 rightchan];
        elseif rightchan == rm1_chans(1)
            rightchannels = [rightchan rightchan+1];
        end
        if leftchan == lm1_chans(end)
            leftchannels = [leftchan-1 leftchan];
        elseif leftchan > lm1_chans(1) && lm1_chans(1)-rightchan > 1
            leftchannels = [leftchan-1 leftchan leftchan+1];
        elseif leftchan == lm1_chans(1)
            leftchannels = [leftchan leftchan+1];
        end
        allchans = [rightchannels leftchannels]; % selected and adjacent channels
            
    end
    
    % get evs
    evs = LFP.event;
    
    % pick correct go trials only
    goevs = evs(strcmpi({evs.type},'GoStimulus'));
    gocorevs = goevs([goevs.acc]==1); % acc only
    gocorevs = gocorevs([gocorevs.rt]>minRT); % > minRT

    clear elats
    elats.go_L = [gocorevs([gocorevs.resp_side]==1).latency];
    elats.go_R = [gocorevs([gocorevs.resp_side]==3).latency]; % this task has right paddle = 3 for some reason
    for ic = 1:length(chans)
        eval(['gooutput.c' num2str(ic) ' = ersp(LFP,2,' num2str(chans(ic)) ',elats,plotlimits,baseline,freqs,.5,method);']);
    end
    
    % pick correct go trials only
    respevs = evs(strcmpi({evs.type},'Response'));
    respcorevs = respevs([respevs.acc]==1); % acc only
    respcorevs = respcorevs([respcorevs.rt]>minRT); % > minRT

    clear elats
    elats.resp_L = [respcorevs([respcorevs.resp_side]==1).latency];
    elats.resp_R = [respcorevs([respcorevs.resp_side]==3).latency]; % this task has right paddle = 3 for some reason
    for ic = 1:length(allchans)
        eval(['respoutput.c' num2str(ic) ' = ersp(LFP,2,' num2str(allchans(ic)) ',elats,respplotlimits,respbaseline,freqs,.5,method);']);
    end
    
    savfile = ['Subject' num2str(subnum) '_ERSP-motor.mat'];
    erspfolder = '/data/backed_up/StopOR/ersp';
    save(fullfile(folders.ersp,savfile),'gooutput','respoutput');
    
end

%% Subgaleal ERSP Figure for go trials - localizer block
clear dataL* dataR*
timelimits = [-1000 1000]; baselinelimits = [-1100 -1000]; ylim = 50;
for is = [1:6 8:20] 
    subnum = datasets(is).subnum;
    filename = ['Subject' num2str(subnum) '_ERSP-motor_localizer.mat'];
    load(fullfile(folders.ersp,filename));
    
    dataR_ipsi(is,:,:) = gooutput.c2.ersp.go_R;
    dataR_contra(is,:,:) = gooutput.c2.ersp.go_L;
    dataL_ipsi(is,:,:) = gooutput.c1.ersp.go_L;
    dataL_contra(is,:,:) = gooutput.c1.ersp.go_R;
end

dataR = squeeze(mean(dataR_contra,1));
dataL = squeeze(mean(dataL_contra,1));

% save grand average ersp matrices for correction
save(fullfile(folders.ersp,['RM1_Gotrials_main']),'dataR_contra','dataR_ipsi'); 
save(fullfile(folders.ersp,['LM1_Gotrials_main']),'dataL_contra','dataL_ipsi'); 

% make figure
figure('Color','w'); 
    
% plot Right M1
subplot(1,2,1);
hold,pcolor(dataL),shading interp, colormap jet;
% lines
line([abs(timelimits(1)) abs(timelimits(1))],[0 ylim],'Color','k','LineStyle','-');

% format
set(gca,'Xtick',[abs(timelimits(1)) abs(timelimits(1))+abs(timelimits(2))],'Xticklabel',{'Stim','1500ms'});
set(gca,'XLim',[abs(timelimits(1))-abs(baselinelimits(1)) abs(timelimits(1))+timelimits(2)],'YLim',[1 ylim]);
title('Left M1, Contralateral responses');
c = colorbar; c.Label.String = 'db';
set(gca,'Clim',[-6 6]);

% plot Left M1
subplot(1,2,2)
hold,pcolor(dataR),shading interp,colormap jet;
% lines
line([abs(timelimits(1)) abs(timelimits(1))],[0 ylim],'Color','k','LineStyle','-');
% format
set(gca,'Xtick',[abs(timelimits(1)) abs(timelimits(1))+abs(timelimits(2))],'Xticklabel',{'Stim','1500ms'});
set(gca,'XLim',[abs(timelimits(1))-abs(baselinelimits(1)) abs(timelimits(1))+timelimits(2)],'YLim',[1 ylim]);
title('Right M1, Contralateral responses');
c = colorbar; c.Label.String = 'db';
set(gca,'Clim',[-6 6]);

% Subgaleal ERSP Figure for go trials - main block
clear dataL* dataR*
timelimits = [-500 1500]; baselinelimits = [-100 0]; ylim = 50;
for is = 1:length(datasets)
    subnum = datasets(is).subnum;
    filename = ['Subject' num2str(subnum) '_ERSP-motor.mat'];
    load(fullfile(folders.ersp,filename));
    
    dataR_ipsi(is,:,:) = gooutput.c2.ersp.go_R;
    dataR_contra(is,:,:) = gooutput.c2.ersp.go_L;
    dataL_ipsi(is,:,:) = gooutput.c1.ersp.go_L;
    dataL_contra(is,:,:) = gooutput.c1.ersp.go_R;
end

dataR = squeeze(mean(dataR_contra,1));
dataL = squeeze(mean(dataL_contra,1));

% save grand average ersp matrices for correction
save(fullfile(folders.ersp,['RM1_Gotrials_main']),'dataR_contra','dataR_ipsi'); 
save(fullfile(folders.ersp,['LM1_Gotrials_main']),'dataL_contra','dataL_ipsi'); 

% make figure
figure('Color','w'); 
    
% plot Right M1
subplot(1,2,1);
hold,pcolor(dataL),shading interp,colormap jet;
% lines
line([abs(timelimits(1)) abs(timelimits(1))],[0 ylim],'Color','k','LineStyle','-');

% format
set(gca,'Xtick',[abs(timelimits(1)) abs(timelimits(1))+abs(timelimits(2))],'Xticklabel',{'Stim','1500ms'});
set(gca,'XLim',[abs(timelimits(1))-abs(baselinelimits(1)) abs(timelimits(1))+timelimits(2)],'YLim',[1 ylim]);
title('Left M1, Contralateral responses');
c = colorbar; c.Label.String = 'db';
set(gca,'Clim',[-6 6]);

% plot Left M1
subplot(1,2,2)
hold,pcolor(dataR),shading interp,colormap jet;
% lines
line([abs(timelimits(1)) abs(timelimits(1))],[0 ylim],'Color','k','LineStyle','-');
% format
set(gca,'Xtick',[abs(timelimits(1)) abs(timelimits(1))+abs(timelimits(2))],'Xticklabel',{'Stim','1500ms'});
set(gca,'XLim',[abs(timelimits(1))-abs(baselinelimits(1)) abs(timelimits(1))+timelimits(2)],'YLim',[1 ylim]);
title('Right M1, Contralateral responses');
c = colorbar; c.Label.String = 'db';
set(gca,'Clim',[-6 6]);

%% Subgaleal ERSP Figure for RESPONSE-locked go trials - main block
clear dataL* dataR*
timelimits = [-1000 1000]; baselinelimits = [-1100 -1000]; ylim = 50;
for is = 1:length(datasets)
    subnum = datasets(is).subnum;
    clear chans
    
    % identify selected and adjacent chans
    load(fullfile(folders.pp,['Subject' num2str(subnum) '-LFP.mat'])); LFP.etc = [];    
    rm1_chans = find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'R subgaleal')));
    lm1_chans = find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'L subgaleal')));
    load(fullfile(folders.beta,['Subject' num2str(subnum) '.mat']));
    if is == 2
        rightsel = 1; rightbefore = []; rightafter = [];
        leftsel = 2; leftbefore = []; leftafter = [];
    else
        if ~isempty(intersect(is,stn))
            rightsel = str2num(chanlabels{3}(5));
            leftsel = str2num(chanlabels{4}(5))+length(rm1_chans)-1;
        else
            rightsel = str2num(chanlabels{1}(5));
            leftsel = str2num(chanlabels{2}(5))+length(rm1_chans)-1;
        end
        if rightsel > 1 && (lm1_chans(1)-1)-rightsel > 1
            rightbefore = rightsel-1;
            rightafter = rightsel+1;
        elseif rightsel > 1 && (lm1_chans(1)-1)-rightsel <= 1
            rightbefore = rightsel-1;
            rightafter = [];
        elseif rightsel == rm1_chans(1)
            rightbefore = [];
            rightafter = rightsel+1;
        end
        if leftsel == length(rm1_chans)+length(lm1_chans)-2
            leftbefore = leftsel-1;
            leftafter = [];
        elseif leftsel > length(lm1_chans) && leftsel-rightsel > 1
            leftbefore = leftsel-1;
            leftafter = leftsel+1;
        elseif leftsel == length(lm1_chans)
            leftbefore = [];
            leftafter = leftsel+1;
        end         
        chans = [rightbefore rightsel rightafter leftbefore leftsel leftafter];
        if ~isempty(leftbefore); leftbefore = find(chans==leftbefore); end
        leftsel = find(chans==leftsel);
        if ~isempty(leftafter); leftafter = find(chans==leftafter); end
    end
    
    filename = ['Subject' num2str(subnum) '_ERSP-motor.mat'];
    load(fullfile(folders.ersp,filename));
    
    if ~isempty(rightbefore)
        eval(['dataRbefore_contra(is,:,:) = respoutput.c' num2str(rightbefore) '.ersp.resp_L;']);  
    else
        dataRbefore_contra(is,:,:) = nan(50,2001);
    end
    eval(['dataRsel_contra(is,:,:) = respoutput.c' num2str(rightsel) '.ersp.resp_L;']);
    if ~isempty(rightafter)
        eval(['dataRafter_contra(is,:,:) = respoutput.c' num2str(rightafter) '.ersp.resp_L;']);
    else
        dataRafter_contra(is,:,:) = nan(50,2001);
    end
    if ~isempty(leftbefore)
        eval(['dataLbefore_contra(is,:,:) = respoutput.c' num2str(leftbefore) '.ersp.resp_R;']);  
    else
        dataLbefore_contra(is,:,:) = nan(50,2001);
    end
    eval(['dataLsel_contra(is,:,:) = respoutput.c' num2str(leftsel) '.ersp.resp_R;']);
    if ~isempty(leftafter)      
        eval(['dataLafter_contra(is,:,:) = respoutput.c' num2str(leftafter) '.ersp.resp_R;']);  
    else
        dataLafter_contra(is,:,:) = nan(50,2001);
    end
end

dataRbefore = squeeze(nanmean(dataRbefore_contra,1));
dataRsel = squeeze(nanmean(dataRsel_contra,1));
dataRafter = squeeze(nanmean(dataRafter_contra,1));
dataLbefore = squeeze(nanmean(dataLbefore_contra,1));
dataLsel = squeeze(nanmean(dataLsel_contra,1));
dataLafter = squeeze(nanmean(dataLafter_contra,1));

% make figure
figure('Color','w'); 
    
% plot Right M1
subplot(2,3,1);
% one before selected
hold,pcolor(dataRbefore),shading interp,colormap jet;
% lines
line([abs(timelimits(1)) abs(timelimits(1))],[0 ylim],'Color','k','LineStyle','-');
% format
set(gca,'Xtick',[1 abs(timelimits(1)) abs(timelimits(1))+abs(timelimits(2))],'Xticklabel',{'-1000','Resp','1000ms'});
set(gca,'XLim',[1 abs(timelimits(1))+timelimits(2)],'YLim',[1 ylim]);
title('Right M1, contact before selected');
c = colorbar; c.Label.String = 'db';
set(gca,'Clim',[-6 2]);
% selected
subplot(2,3,2);
hold,pcolor(dataRsel),shading interp,colormap jet;
% lines
line([abs(timelimits(1)) abs(timelimits(1))],[0 ylim],'Color','k','LineStyle','-');
% format
set(gca,'Xtick',[1 abs(timelimits(1)) abs(timelimits(1))+abs(timelimits(2))],'Xticklabel',{'-1000','Resp','1000ms'});
set(gca,'XLim',[1 abs(timelimits(1))+timelimits(2)],'YLim',[1 ylim]);
title('Right M1, selected contact');
c = colorbar; c.Label.String = 'db';
set(gca,'Clim',[-6 2]);
% one after selected
subplot(2,3,3);
hold,pcolor(dataRafter),shading interp,colormap jet;
% lines
line([abs(timelimits(1)) abs(timelimits(1))],[0 ylim],'Color','k','LineStyle','-');
% format
set(gca,'Xtick',[1 abs(timelimits(1)) abs(timelimits(1))+abs(timelimits(2))],'Xticklabel',{'-1000','Resp','1000ms'});
set(gca,'XLim',[1 abs(timelimits(1))+timelimits(2)],'YLim',[1 ylim]);
title('Right M1, contact after selected');
c = colorbar; c.Label.String = 'db';
set(gca,'Clim',[-6 2]);

% plot Right M1
subplot(2,3,4);
% one before selected
hold,pcolor(dataLbefore),shading interp,colormap jet;
% lines
line([abs(timelimits(1)) abs(timelimits(1))],[0 ylim],'Color','k','LineStyle','-');
% format
set(gca,'Xtick',[1 abs(timelimits(1)) abs(timelimits(1))+abs(timelimits(2))],'Xticklabel',{'-1000','Resp','1000ms'});
set(gca,'XLim',[1 abs(timelimits(1))+timelimits(2)],'YLim',[1 ylim]);
title('Left M1, contact before selected');
c = colorbar; c.Label.String = 'db';
set(gca,'Clim',[-6 2]);
% selected
subplot(2,3,5);
hold,pcolor(dataLsel),shading interp,colormap jet;
% lines
line([abs(timelimits(1)) abs(timelimits(1))],[0 ylim],'Color','k','LineStyle','-');
% format
set(gca,'Xtick',[1 abs(timelimits(1)) abs(timelimits(1))+abs(timelimits(2))],'Xticklabel',{'-1000','Resp','1000ms'});
set(gca,'XLim',[1 abs(timelimits(1))+timelimits(2)],'YLim',[1 ylim]);
title('Left M1, selected contact');
c = colorbar; c.Label.String = 'db';
set(gca,'Clim',[-6 2]);
% one after selected
subplot(2,3,6);
hold,pcolor(dataLafter),shading interp,colormap jet;
% lines
line([abs(timelimits(1)) abs(timelimits(1))],[0 ylim],'Color','k','LineStyle','-');
% format
set(gca,'Xtick',[1 abs(timelimits(1)) abs(timelimits(1))+abs(timelimits(2))],'Xticklabel',{'-1000','Resp','1000ms'});
set(gca,'XLim',[1 abs(timelimits(1))+timelimits(2)],'YLim',[1 ylim]);
title('Left M1, contact after selected');
c = colorbar; c.Label.String = 'db';
set(gca,'Clim',[-6 2]);
%% Depth electrode ERSP matrices for STN
for is = stn
    
    subnum = datasets(is).subnum;
    load(fullfile(folders.pp,['Subject' num2str(subnum) '-LFP.mat'])); LFP.etc = [];
    load(fullfile(folders.beta,['Subject' num2str(subnum) '.mat']));

    % make dipolar stn
    rstn_chans = find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'R STN'))); % R STN channels
    if ~isempty(rstn_chans); rstn_chans = [find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'R STN LFP 0'))) find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'R STN LFP 1'))) find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'R STN LFP 2'))) find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'R STN LFP 3')))]; end
    lstn_chans = find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'L STN'))); % L STN channels
    if ~isempty(lstn_chans); lstn_chans = [find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'L STN LFP 0'))) find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'L STN LFP 1'))) find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'L STN LFP 2'))) find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'L STN LFP 3')))]; end
    rm1_chans = find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'R subgaleal'))); % R M1 channels
    lm1_chans = find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'L subgaleal'))); % L M1 channels
    number_of_locations = ~isempty(rstn_chans) + ~isempty(lstn_chans) + ~isempty(rm1_chans) + ~isempty(lm1_chans);
    locations = {'rstn','lstn','rm1','lm1'}; % all possible contacts
  
    % go through locations and make bipolar data with contacts available
    newchanlocs = []; % will be appended
    newdata = []; % will be appended
    for il = 1:length(locations)
        % check if location is present in subject
        loclabel = [locations{il} '_chans'];
        eval(['locchans = ' loclabel ';']);
        if ~isempty(locchans)
            % go through location channels and make data and chanlabel
            locdata = zeros(length(locchans)-1,LFP.pnts);
            locchanlocs = LFP.chanlocs(1);  % will be overwritten, adopt structure layout
            for ilc = 1:length(locchans)-1
                locdata(ilc,:) = LFP.data(locchans(ilc),:) - LFP.data(locchans(ilc+1),:);
                locchanlocs(ilc).labels = [locations{il} '_' num2str(ilc)];
            end
            % identify new channel indices
            eval([loclabel ' = [' num2str(length(newchanlocs)+1:length(newchanlocs)+length(locchanlocs)) '];']);
            % append data and chanlocs
            newchanlocs = [newchanlocs locchanlocs];
            newdata = [newdata; locdata];
        end
    end
    LFP.data = newdata; LFP.chanlocs = newchanlocs; LFP.nbchan = length(LFP.chanlocs);

    load(fullfile(folders.pp,['ManualRej' num2str(subnum) '.mat']),'rejpoints','rejections');
    LFP = pop_select(LFP,'nopoint',rejpoints);
    
    % get evs
    evs = LFP.event;
    
    % identify chans to use
    [~,rbgchan] = intersect({LFP.chanlocs.labels},chanlabels(~cellfun(@isempty,strfind(chanlabels,'rstn'))));
    [~,lbgchan] = intersect({LFP.chanlocs.labels},chanlabels(~cellfun(@isempty,strfind(chanlabels,'lstn'))));
    chans = [rbgchan,lbgchan];
    
    % pick correct go trials only
    goevs = evs(strcmpi({evs.type},'GoStimulus'));
    gocorevs = goevs([goevs.acc]==1); % acc only
    gocorevs = gocorevs([gocorevs.rt]>minRT); % > minRT
    
    % pick successful stops only
    stopevs = evs(strcmpi({evs.type},'StopStimulus'));
    stopcorevs = stopevs([stopevs.acc]==3); % succ only
    
    % pick failed stops only
    failevs = evs(strcmpi({evs.type},'StopStimulus'));
    failcorevs = failevs([failevs.acc]==4); % fail only
    failcorevs = failcorevs([failcorevs.rt]>minRT); % > minRT
    
    clear elats
    elats.go = [gocorevs.latency];
    for ic = 1:length(chans)
        eval(['gooutput.c' num2str(ic) ' = ersp(LFP,2,' num2str(chans(ic)) ',elats,plotlimits,baseline,freqs,.5,method);']);
    end
    
    clear elats
    elats.stop = [stopcorevs.latency];
    for ic = 1:length(chans)
        eval(['stopoutput.c' num2str(ic) ' = ersp(LFP,2,' num2str(chans(ic)) ',elats,plotlimits,baseline,freqs,.5,method);']);
    end
      
    clear elats
    elats.fail = [failcorevs.latency];
    for ic = 1:length(chans)
        eval(['failoutput.c' num2str(ic) ' = ersp(LFP,2,' num2str(chans(ic)) ',elats,plotlimits,baseline,freqs,.5,method);']);
    end
    savfile = ['Subject' num2str(subnum) '_ERSP-stn.mat'];
    save(fullfile(folders.ersp,savfile),'gooutput','stopoutput','failoutput');

end

% make figure
% STN ERSP Figure for stop-go trials - main block
clear dataL* dataR*
timelimits = [-500 1500]; baselinelimits = [-100 0]; ylim = 50;
for is = stn
    subnum = datasets(is).subnum;
    filename = ['Subject' num2str(subnum) '_ERSP-stn.mat'];
    load(fullfile(folders.ersp,filename));
    
    dataR(is,:,:) = stopoutput.c2.ersp.stop-gooutput.c2.ersp.go;
    dataL(is,:,:) = stopoutput.c1.ersp.stop-gooutput.c1.ersp.go;% plotleft STN
subplot(1,2,1);
hold,pcolor(dataL),shading interp, colormap jet;
% lines
line([abs(timelimits(1)) abs(timelimits(1))],[0 ylim],'Color','k','LineStyle','-');

% format
set(gca,'Xtick',[abs(timelimits(1)) abs(timelimits(1))+abs(timelimits(2))],'Xticklabel',{'Stim','1500ms'});
set(gca,'XLim',[abs(timelimits(1))-abs(baselinelimits(1)) abs(timelimits(1))+timelimits(2)],'YLim',[0 ylim]);
title('Left STN, stop-go trials');
c = colorbar; c.Label.String = 'db';
set(gca,'Clim',[-3 3]);

end

dataR = squeeze(mean(dataR,1));
dataL = squeeze(mean(dataL,1));

figure('Color','w'); 
    

% plot right STN
subplot(1,2,2)
hold,pcolor(dataR),shading interp,colormap jet;
% lines
line([abs(timelimits(1)) abs(timelimits(1))],[0 ylim],'Color','k','LineStyle','-');
% format
set(gca,'Xtick',[abs(timelimits(1)) abs(timelimits(1))+abs(timelimits(2))],'Xticklabel',{'Stim','1500ms'});
set(gca,'XLim',[abs(timelimits(1))-abs(baselinelimits(1)) abs(timelimits(1))+timelimits(2)],'YLim',[1 ylim]);
title('Right STN, stop-go trials');
c = colorbar; c.Label.String = 'db';
set(gca,'Clim',[-3 3]);

%% VIM depth ERSPs
for is = tha
    
    subnum = datasets(is).subnum;
    load(fullfile(folders.pp,['Subject' num2str(subnum) '-LFP.mat'])); LFP.etc = [];
    load(fullfile(folders.beta,['Subject' num2str(subnum) '.mat']));

    % make dipolar stn
    rvim_chans = find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'R VIM'))); % R STN channels
    if ~isempty(rvim_chans); rvim_chans = [find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'R VIM LFP 0'))) find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'R VIM LFP 1')))]; end
    lvim_chans = find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'L VIM'))); % L STN channels
    if ~isempty(lvim_chans); lvim_chans = [find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'L VIM LFP 0'))) find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'L VIM LFP 1')))]; end
    rm1_chans = find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'R subgaleal'))); % R M1 channels
    lm1_chans = find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'L subgaleal'))); % L M1 channels
    number_of_locations = ~isempty(rvim_chans) + ~isempty(lvim_chans) + ~isempty(rm1_chans) + ~isempty(lm1_chans);
    locations = {'rvim','lvim','rm1','lm1'}; % all possible contacts
  
    % go through locations and make bipolar data with contacts available
    newchanlocs = []; % will be appended
    newdata = []; % will be appended
    for il = 1:length(locations)
        % check if location is present in subject
        loclabel = [locations{il} '_chans'];
        eval(['locchans = ' loclabel ';']);
        if ~isempty(locchans)
            % go through location channels and make data and chanlabel
            locdata = zeros(length(locchans)-1,LFP.pnts);
            locchanlocs = LFP.chanlocs(1);  % will be overwritten, adopt structure layout
            for ilc = 1:length(locchans)-1
                locdata(ilc,:) = LFP.data(locchans(ilc),:) - LFP.data(locchans(ilc+1),:);
                locchanlocs(ilc).labels = [locations{il} '_' num2str(ilc)];
            end
            % identify new channel indices
            eval([loclabel ' = [' num2str(length(newchanlocs)+1:length(newchanlocs)+length(locchanlocs)) '];']);
            % append data and chanlocs
            newchanlocs = [newchanlocs locchanlocs];
            newdata = [newdata; locdata];
        end
    end
    LFP.data = newdata; LFP.chanlocs = newchanlocs; LFP.nbchan = length(LFP.chanlocs);
   
    load(fullfile(folders.pp,['ManualRej' num2str(subnum) '.mat']),'rejpoints','rejections');
    LFP = pop_select(LFP,'nopoint',rejpoints);
    
    % get evs
    evs = LFP.event;
    
    % identify chans to use
    [~,rbgchan] = intersect({LFP.chanlocs.labels},chanlabels(~cellfun(@isempty,strfind(chanlabels,'rvim'))));
    [~,lbgchan] = intersect({LFP.chanlocs.labels},chanlabels(~cellfun(@isempty,strfind(chanlabels,'lvim'))));
    chans = [rbgchan,lbgchan];
    
    % pick correct go trials only
    goevs = evs(strcmpi({evs.type},'GoStimulus'));
    gocorevs = goevs([goevs.acc]==1); % acc only
    gocorevs = gocorevs([gocorevs.rt]>minRT); % > minRT
    
    % pick successful stops only
    stopevs = evs(strcmpi({evs.type},'StopStimulus'));
    stopcorevs = stopevs([stopevs.acc]==3); % succ only
    
    % pick failed stops only
    failevs = evs(strcmpi({evs.type},'StopStimulus'));
    failcorevs = failevs([failevs.acc]==4); % fail only
    failcorevs = failcorevs([failcorevs.rt]>minRT); % > minRT
    
    %pick correct go trials only
    respevs = evs(strcmpi({evs.type},'Response'));
    respcorevs = respevs([respevs.acc]==1); % acc only
    respcorevs = respcorevs([respcorevs.rt]>minRT); % > minRT
    
    clear elats
    elats.go = [gocorevs.latency];
    for ic = 1:length(chans)
        eval(['gooutput.c' num2str(ic) ' = ersp(LFP,2,' num2str(chans(ic)) ',elats,plotlimits,baseline,freqs,.5,method);']);
    end
    
    clear elats
    elats.stop = [stopcorevs.latency];
    for ic = 1:length(chans)
        eval(['stopoutput.c' num2str(ic) ' = ersp(LFP,2,' num2str(chans(ic)) ',elats,plotlimits,baseline,freqs,.5,method);']);
    end
    
    clear elats
    elats.fail = [failcorevs.latency];
    for ic = 1:length(chans)
        eval(['failoutput.c' num2str(ic) ' = ersp(LFP,2,' num2str(chans(ic)) ',elats,plotlimits,baseline,freqs,.5,method);']);
    end

    savfile = ['Subject' num2str(subnum) '_ERSP-vim.mat'];
    save(fullfile(folders.ersp,savfile),'gooutput','stopoutput','failoutput');

end

% make figure
% VIM ERSP Figure for stop-go trials - main block
clear dataL* dataR*
timelimits = [-500 1500]; baselinelimits = [-100 0]; ylim = 50;
for is = tha
    subnum = datasets(is).subnum;
    filename = ['Subject' num2str(subnum) '_ERSP-vim.mat'];
    load(fullfile(folders.ersp,filename));
    
    dataR(is,:,:) = stopoutput.c2.ersp.stop-gooutput.c2.ersp.go;
    dataL(is,:,:) = stopoutput.c1.ersp.stop-gooutput.c1.ersp.go;
end

dataR = squeeze(mean(dataR,1));
dataL = squeeze(mean(dataL,1));

figure('Color','w'); 
    
% plotleft VIM
subplot(1,2,1);
hold,pcolor(dataL),shading interp, colormap jet;
% lines
line([abs(timelimits(1)) abs(timelimits(1))],[0 ylim],'Color','k','LineStyle','-');

% format
set(gca,'Xtick',[abs(timelimits(1)) abs(timelimits(1))+abs(timelimits(2))],'Xticklabel',{'Stim','1500ms'});
set(gca,'XLim',[abs(timelimits(1))-abs(baselinelimits(1)) abs(timelimits(1))+timelimits(2)],'YLim',[1 ylim]);
title('Left VIM, stop-go trials');
c = colorbar; c.Label.String = 'db';
set(gca,'Clim',[-3 3]);

% plot right VIM
subplot(1,2,2)
hold,pcolor(dataR),shading interp,colormap jet;
% lines
line([abs(timelimits(1)) abs(timelimits(1))],[0 ylim],'Color','k','LineStyle','-');
% format
set(gca,'Xtick',[abs(timelimits(1)) abs(timelimits(1))+abs(timelimits(2))],'Xticklabel',{'Stim','1500ms'});
set(gca,'XLim',[abs(timelimits(1))-abs(baselinelimits(1)) abs(timelimits(1))+timelimits(2)],'YLim',[1 ylim]);
title('Right VIM, stop-go trials');
c = colorbar; c.Label.String = 'db';
set(gca,'Clim',[-3 3]);
%% Vop depth ERSPs
for is = tha
    
    subnum = datasets(is).subnum;
    load(fullfile(folders.pp,['Subject' num2str(subnum) '-LFP.mat'])); LFP.etc = [];
    load(fullfile(folders.beta,['Subject' num2str(subnum) '.mat']));

    % make dipolar stn
    rvim_chans = find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'R VIM'))); % R STN channels
    if ~isempty(rvim_chans); rvim_chans = [find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'R VIM LFP 2'))) find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'R VIM LFP 3')))]; end
    lvim_chans = find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'L VIM'))); % L STN channels
    if ~isempty(lvim_chans); lvim_chans = [find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'L VIM LFP 2'))) find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'L VIM LFP 3')))]; end
    rm1_chans = find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'R subgaleal'))); % R M1 channels
    lm1_chans = find(~cellfun(@isempty,strfind({LFP.chanlocs.labels},'L subgaleal'))); % L M1 channels
    number_of_locations = ~isempty(rvim_chans) + ~isempty(lvim_chans) + ~isempty(rm1_chans) + ~isempty(lm1_chans);
    locations = {'rvim','lvim','rm1','lm1'}; % all possible contacts
  
    % go through locations and make bipolar data with contacts available
    newchanlocs = []; % will be appended
    newdata = []; % will be appended
    for il = 1:length(locations)
        % check if location is present in subject
        loclabel = [locations{il} '_chans'];
        eval(['locchans = ' loclabel ';']);
        if ~isempty(locchans)
            % go through location channels and make data and chanlabel
            locdata = zeros(length(locchans)-1,LFP.pnts);
            locchanlocs = LFP.chanlocs(1);  % will be overwritten, adopt structure layout
            for ilc = 1:length(locchans)-1
                locdata(ilc,:) = LFP.data(locchans(ilc),:) - LFP.data(locchans(ilc+1),:);
                locchanlocs(ilc).labels = [locations{il} '_' num2str(ilc)];
            end
            % identify new channel indices
            eval([loclabel ' = [' num2str(length(newchanlocs)+1:length(newchanlocs)+length(locchanlocs)) '];']);
            % append data and chanlocs
            newchanlocs = [newchanlocs locchanlocs];
            newdata = [newdata; locdata];
        end
    end
    LFP.data = newdata; LFP.chanlocs = newchanlocs; LFP.nbchan = length(LFP.chanlocs);
   
    load(fullfile(folders.pp,['ManualRej' num2str(subnum) '.mat']),'rejpoints','rejections');
    LFP = pop_select(LFP,'nopoint',rejpoints);
    
    % get evs
    evs = LFP.event;
    
    % identify chans to use
    [~,rbgchan] = intersect({LFP.chanlocs.labels},chanlabels(~cellfun(@isempty,strfind(chanlabels,'rvim'))));
    [~,lbgchan] = intersect({LFP.chanlocs.labels},chanlabels(~cellfun(@isempty,strfind(chanlabels,'lvim'))));
    chans = [rbgchan,lbgchan];
    
    % pick correct go trials only
    goevs = evs(strcmpi({evs.type},'GoStimulus'));
    gocorevs = goevs([goevs.acc]==1); % acc only
    gocorevs = gocorevs([gocorevs.rt]>minRT); % > minRT
    
    % pick successful stops only
    stopevs = evs(strcmpi({evs.type},'StopStimulus'));
    stopcorevs = stopevs([stopevs.acc]==3); % succ only
    
    % pick failed stops only
    failevs = evs(strcmpi({evs.type},'StopStimulus'));
    failcorevs = failevs([failevs.acc]==4); % fail only
    failcorevs = failcorevs([failcorevs.rt]>minRT); % > minRT
    
    %pick correct go trials only
    respevs = evs(strcmpi({evs.type},'Response'));
    respcorevs = respevs([respevs.acc]==1); % acc only
    respcorevs = respcorevs([respcorevs.rt]>minRT); % > minRT
    
    clear elats
    elats.go = [gocorevs.latency];
    for ic = 1:length(chans)
        eval(['gooutput.c' num2str(ic) ' = ersp(LFP,2,' num2str(chans(ic)) ',elats,plotlimits,baseline,freqs,.5,method);']);
    end
    
    clear elats
    elats.stop = [stopcorevs.latency];
    for ic = 1:length(chans)
        eval(['stopoutput.c' num2str(ic) ' = ersp(LFP,2,' num2str(chans(ic)) ',elats,plotlimits,baseline,freqs,.5,method);']);
    end
    
    clear elats
    elats.fail = [failcorevs.latency];
    for ic = 1:length(chans)
        eval(['failoutput.c' num2str(ic) ' = ersp(LFP,2,' num2str(chans(ic)) ',elats,plotlimits,baseline,freqs,.5,method);']);
    end

    savfile = ['Subject' num2str(subnum) '_ERSP-vop.mat'];
    save(fullfile(folders.ersp,savfile),'gooutput','stopoutput','failoutput');

end

% make figure
% VIM ERSP Figure for stop-go trials - main block
clear dataL* dataR*
timelimits = [-500 1500]; baselinelimits = [-100 0]; ylim = 50;
for is = tha
    subnum = datasets(is).subnum;
    filename = ['Subject' num2str(subnum) '_ERSP-vop.mat'];
    load(fullfile(folders.ersp,filename));
    
    dataR(is,:,:) = stopoutput.c2.ersp.stop-gooutput.c2.ersp.go;
    dataL(is,:,:) = stopoutput.c1.ersp.stop-gooutput.c1.ersp.go;
end

dataR = squeeze(mean(dataR,1));
dataL = squeeze(mean(dataL,1));

figure('Color','w'); 
    
% plotleft Vop
subplot(1,2,1);
hold,pcolor(dataL),shading interp, colormap jet;
% lines
line([abs(timelimits(1)) abs(timelimits(1))],[0 ylim],'Color','k','LineStyle','-');

% format
set(gca,'Xtick',[abs(timelimits(1)) abs(timelimits(1))+abs(timelimits(2))],'Xticklabel',{'Stim','1500ms'});
set(gca,'XLim',[abs(timelimits(1))-abs(baselinelimits(1)) abs(timelimits(1))+timelimits(2)],'YLim',[1 ylim]);
title('Left Vop, stop-go trials');
c = colorbar; c.Label.String = 'db';
set(gca,'Clim',[-3 3]);

% plot right Vop
subplot(1,2,2)
hold,pcolor(dataR),shading interp,colormap jet;
% lines
line([abs(timelimits(1)) abs(timelimits(1))],[0 ylim],'Color','k','LineStyle','-');
% format
set(gca,'Xtick',[abs(timelimits(1)) abs(timelimits(1))+abs(timelimits(2))],'Xticklabel',{'Stim','1500ms'});
set(gca,'XLim',[abs(timelimits(1))-abs(baselinelimits(1)) abs(timelimits(1))+timelimits(2)],'YLim',[1 ylim]);
title('Right Vop, stop-go trials');
c = colorbar; c.Label.String = 'db';
set(gca,'Clim',[-3 3]);
