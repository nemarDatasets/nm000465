%% Sort trial events for trial histograms (stimulus-locked)
% This script goes through our saved files of beta bursts and separates
% bursts into stimulus-locked time bins, depending on trial type. It
% outputs figures of Go- and stop-locked burst rates, along with results
% from ANOVAs and pairwise comparisons.
nbins = 0:100:900; %set bins
set(0,'DefaultFigureWindowStyle','docked')
% which participants contribute tha (exclude patient with both STN and tha)
tha_to_do = tha(2:end);
% preallocations
CONTRAGO_main = NaN(length(datasets),length(nbins)-1); IPSIGO_main = CONTRAGO_main;
GO_bg_main = CONTRAGO_main; SUCCGO_main = CONTRAGO_main;
FAILGO_main = CONTRAGO_main; MATCHGO_contram1_main = CONTRAGO_main;
FAILSTOP_main = CONTRAGO_main; SUCCSTOP_main = CONTRAGO_main;
FAILSTOP_contram1_main = CONTRAGO_main; FAILSTOP_ipsim1_main = CONTRAGO_main;
SUCCSTOP_contram1_main = CONTRAGO_main; SUCCSTOP_ipsim1_main = CONTRAGO_main;
MATCHGO_main = CONTRAGO_main; MATCHGO_ipsim1_main = CONTRAGO_main;
D_SUCCSTOP_main = CONTRAGO_main;
D_FAILSTOP_main = CONTRAGO_main; D_MATCHGO_main = CONTRAGO_main;
FAILGO_blbg = NaN(length(datasets),1); SUCCGO_blbg = FAILGO_blbg;
GO_blbg = FAILGO_blbg; D_FAILGO_blbg = FAILGO_blbg; D_SUCCGO_blbg = FAILGO_blbg;
D_GO_blbg = FAILGO_blbg;

for is = 1:length(datasets) % for each subject
    
    subnum = datasets(is).subnum; % subject number
    clear trialevs* trials* dorsal* bl_trials* chanlabels
    
    % load beta event indices
    load(fullfile(folders.beta,['Subject' num2str(subnum) '.mat']));
    
    % assign channels (only main block has depth electrodes)
    % assign VIM [THIS DEFAULT TO STN FOR 104 (which has both VIM and STN)]
    if sum(~cellfun(@isempty,strfind(chanlabels,'rvim'))) == 1
        rbgchan = ~cellfun(@isempty,strfind(chanlabels,'rvim'));
        lbgchan = ~cellfun(@isempty,strfind(chanlabels,'lvim'));
        eval(['trialsbgl = trialevs.' chanlabels{lbgchan} ';']);
        eval(['trialsbgr = trialevs.' chanlabels{rbgchan} ';']);
        eval(['bl_trialsbgl = blevs.' chanlabels{lbgchan} ';']);
        eval(['bl_trialsbgr = blevs.' chanlabels{rbgchan} ';']);
    end
    % assign STN [THIS DEFAULTS TO STN FOR 104 (which has both VIM and STN)]
    if sum(~cellfun(@isempty,strfind(chanlabels,'rstn'))) == 1
        rbgchan = ~cellfun(@isempty,strfind(chanlabels,'rstn'));
        lbgchan = ~cellfun(@isempty,strfind(chanlabels,'lstn'));
        eval(['trialsbgl = trialevs.' chanlabels{lbgchan} ';']);
        eval(['trialsbgr = trialevs.' chanlabels{rbgchan} ';']);
        eval(['bl_trialsbgl = blevs.' chanlabels{lbgchan} ';']);
        eval(['bl_trialsbgr = blevs.' chanlabels{rbgchan} ';']);    
    end
    
    % combine left and right bg data
    trialnumbers = fieldnames(trialsbgl);
    for itt = 1:length(trialnumbers)
        eval(['trialsbg.' trialnumbers{itt} ' = [trialsbgl.' trialnumbers{itt} ' trialsbgr.' trialnumbers{itt} '];']);
        eval(['bl_trialsbg.' trialnumbers{itt} ' = [bl_trialsbgl.' trialnumbers{itt} ' bl_trialsbgr.' trialnumbers{itt} '];']);
    end
        
    % Now sort events from M1
    rightmotor = chanlabels{~cellfun(@isempty,strfind(chanlabels,'rm1'))};
    eval(['trialsc4 = trialevs.' rightmotor ';']);
    eval(['bl_trialsc4 = blevs.' rightmotor ';']);
    % assign left motor
    leftmotor = chanlabels{~cellfun(@isempty,strfind(chanlabels,'lm1'))};
    eval(['trialsc3 = trialevs.' leftmotor ';']);
    eval(['bl_trialsc3 = blevs.' leftmotor ';']);
    
    if ~isempty(intersect(is,tha)) % if a thalamus case, load dorsal thal 
        % load dorsal thalamus bursts
        load(fullfile(folders.beta,['Subject' num2str(subnum) '_dorsal.mat']));
        if sum(~cellfun(@isempty,strfind(chanlabels,'lvim'))) == 1
            if is ~= 2; lbgchan = ~cellfun(@isempty,strfind(chanlabels,'lvim'));end
            rbgchan = ~cellfun(@isempty,strfind(chanlabels,'rvim'));
            eval(['dorsal_trialsbgl = trialevs.' chanlabels{lbgchan} ';']);
            if is ~= 2; eval(['dorsal_trialsbgr = trialevs.' chanlabels{rbgchan} ';']); end
            eval(['dorsal_bl_trialsbgl = blevs.' chanlabels{lbgchan} ';']);
            if is ~= 2; eval(['dorsal_bl_trialsbgr = blevs.' chanlabels{rbgchan} ';']); end
        end
        for itt = 1:length(trialnumbers)
            if is ~= 2 
                eval(['dorsal_trialsbg.' trialnumbers{itt} ' = [dorsal_trialsbgl.' trialnumbers{itt} ' dorsal_trialsbgr.' trialnumbers{itt} '];']);
                eval(['dorsal_bl_trialsbg.' trialnumbers{itt} ' = [dorsal_bl_trialsbgl.' trialnumbers{itt} ' dorsal_bl_trialsbgr.' trialnumbers{itt} '];']);
            else
                eval(['dorsal_trialsbg.' trialnumbers{itt} ' = [dorsal_trialsbgl.' trialnumbers{itt} '];']);
                eval(['dorsal_bl_trialsbg.' trialnumbers{itt} ' = [dorsal_bl_trialsbgl.' trialnumbers{itt} '];']);
            end
        end
    end
    
    % presets for binned counts of bursts per trial type and trial type
    % counters
    bg_gol = []; bg_gor = []; gr = 0; gl = 0;
    bg_ssl = []; bg_ssr = []; ssr = 0; ssl = 0;
    bg_fsl = []; bg_fsr = []; fsr = 0; fsl = 0;
    bg_gossl = []; bg_gossr = []; gssr = 0; gssl = 0;
    bg_gofsl = []; bg_gofsr = []; gfsr = 0; gfsl = 0;
    bl_gossl = []; bl_gossr = []; blgssr = 0; blgssl = 0;
    bl_gofsl = []; bl_gofsr = []; blgfsr = 0; blgfsl = 0;
    go_bl_gossl = []; go_bl_gossr = []; gblgssr = 0; gblgssl = 0;
    go_bl_gofsl = []; go_bl_gofsr = []; gblgfsr = 0; gblgfsl = 0;
    bl_gol = []; bl_gor = []; blgr = 0; blgl = 0; go_bl_gol = []; go_bl_gor = [];
    matchl = []; matchr = []; ml = 0; mr = 0;
    
    for it = 1:length(fieldnames(trialsbg)) % for each trial
        % need to be cleared so we don't use last trial info
        nextgo = []; match_evs = []; match = []; evs = []; bevs = [];
        
        % if a stop trial, identify a go trial w/ similar or same
        % SSD
        if accuracy(it) == 3 || accuracy(it) == 4
            % try to pick matched go with same SSD soon after this
            % trial
            match = find(ssd-ssd(it) == 0 & accuracy == 1); nextgo = match(find(match>it,1,'first'));
            % if failed, pick first go trial w/ same SSD in exp
            if isempty(nextgo); nextgo = find(ssd-ssd(it) == 0 & accuracy == 1,1,'first'); end
            % if failed, pick first go trial w/ SSD w/in 50ms
            if isempty(nextgo); nextgo = find(ssd-ssd(it) == 50 | ssd-ssd(it) == -50 & accuracy == 1,1,'first'); end
            eval(['match_evs = trialsbg.t' num2str(nextgo) ';']);
        end
        
        % get events from that trial
        eval(['evs = trialsbg.t' num2str(it) ';']);
        evs(evs<=2) = []; % don't include bursts already happening at start time
        eval(['bevs = bl_trialsbg.t' num2str(it) ';']);
        bevs(bevs<=2) = []; % don't include bursts already happening at start time
        
        % if there's an event during this trial
        if ~isempty(evs)
            % preallocate
            trial = zeros(size(nbins));
            
            for ie = 1:length(evs) % for each beta event
                
                % count trial in bin it belongs to
                upperbound = find(evs(ie)<nbins,1,'first');
                trial(upperbound) = trial(upperbound) + 1;
            end
            
            % store event counts for this trial according to
            % accuracy and side of response to be made
            if side(it) == 1 && accuracy(it) == 4
                fsl = fsl + 1;
                bg_fsl(fsl,:) = trial;
            elseif side(it) == 2 && accuracy(it) == 4
                fsr = fsr + 1;
                bg_fsr(fsr,:) = trial;
            end
            if side(it) == 1 && accuracy(it) == 3
                ssl = ssl + 1;
                bg_ssl(ssl,:) = trial;
            elseif side(it) == 2 && accuracy(it) == 3
                ssr = ssr + 1;
                bg_ssr(ssr,:) = trial;
            end
            if side(it) == 1 && accuracy(it) == 1004
                gfsl = gfsl + 1;
                bg_gofsl(gfsl,:) = trial;
            elseif side(it) == 2 && accuracy(it) == 1004
                gfsr = gfsr + 1;
                bg_gofsr(gfsr,:) = trial;
            end
            if side(it) == 1 && accuracy(it) == 1003
                gssl = gssl + 1;
                bg_gossl(gssl,:) = trial;
            elseif side(it) == 2 && accuracy(it) == 1003
                gssr = gssr + 1;
                bg_gossr(gssr,:) = trial;
            end
            if side(it) == 1 && accuracy(it) == 1
                gl = gl + 1;
                bg_gol(gl,:) = trial;
            elseif side(it) == 2 && accuracy(it) == 1
                gr = gr + 1;
                bg_gor(gr,:) = trial;
            end
            
            if ssd(it)>50
                bl_trial = []; go_bl_trial = [];
                if accuracy(it) == 3 || accuracy(it) == 4
                    % if a stop trial, look before stop signal (which is the
                    % end of the baseline window)
                    bl_trial = length(bevs(bevs<500 & bevs>400));
                elseif accuracy(it) == 1 
                    % if a go trial, look during evs when SS would have
                    % happened
                    bl_trial = length(evs(evs<ssd(it) & evs>ssd(it)-100));
                    go_bl_trial = length(bevs(bevs<500 & bevs>400));
                elseif accuracy(it) == 1003 || accuracy(it) == 1004 % go before ss
                    go_bl_trial = length(bevs(bevs<500 & bevs>400));
                end
                
                if side(it) == 1 && accuracy(it)==3
                    blgssl = blgssl + 1;
                    bl_gossl(blgssl,:) = bl_trial;
                elseif side(it) == 2 && accuracy(it) == 3
                    blgssr = blgssr + 1;
                    bl_gossr(blgssr,:) = bl_trial;
                end
                if side(it) == 1 && accuracy(it) == 4
                    blgfsl = blgfsl + 1;
                    bl_gofsl(blgfsl,:) = bl_trial;
                elseif side(it) == 2 && accuracy(it) == 4
                    blgfsr = blgfsr + 1;
                    bl_gofsr(blgfsr,:) = bl_trial;
                end
                if side(it) == 1 && accuracy(it) == 1004
                    gblgfsl = gblgfsl + 1;
                    go_bl_gofsl(gblgfsl,:) = go_bl_trial;
                elseif side(it) == 2 && accuracy(it) == 1004
                    gblgfsr = gblgfsr + 1;
                    go_bl_gofsr(gblgfsr,:) = go_bl_trial;
                end
                if side(it) == 1 && accuracy(it) == 1003
                    gblgssl = gblgssl + 1;
                    go_bl_gossl(gblgssl,:) = go_bl_trial;
                elseif side(it) == 2 && accuracy(it) == 1003
                    gblgssr = gblgssr + 1;
                    go_bl_gossr(gblgssr,:) = go_bl_trial;
                end
                if side(it) == 1 && accuracy(it) == 1
                    blgl = blgl + 1;
                    bl_gol(blgl,:) = bl_trial;
                    go_bl_gol(blgl,:) = go_bl_trial;
                elseif side(it) == 2 && accuracy(it) == 1
                    blgr = blgr + 1;
                    bl_gor(blgr,:) = bl_trial;
                    go_bl_gor(blgr,:) = go_bl_trial;
                end
            end
        end
        
        % if there are events during a matched go trial
        match_evs(match_evs<=2) = [];
        if ~isempty(match_evs)
            match_trial = zeros(size(nbins));
            
            for ie = 1:length(match_evs) % count those events in their bin (accounting for SSD)
                upperbound = find(match_evs(ie)-ssd(nextgo)<nbins & match_evs(ie)-ssd(nextgo)>0,1,'first');
                match_trial(upperbound) = match_trial(upperbound) + 1;
            end
            % sort according to accuracy and side
            if side(nextgo) == 1 && accuracy(nextgo) == 1
                ml = ml + 1;
                matchl(ml,:) = match_trial;
            elseif side(nextgo) == 2 && accuracy(nextgo) == 1
                mr = mr + 1;
                matchr(mr,:) = match_trial;
            end
        end
    end
    
    % if a thalamus DBS case, also do dorsal thalamus
    if ~isempty(intersect(is,tha))
        % presets for binned counts of bursts per trial type and trial type
        % counters
        d_bg_gol = []; d_bg_gor = []; dgr = 0; dgl = 0;
        d_bg_ssl = []; d_bg_ssr = []; dssr = 0; dssl = 0;
        d_bg_fsl = []; d_bg_fsr = []; dfsr = 0; dfsl = 0;
        d_bg_gossl = []; d_bg_gossr = []; dgssr = 0; dgssl = 0;
        d_bg_gofsl = []; d_bg_gofsr = []; dgfsr = 0; dgfsl = 0;
        d_bl_gossl = []; d_bl_gossr = []; dblgssr = 0; dblgssl = 0;
        d_bl_gofsl = []; d_bl_gofsr = []; dblgfsr = 0; dblgfsl = 0;
        go_d_bl_gossl = []; go_d_bl_gossr = []; gdblgssr = 0; gdblgssl = 0;
        go_d_bl_gofsl = []; go_d_bl_gofsr = []; gdblgfsr = 0; gdblgfsl = 0;
        d_bl_gol = []; d_bl_gor = []; dblgr = 0; dblgl = 0; go_d_bl_gol = [];
        d_matchl = []; d_matchr = []; dml = 0; dmr = 0; go_d_bl_gor = [];
        
        for it = 1:length(fieldnames(dorsal_trialsbg)) % for each trial
            % need to be cleared so we don't use last trial info
            nextgo = []; match_evs = []; match = []; evs = []; bevs = [];
            
            % if a stop trial, identify a go trial w/ similar or same
            % SSD
            if accuracy(it) == 3 || accuracy(it) == 4
                % try to pick matched go with same SSD soon after this
                % trial
                match = find(ssd-ssd(it) == 0 & accuracy == 1); nextgo = match(find(match>it,1,'first'));
                % if failed, pick first go trial w/ same SSD in exp
                if isempty(nextgo); nextgo = find(ssd-ssd(it) == 0 & accuracy == 1,1,'first'); end
                % if failed, pick first go trial w/ SSD w/in 50ms
                if isempty(nextgo); nextgo = find(ssd-ssd(it) == 50 | ssd-ssd(it) == -50 & accuracy == 1,1,'first'); end
                eval(['match_evs = dorsal_trialsbg.t' num2str(nextgo) ';']);
            end
            
            % get events from that trial
            eval(['evs = dorsal_trialsbg.t' num2str(it) ';']);
            evs(evs<=2) = []; % don't include bursts already happening at start time
            eval(['bevs = dorsal_bl_trialsbg.t' num2str(it) ';']);
            bevs(bevs<=2) = []; % don't include bursts already happening at start time
            
            % if there's an event during this trial
            if ~isempty(evs)
                % preallocate
                trial = zeros(size(nbins));
                
                for ie = 1:length(evs) % for each beta event
                    
                    % count trial in bin it belongs to
                    upperbound = find(evs(ie)<nbins,1,'first');
                    trial(upperbound) = trial(upperbound) + 1;
                end
                
                % store event counts for this trial according to
                % accuracy and side of response to be made
                if side(it) == 1 && accuracy(it) == 4
                    dfsl = dfsl + 1;
                    d_bg_fsl(dfsl,:) = trial;
                elseif side(it) == 2 && accuracy(it) == 4
                    dfsr = dfsr + 1;
                    d_bg_fsr(dfsr,:) = trial;
                end
                if side(it) == 1 && accuracy(it) == 3
                    dssl = dssl + 1;
                    d_bg_ssl(dssl,:) = trial;
                elseif side(it) == 2 && accuracy(it) == 3
                    dssr = dssr + 1;
                    d_bg_ssr(dssr,:) = trial;
                end
                if side(it) == 1 && accuracy(it) == 1004
                    dgfsl = dgfsl + 1;
                    d_bg_gofsl(dgfsl,:) = trial;
                elseif side(it) == 2 && accuracy(it) == 1004
                    dgfsr = dgfsr + 1;
                    d_bg_gofsr(dgfsr,:) = trial;
                end
                if side(it) == 1 && accuracy(it) == 1003
                    dgssl = dgssl + 1;
                    d_bg_gossl(dgssl,:) = trial;
                elseif side(it) == 2 && accuracy(it) == 1003
                    dgssr = dgssr + 1;
                    d_bg_gossr(dgssr,:) = trial;
                end
                
                if ssd(it)>50
                    bl_trial = []; go_bl_trial = [];
                    if accuracy(it) == 3 || accuracy(it) == 4
                        % if a stop trial, look before stop signal (which is the
                        % end of the baseline window)
                        bl_trial = length(bevs(bevs<500 & bevs>400));
                    elseif accuracy(it) == 1
                        % if a go trial, look during evs when SS would have
                        % happened
                        bl_trial = length(evs(evs<ssd(it) & evs>ssd(it)-100));
                        go_bl_trial = length(bevs(bevs<500 & bevs>400));
                    elseif accuracy(it) == 1003 || accuracy(it) == 1004
                        go_bl_trial = length(bevs(bevs<500 & bevs>400));
                    end
                    
                    if side(it) == 1 && accuracy(it) == 3
                        dblgssl = dblgssl + 1;
                        d_bl_gossl(dblgssl,:) = bl_trial;
                    elseif side(it) == 2 && accuracy(it) == 3
                        dblgssr = dblgssr + 1;
                        d_bl_gossr(dblgssr,:) = bl_trial;
                    end 
                    if side(it) == 1 && accuracy(it) == 4
                        dblgfsl = dblgfsl + 1;
                        d_bl_gofsl(dblgfsl,:) = bl_trial;
                    elseif side(it) == 2 && accuracy(it) == 4
                        dblgfsr = dblgfsr + 1;
                        d_bl_gofsr(dblgfsr,:) = bl_trial;
                    end 
                    if side(it) == 1 && accuracy(it) == 1004
                        gdblgfsl = gdblgfsl + 1;
                        go_d_bl_gofsl(gdblgfsl,:) = go_bl_trial;
                    elseif side(it) == 2 && accuracy(it) == 1004
                        gdblgfsr = gdblgfsr + 1;
                        go_d_bl_gofsr(gdblgfsr,:) = go_bl_trial;
                    end
                    if side(it) == 1 && accuracy(it) == 1003
                        gdblgssl = gdblgssl + 1;
                        go_d_bl_gossl(gdblgssl,:) = go_bl_trial;
                    elseif side(it) == 2 && accuracy(it) == 1003
                        gdblgssr = gdblgssr + 1;
                        go_d_bl_gossr(gdblgssr,:) = go_bl_trial;
                    end
                    if side(it) == 1 && accuracy(it) == 1
                        dblgl = dblgl + 1;
                        d_bl_gol(dblgl,:) = bl_trial;
                        go_d_bl_gol(dblgl,:) = go_bl_trial;
                    elseif side(it) == 2 && accuracy(it) == 1
                        dblgr = dblgr + 1;
                        d_bl_gor(dblgr,:) = bl_trial;
                        go_d_bl_gor(dblgr,:) = go_bl_trial;
                    end
                    if side(it) == 1 && accuracy(it) == 1
                        dgl = dgl + 1;
                        d_bg_gol(dgl,:) = trial;
                        go_d_bg_gol(dgl,:) = go_bl_trial;
                    elseif side(it) == 2 && accuracy(it) == 1
                        dgr = dgr + 1;
                        d_bg_gor(dgr,:) = trial;
                        go_d_bg_gor(dgr,:) = go_bl_trial;
                    end
                end
            end
            
            % if there are events during a matched go trial
            match_evs(match_evs<=2) = [];
            if ~isempty(match_evs)
                match_trial = zeros(size(nbins));
                
                for ie = 1:length(match_evs) % count those events in their bin (accounting for SSD)
                    upperbound = find(match_evs(ie)-ssd(nextgo)<nbins & match_evs(ie)-ssd(nextgo)>0,1,'first');
                    match_trial(upperbound) = match_trial(upperbound) + 1;
                end
                % sort according to accuracy and side
                if side(nextgo) == 1 && accuracy(nextgo) == 1
                    dml = dml + 1;
                    d_matchl(dml,:) = match_trial;
                elseif side(nextgo) == 2 && accuracy(nextgo) == 1
                    dmr = dmr + 1;
                    d_matchr(dmr,:) = match_trial;
                end
            end
        end
    end
    
    % Sort events from right M1 next
    % presets
    r_gol = []; r_gor = []; gr = 0; gl = 0;
    r_fsr = []; r_fsl = []; fsr = 0; fsl = 0;
    r_ssr = []; r_ssl = []; ssr = 0; ssl = 0;
    r_matchl = []; r_matchr = []; r_ml = 0; r_mr = 0;
    
    for it = 1:length(fieldnames(trialsc4)) % for each trial
        nextgo = []; match_evs = []; match = []; evs = []; bevs = [];
        
        % if stop trial, identify go trial with similar or same SSD
        if accuracy(it) == 3 || accuracy(it) == 4
            % try to pick matched go with same SSD soon after this
            % trial
            match = find(ssd-ssd(it) == 0 & accuracy == 1); nextgo = match(find(match>it,1,'first'));
            % if failed, pick first go trial w/ same SSD in exp
            if isempty(nextgo); nextgo = find(ssd-ssd(it) == 0 & accuracy == 1,1,'first'); end
            % if failed, pick first go trial w/ SSD w/in 50ms
            if isempty(nextgo); nextgo = find(ssd-ssd(it) == 50 | ssd-ssd(it) == -50 & accuracy == 1,1,'first'); end
            eval(['match_evs = trialsc4.t' num2str(nextgo) ';']);
        end
        
        % get events
        eval(['evs = trialsc4.t' num2str(it) ';']);
        evs(evs<=2) = [];
        eval(['bevs = trialsc4.t' num2str(it) ';']);
        bevs(bevs<=2) = [];
        
        % if there is an event this trial
        if ~isempty(evs)
            trial = zeros(size(nbins));
            
            for ie = 1:length(evs) % for each event
                
                % count trial in its appropriate bin
                upperbound = find(evs(ie)<nbins,1,'first');
                trial(upperbound) = trial(upperbound) + 1;
                
            end
            
            % sort according to accuracy and side of response
            if side(it) == 1 && accuracy(it) == 3
                ssl = ssl + 1;
                r_ssl(ssl,:) = trial;
            elseif side(it) == 2 && accuracy(it) == 3
                ssr = ssr + 1;
                r_ssr(ssr,:) = trial;
            end
            if side(it) == 1 && accuracy(it) == 4
                fsl = fsl + 1;
                r_fsl(fsl,:) = trial;
            elseif side(it) == 2 && accuracy(it) == 4
                fsr = fsr + 1;
                r_fsr(fsr,:) = trial;
            end
            if side(it) == 1 && accuracy(it) == 1
                gl = gl + 1;
                r_gol(gl,:) = trial;
            elseif side(it) == 2 && accuracy(it) == 1
                gr = gr + 1;
                r_gor(gr,:) = trial;
            end
            if ssd(it)>50
                bl_trial = [];
                if accuracy(it) == 1003 || accuracy(it) == 1004
                % if a stop trial, look before stop signal (which is the
                % end of the baseline window)
                    bl_trial = length(bevs(bevs<500 & bevs>400));
                elseif accuracy(it) == 1
                % if a go trial, look during evs when SS would have
                % happened
                    bl_trial = length(evs(evs<ssd(it) & evs>ssd(it)-100));
                end               
                
               if side(it) == 1 && accuracy(it) == 1004
                   gfsl = gfsl + 1;
                   r_gofsl(gfsl,:) = bl_trial;
               elseif side(it) == 2 && accuracy(it) == 1004
                   gfsr = gfsr + 1;
                   r_gofsr(gfsr,:) = bl_trial;
               end
               if side(it) == 1 && accuracy(it) == 1003
                   gssl = gssl + 1;
                   r_gossl(gssl,:) = bl_trial;
               elseif side(it) == 2 && accuracy(it) == 1003
                   gssr = gssr + 1;
                   r_gossr(gssr,:) = bl_trial;
               end
           end
        end
        
        % if there is an event in the matched-go trial
        match_evs(match_evs<=2) = [];
        if ~isempty(match_evs)
            match_trial = zeros(size(nbins));
            for ie = 1:length(match_evs) % for each event
                % place in appropriate bin (accounting for SSD)
                upperbound = find(match_evs(ie)-ssd(nextgo)<nbins & match_evs(ie)-ssd(nextgo)>0,1,'first');
                match_trial(upperbound) = match_trial(upperbound) + 1;
                % sort according to side and acc
                if side(nextgo) == 1 && accuracy(nextgo) == 1
                    r_ml = r_ml + 1;
                    r_matchl(r_ml,:) = match_trial;
                elseif side(nextgo) == 2 && accuracy(nextgo) == 1
                    r_mr = r_mr + 1;
                    r_matchr(r_mr,:) = match_trial;
                end
            end
        end
        
    end
    
    % left motor strip is next and last
    
    % presets
    l_gol = []; l_gor = []; gr = 0; gl = 0;
    l_fsr = []; l_fsl = []; fsr = 0; fsl = 0;
    l_ssr = []; l_ssl = []; ssr = 0; ssl = 0;
    l_matchl = []; l_matchr = []; l_ml = 0; l_mr = 0;
    
    for it = 1:length(fieldnames(trialsc3)) % for each trial
        nextgo = []; match_evs = []; match = []; bevs = []; evs = [];
        
        % if a stop trial, find matched go trial with same or
        % similar SSD
        if accuracy(it) == 3 || accuracy(it) == 4
            % try to pick matched go with same SSD soon after this
            % trial
            match = find(ssd-ssd(it) == 0 & accuracy == 1); nextgo = match(find(match>it,1,'first'));
            % if failed, pick most recent
            if isempty(nextgo); match = find(ssd-ssd(it) == 0 & accuracy == 1); nextgo = match(find(match<it,1,'last')); end
            % if failed, pick first go trial w/ SSD w/in 50ms
            if isempty(nextgo); nextgo = find(ssd-ssd(it) == 50 | ssd-ssd(it) == -50 & accuracy == 1,1,'first'); end
            eval(['match_evs = trialsc3.t' num2str(nextgo) ';']);
        end
        
        % get events
        eval(['evs = trialsc3.t' num2str(it) ';']); 
        evs(evs<=2) = [];
        eval(['bevs = trialsc3.t' num2str(it) ';']); 
        bevs(bevs<=2) = [];
        
        % if there was > 1 ev
        if ~isempty(evs)
            timelock = RT;
            trial = zeros(size(nbins));
            
            for ie = 1:length(evs) % for each event
                
                % count trial in respective bin
                upperbound = find(evs(ie)<nbins,1,'first');
                trial(upperbound) = trial(upperbound) + 1;
                
            end
            
            % sort according to side and accuracy
            if side(it) == 1 && accuracy(it) == 1
                gl = gl + 1;
                l_gol(gl,:) = trial;
            elseif side(it) == 2 && accuracy(it) == 1
                gr = gr + 1;
                l_gor(gr,:) = trial;
            end
            if side(it) == 1 && accuracy(it) == 3
                ssl = ssl + 1;
                l_ssl(ssl,:) = trial;
            elseif side(it) == 2 && accuracy(it) == 3
                ssr = ssr + 1;
                l_ssr(ssr,:) = trial;
            end
            if side(it) == 1 && accuracy(it) == 4
                fsl = fsl + 1;
                l_fsl(fsl,:) = trial;
            elseif side(it) == 2 && accuracy(it) == 4
                fsr = fsr + 1;
                l_fsr(fsr,:) = trial;
            end
            if side(it) == 1 && accuracy(it) == 1
                gl = gl + 1;
                l_gol(gl,:) = trial;
            elseif side(it) == 2 && accuracy(it) == 1
                gr = gr + 1;
                l_gor(gr,:) = trial;
            end  
            if ssd(it)>50
                bl_trial = [];
                if accuracy(it) == 1003 || accuracy(it) == 1004
                % if a stop trial, look before stop signal (which is the
                % end of the baseline window)
                    bl_trial = length(bevs(bevs<500 & bevs>400));
                elseif accuracy(it) == 1
                % if a go trial, look during evs when SS would have
                % happened
                    bl_trial = length(evs(evs<ssd(it) & evs>ssd(it)-100));
                end 
                
               if side(it) == 1 && accuracy(it) == 1004
                   gfsl = gfsl + 1;
                   l_gofsl(gfsl,:) = bl_trial;
               elseif side(it) == 2 && accuracy(it) == 1004
                   gfsr = gfsr + 1;
                   l_gofsr(gfsr,:) = bl_trial;
               end
               if side(it) == 1 && accuracy(it) == 1003
                   gssl = gssl + 1;
                   l_gossl(gssl,:) = bl_trial;
               elseif side(it) == 2 && accuracy(it) == 1003
                   gssr = gssr + 1;
                   l_gossr(gssr,:) = bl_trial;
               end
           end
        end
        
        % if there was a matched-go trial event
        if ~isempty(match_evs)
            match_trial = zeros(size(nbins));
            for ie = 1:length(match_evs) % for each event
                % place in its bin (accounting for SSD)
                upperbound = find(match_evs(ie)-ssd(nextgo)<nbins & match_evs(ie)-ssd(nextgo)>0,1,'first');
                match_trial(upperbound) = match_trial(upperbound) + 1;
                % Sort by side
                if side(nextgo) == 1 && accuracy(nextgo) == 1
                    l_ml = l_ml + 1;
                    l_matchl(l_ml,:) = match_trial;
                elseif side(nextgo) == 2 && accuracy(nextgo) == 1
                    l_mr = l_mr + 1;
                    l_matchr(l_mr,:) = match_trial;
                end
            end
        end
    end
    
    % delete all of the first time point bins to account for "pre-zero"
    % event accumulation
    r_gol(:,1) = []; r_gor(:,1) = [];
    l_gol(:,1) = []; l_gor(:,1) = [];
    if ~isempty(r_fsr); r_fsr(:,1) = []; end
    if ~isempty(r_fsl); r_fsl(:,1) = []; end
    if ~isempty(l_fsr); l_fsr(:,1) = []; end
    l_fsl(:,1) = [];
    if ~isempty(bg_fsr); bg_fsr(:,1) = []; end
    bg_fsl(:,1) = [];
    if ~isempty(r_ssr); r_ssr(:,1) = []; end
    r_ssl(:,1) = [];
    l_ssr(:,1) = []; l_ssl(:,1) = [];
    bg_ssr(:,1) = []; bg_ssl(:,1) = [];
    r_matchl(:,1) = []; r_matchr(:,1) = [];
    l_matchl(:,1) = []; l_matchr(:,1) = [];
    matchr(:,1) = []; matchl(:,1) = [];
    bg_gol(:,1) = []; bg_gor(:,1) = [];
    bg_gossl(:,1) = []; bg_gossr(:,1) = [];
    bg_gofsl(:,1) = []; bg_gofsr(:,1) = [];
    if ~isempty(intersect(is,tha))
        d_bg_ssr(:,1) = []; d_bg_ssl(:,1) = [];
        if ~isempty(d_bg_fsr); d_bg_fsr(:,1) = []; end
        d_bg_fsl(:,1) = [];
        d_matchr(:,1) = []; d_matchl(:,1) = [];
        d_bg_gol(:,1) = []; d_bg_gor(:,1) = [];
        d_bg_gossl(:,1) = []; d_bg_gossr(:,1) = [];
        d_bg_gofsl(:,1) = []; d_bg_gofsr(:,1) = [];
    end

    % store percentages (get value of avg beta events per trial for each
    % trial type)
    CONTRAGO_main(is,:) = sum([r_gol;l_gor])/size([r_gol;l_gor],1);
    IPSIGO_main(is,:) = sum([r_gor;l_gol])/size([r_gor;l_gol],1);
    FAILSTOP_contram1_main(is,:) = sum([l_fsr;r_fsl])/size([l_fsr;r_fsl],1);
    SUCCSTOP_contram1_main(is,:) = sum([l_ssr;r_ssl])/size([l_ssr;r_ssl],1);
    MATCHGO_contram1_main(is,:) = sum([r_matchl;l_matchr])/size([r_matchl;l_matchr],1);
    FAILSTOP_ipsim1_main(is,:) = sum([r_fsr;l_fsl])/size([r_fsr;l_fsl],1);
    SUCCSTOP_ipsim1_main(is,:) = sum([r_ssr;l_ssl])/size([r_ssr;l_ssl],1);
    MATCHGO_ipsim1_main(is,:) = sum([l_matchl;r_matchr])/size([l_matchl;r_matchr],1);
    FAILSTOP_main(is,:) = sum([bg_fsr;bg_fsl])/size([bg_fsr;bg_fsl],1);
    SUCCSTOP_main(is,:) = sum([bg_ssr;bg_ssl])/size([bg_ssr;bg_ssl],1);
    MATCHGO_main(is,:) = sum([matchl;matchr])/size([matchl;matchr],1);
    FAILGO_main(is,:) = sum([bg_gofsl;bg_gofsr])/size([bg_gofsl;bg_gofsr],1);
    SUCCGO_main(is,:) = sum([bg_gossl;bg_gossr])/size([bg_gossl;bg_gossr],1);
    GO_bg_main(is,:) = sum([bg_gol;bg_gor])/size([bg_gol;bg_gor],1);

    FAILGO_blbg(is,:) = sum([bl_gofsr;bl_gofsl])/size([bl_gofsr;bl_gofsl],1); % divide by 5 for bl per 100ms before stop
    SUCCGO_blbg(is,:) = sum([bl_gossr;bl_gossl])/size([bl_gossr;bl_gossl],1);
    GO_blbg(is,:) = sum([bl_gol;bl_gor])/size([bl_gol;bl_gor],1);
    FAILGO_goblbg(is,:) = sum([go_bl_gofsr;go_bl_gofsl])/size([go_bl_gofsr;go_bl_gofsl],1); % divide by 5 for bl per 100ms before stop
    SUCCGO_goblbg(is,:) = sum([go_bl_gossr;go_bl_gossl])/size([go_bl_gossr;go_bl_gossl],1);
    GO_goblbg(is,:) = sum([go_bl_gol;go_bl_gor])/size([go_bl_gol;go_bl_gor],1);
    
    if ~isempty(intersect(is,tha))
        D_FAILSTOP_main(is,:) = sum([d_bg_fsr;d_bg_fsl])/size([d_bg_fsr;d_bg_fsl],1);
        D_SUCCSTOP_main(is,:) = sum([d_bg_ssr;d_bg_ssl])/size([d_bg_ssr;d_bg_ssl],1);
        D_MATCHGO_main(is,:) = sum([d_matchl;d_matchr])/size([d_matchl;d_matchr],1);
        D_FAILGO_blbg(is,:) = sum([d_bl_gofsr;d_bl_gofsl])/size([d_bl_gofsr;d_bl_gofsl],1); % divide by 5 for bl per 100ms before stop
        D_SUCCGO_blbg(is,:) = sum([d_bl_gossr;d_bl_gossl])/size([d_bl_gossr;d_bl_gossl],1);
        D_FAILGO_main(is,:) = sum([d_bg_gofsl;d_bg_gofsr])/size([d_bg_gofsl;d_bg_gofsr],1);
        D_SUCCGO_main(is,:) = sum([d_bg_gossl;d_bg_gossr])/size([d_bg_gossl;d_bg_gossr],1);
        D_GO_bg_main(is,:) = sum([d_bg_gol;d_bg_gor])/size([d_bg_gol;d_bg_gor],1);
        D_GO_blbg(is,:) = sum([d_bl_gol;d_bl_gor])/size([d_bl_gol;d_bl_gor],1);
        D_FAILGO_goblbg(is,:) = sum([go_d_bl_gofsr;go_d_bl_gofsl])/size([go_d_bl_gofsr;go_d_bl_gofsl],1); % divide by 5 for bl per 100ms before stop
        D_SUCCGO_goblbg(is,:) = sum([go_d_bl_gossr;go_d_bl_gossl])/size([go_d_bl_gossr;go_d_bl_gossl],1);
        D_GO_goblbg(is,:) = sum([go_d_bl_gol;go_d_bl_gor])/size([go_d_bl_gol;go_d_bl_gor],1);
    end
end

% 1) Do stats for stop-locked bursts (Figure 4) 
% set up 2-way (condition x time) ANOVA w/permutations
% set up matrices
Y_STN = []; S_STN = []; F1_STN = []; F2_STN = [];
Y_VIM = []; S_VIM = []; F1_VIM = []; F2_VIM = [];
for is = 1:length(datasets)
    subs = repmat(is,1,(length(nbins)-1)*3)'; f1 = [ones(1,length(nbins)-1) repmat(2,1,length(nbins)-1) repmat(3,1,length(nbins)-1)]';
    f2 = repmat(1:length(nbins)-1,1,3)';
    if strcmpi(datasets(is).loc,'STN') || strcmpi(datasets(is).loc,'both')
        if isempty(Y_STN)
            Y_STN = [FAILSTOP_main(is,:) SUCCSTOP_main(is,:) MATCHGO_main(is,:)]';
            S_STN = subs; F1_STN = f1; F2_STN = f2;
        else
            Y_STN = [Y_STN; [FAILSTOP_main(is,:) SUCCSTOP_main(is,:) MATCHGO_main(is,:)]'];
            S_STN = [S_STN; subs]; F1_STN = [F1_STN; f1];
            F2_STN = [F2_STN; f2];
        end
    else
        if isempty(Y_VIM)
            Y_VIM = [FAILSTOP_main(is,:) SUCCSTOP_main(is,:) MATCHGO_main(is,:)]';
            S_VIM = subs; F1_VIM = f1; F2_VIM = f2;
        else
            Y_VIM = [Y_VIM; [FAILSTOP_main(is,:) SUCCSTOP_main(is,:) MATCHGO_main(is,:)]'];
            S_VIM = [S_VIM; subs]; F1_VIM = [F1_VIM; f1];
            F2_VIM = [F2_VIM; f2];
        end
    end
end

factnames = {'trialtype','timepoint'};
perm = 10000; % how many times to run
% run permutations to bootstrap
    disp('Please wait... completing permutations... ');

for ip = 1:perm
    permstats = [];
    Y_STN_rand = Y_STN(randperm(length(Y_STN)));
    Y_VIM_rand = Y_VIM(randperm(length(Y_VIM)));
    
    perm_stats = rm_anova2(Y_STN_rand,S_STN,F1_STN,F2_STN,factnames);
    STN_typeF(ip) = perm_stats{2,5};
    STN_timeF(ip) = perm_stats{3,5};
    STN_intF(ip) = perm_stats{4,5};
    
    perm_stats = rm_anova2(Y_VIM_rand,S_VIM,F1_VIM,F2_VIM,factnames);
    VIM_typeF(ip) = perm_stats{2,5};
    VIM_timeF(ip) = perm_stats{3,5};
    VIM_intF(ip) = perm_stats{4,5};
end
% define sig cutoff based on permutations
STN_typecutoff = quantile(STN_typeF,0.95); VIM_typecutoff = quantile(VIM_typeF,0.95);
STN_timecutoff = quantile(STN_timeF,0.95); VIM_timecutoff = quantile(VIM_timeF,0.95);
STN_intcutoff = quantile(STN_intF,0.95); VIM_intcutoff = quantile(VIM_intF,0.95);

% run actual value ANOVA
STN_final_stats = rm_anova2(Y_STN,S_STN,F1_STN,F2_STN,factnames);
VIM_final_stats = rm_anova2(Y_VIM,S_VIM,F1_VIM,F2_VIM,factnames);
disp('Statistical results for stop-locked burst rate analysis:');
disp('Significant effects in STN sample: ');
if STN_final_stats{2,5} > STN_typecutoff
    disp(['Trial type: F = ' num2str(STN_final_stats{2,5}) ', p = ' num2str(STN_final_stats{2,6})]);
end
if STN_final_stats{3,5} > STN_timecutoff
    disp(['Timepoint: F = ' num2str(STN_final_stats{3,5}) ', p = ' num2str(STN_final_stats{3,6})]);
end
if STN_final_stats{4,5} > STN_intcutoff
    disp(['Trial x time interaction: F = ' num2str(STN_final_stats{4,5}) ', p = ' num2str(STN_final_stats{4,6})]);
end

disp('Significant effects in VIM sample: ');
if VIM_final_stats{2,5} > VIM_typecutoff
    disp(['Trial type: F = ' num2str(VIM_final_stats{2,5}) ', p = ' num2str(VIM_final_stats{2,6})]);
end
if VIM_final_stats{3,5} > VIM_timecutoff
    disp(['Timepoint: F = ' num2str(VIM_final_stats{3,5}) ', p = ' num2str(VIM_final_stats{3,6})]);
end
if VIM_final_stats{4,5} > VIM_intcutoff
    disp(['Trial x time interaction: F = ' num2str(VIM_final_stats{4,5}) ', p = ' num2str(VIM_final_stats{4,6})]);
end

% parse individual time points using t-tests
for it = 1:length(nbins)-1
    [~,STN_gop(it)] = ttest(SUCCSTOP_main(stn,it),MATCHGO_main(stn,it));
    [~,VIM_gop(it)] = ttest(SUCCSTOP_main(tha_to_do,it),MATCHGO_main(tha_to_do,it));
    [~,STN_failp(it)] = ttest(SUCCSTOP_main(stn,it),FAILSTOP_main(stn,it));
    [~,VIM_failp(it)] = ttest(SUCCSTOP_main(tha_to_do,it),FAILSTOP_main(tha_to_do,it));    
end
corrected_go_STNp = bonf_holm(STN_gop); corrected_fail_STNp = bonf_holm(STN_failp);
corrected_go_VIMp = bonf_holm(VIM_gop); corrected_fail_VIMp = bonf_holm(VIM_failp);
disp('STN sample - Significant burst differences were seen between SS and Go trials at these time points:');
for it = 1:length(nbins)-1
    if corrected_go_STNp(it)<=.05; disp([num2str(nbins(it)) ' to ' num2str(nbins(it+1)) 'ms: p = ' num2str(corrected_go_STNp(it))]); end
end
disp('STN sample - Significant burst differences were seen between SS and FS trials at these time points:');
for it = 1:length(nbins)-1
    if corrected_fail_STNp(it)<=.05; disp([num2str(nbins(it)) ' to ' num2str(nbins(it+1)) 'ms: p = ' num2str(corrected_fail_STNp(it))]); end
end
disp('VIM sample - Significant burst differences were seen between SS and Go trials at these time points:');
for it = 1:length(nbins)-1
    if corrected_go_VIMp(it)<=.05; disp([num2str(nbins(it)) ' to ' num2str(nbins(it+1)) 'ms: p = ' num2str(corrected_go_VIMp(it))]); end
end
disp('VIM sample - Significant burst differences were seen between SS and FS trials at these time points:');
for it = 1:length(nbins)-1
    if corrected_fail_VIMp(it)<=.05; disp([num2str(nbins(it)) ' to ' num2str(nbins(it+1)) 'ms: p = ' num2str(corrected_fail_VIMp(it))]); end
end

% baseline stats
% Set up and run one-way ANOVA with bootstrapping
STN_mat = [SUCCGO_blbg(stn,:) FAILGO_blbg(stn,:) GO_blbg(stn,:)];
VIM_mat = [SUCCGO_blbg(tha_to_do,:) FAILGO_blbg(tha_to_do,:) GO_blbg(tha_to_do,:)];
perm = 10000;
disp(['Please wait... completing permutation...']);
for ip = 1:perm
    permstats = [];
    STN_mat_rand = reshape(STN_mat(randperm(numel(STN_mat))),size(STN_mat));
    VIM_mat_rand = reshape(VIM_mat(randperm(numel(VIM_mat))),size(VIM_mat));

    perm_stats = rm_anova1(STN_mat_rand);
    STN_typeF(ip) = perm_stats.F;
    
    perm_stats = rm_anova1(VIM_mat_rand);
    VIM_typeF(ip) = perm_stats.F;
end
% define sig cutoff based on permutations
STN_typecutoff = quantile(STN_typeF,0.95); VIM_typecutoff = quantile(VIM_typeF,0.95);
% do real ANOVA
final_STNstats = rm_anova1(STN_mat);
if final_STNstats.F > STN_typecutoff
    disp(['Sig differences in pre-stop baseline, STN group: F = ' num2str(final_STNstats.F) ', p = ' num2str(final_STNstats.p)]);
end
final_VIMstats = rm_anova1(VIM_mat);
if final_VIMstats.F > VIM_typecutoff
    disp(['Sig differences in pre-stop baseline, VIM group: F = ' num2str(final_VIMstats.F) ', p = ' num2str(final_VIMstats.p)]);
end

% pre-go baseline
STN_mat = [SUCCGO_goblbg(stn,:) FAILGO_goblbg(stn,:) GO_goblbg(stn,:)];
VIM_mat = [SUCCGO_goblbg(tha_to_do,:) FAILGO_goblbg(tha_to_do,:) GO_goblbg(tha_to_do,:)];
perm = 10000;
disp(['Please wait... completing permutation...']);
for ip = 1:perm
    permstats = [];
    STN_mat_rand = reshape(STN_mat(randperm(numel(STN_mat))),size(STN_mat));
    VIM_mat_rand = reshape(VIM_mat(randperm(numel(VIM_mat))),size(VIM_mat));

    perm_stats = rm_anova1(STN_mat_rand);
    STN_typeF(ip) = perm_stats.F;
    
    perm_stats = rm_anova1(VIM_mat_rand);
    VIM_typeF(ip) = perm_stats.F;
end
% define sig cutoff based on permutations
STN_typecutoff = quantile(STN_typeF,0.95); VIM_typecutoff = quantile(VIM_typeF,0.95);
% do real ANOVA
final_STNstats = rm_anova1(STN_mat);
if final_STNstats.F > STN_typecutoff
    disp(['Sig differences in pre-stop baseline, STN group: F = ' num2str(final_STNstats.F) ', p = ' num2str(final_STNstats.p)]);
end
final_VIMstats = rm_anova1(VIM_mat);
if final_VIMstats.F > VIM_typecutoff
    disp(['Sig differences in pre-stop baseline, VIM group: F = ' num2str(final_VIMstats.F) ', p = ' num2str(final_VIMstats.p)]);
end

% 2) Do stats for go-locked bursts in subcortex (FIgure 3)
% set up 2-way (condition x time) ANOVA w/permutations
% set up matrices
Y_STN = []; S_STN = []; F1_STN = []; F2_STN = [];
Y_VIM = []; S_VIM = []; F1_VIM = []; F2_VIM = [];
Y_VOP = []; S_VOP = []; F1_VOP = []; F2_VOP = [];
for is = 1:length(datasets)
    subs = repmat(is,1,(length(nbins)-1)*3)'; f1 = [ones(1,length(nbins)-1) repmat(2,1,length(nbins)-1) repmat(3,1,length(nbins)-1)]';
    f2 = repmat(1:length(nbins)-1,1,3)';
    if strcmpi(datasets(is).loc,'STN') || strcmpi(datasets(is).loc,'both')
        if isempty(Y_STN)
            Y_STN = [FAILGO_main(is,:) SUCCGO_main(is,:) GO_bg_main(is,:)]';
            S_STN = subs; F1_STN = f1; F2_STN = f2;
        else
            Y_STN = [Y_STN; [FAILGO_main(is,:) SUCCGO_main(is,:) GO_bg_main(is,:)]'];
            S_STN = [S_STN; subs]; F1_STN = [F1_STN; f1];
            F2_STN = [F2_STN; f2];
        end
    else
        if isempty(Y_VIM)
            Y_VIM = [FAILGO_main(is,:) SUCCGO_main(is,:) GO_bg_main(is,:)]';
            S_VIM = subs; F1_VIM = f1; F2_VIM = f2;
            Y_VOP = [D_FAILGO_main(is,:) D_SUCCGO_main(is,:) D_GO_bg_main(is,:)]';
            S_VOP = subs; F1_VOP = f1; F2_VOP = f2;
        else
            Y_VIM = [Y_VIM; [FAILGO_main(is,:) SUCCGO_main(is,:) GO_bg_main(is,:)]'];
            S_VIM = [S_VIM; subs]; F1_VIM = [F1_VIM; f1];
            F2_VIM = [F2_VIM; f2];
            Y_VOP = [Y_VOP; [D_FAILGO_main(is,:) D_SUCCGO_main(is,:) D_GO_bg_main(is,:)]'];
            S_VOP = [S_VOP; subs]; F1_VOP = [F1_VOP; f1]; F2_VOP = [F2_VOP; f2];
        end
    end
end
factnames = {'trialtype','timepoint'};
perm = 10000; % how many times to run
% run permutations to bootstrap
disp('Please wait... completing permutations... ');

for ip = 1:perm
    permstats = [];
    Y_STN_rand = Y_STN(randperm(length(Y_STN)));
    Y_VIM_rand = Y_VIM(randperm(length(Y_VIM)));
    Y_VOP_rand = Y_VOP(randperm(length(Y_VOP)));
    
    perm_stats = rm_anova2(Y_STN_rand,S_STN,F1_STN,F2_STN,factnames);
    STN_typeF(ip) = perm_stats{2,5};
    STN_timeF(ip) = perm_stats{3,5};
    STN_intF(ip) = perm_stats{4,5};
    
    perm_stats = rm_anova2(Y_VIM_rand,S_VIM,F1_VIM,F2_VIM,factnames);
    VIM_typeF(ip) = perm_stats{2,5};
    VIM_timeF(ip) = perm_stats{3,5};
    VIM_intF(ip) = perm_stats{4,5};
    
    perm_stats = rm_anova2(Y_VOP_rand,S_VOP,F1_VOP,F2_VOP,factnames);
    VOP_typeF(ip) = perm_stats{2,5};
    VOP_timeF(ip) = perm_stats{3,5};
    VOP_intF(ip) = perm_stats{4,5};    
end
% define sig cutoff based on permutations
STN_typecutoff = quantile(STN_typeF,0.95); VIM_typecutoff = quantile(VIM_typeF,0.95); VOP_typecutoff = quantile(VOP_typeF,0.95);
STN_timecutoff = quantile(STN_timeF,0.95); VIM_timecutoff = quantile(VIM_timeF,0.95); VOP_timecutoff = quantile(VOP_timeF,0.95);
STN_intcutoff = quantile(STN_intF,0.95); VIM_intcutoff = quantile(VIM_intF,0.95); VOP_intcutoff = quantile(VOP_intF,0.95);

% run actual value ANOVA
STN_final_stats = rm_anova2(Y_STN,S_STN,F1_STN,F2_STN,factnames);
VIM_final_stats = rm_anova2(Y_VIM,S_VIM,F1_VIM,F2_VIM,factnames);
VOP_final_stats = rm_anova2(Y_VOP,S_VOP,F1_VOP,F2_VOP,factnames);
disp('Statistical results for go-locked burst rate analysis in subcortex:');

disp('Significant effects in STN sample: ');
if STN_final_stats{2,5} > STN_typecutoff
    disp(['Trial type: F = ' num2str(STN_final_stats{2,5}) ', p = ' num2str(STN_final_stats{2,6})]);
end
if STN_final_stats{3,5} > STN_timecutoff
    disp(['Timepoint: F = ' num2str(STN_final_stats{3,5}) ', p = ' num2str(STN_final_stats{3,6})]);
end
if STN_final_stats{4,5} > STN_intcutoff
    disp(['Trial x time interaction: F = ' num2str(STN_final_stats{4,5}) ', p = ' num2str(STN_final_stats{4,6})]);
end

disp('Significant effects in VIM: ');
if VIM_final_stats{2,5} > VIM_typecutoff
    disp(['Trial type: F = ' num2str(VIM_final_stats{2,5}) ', p = ' num2str(VIM_final_stats{2,6})]);
end
if VIM_final_stats{3,5} > VIM_timecutoff
    disp(['Timepoint: F = ' num2str(VIM_final_stats{3,5}) ', p = ' num2str(VIM_final_stats{3,6})]);
end
if VIM_final_stats{4,5} > VIM_intcutoff
    disp(['Trial x time interaction: F = ' num2str(VIM_final_stats{4,5}) ', p = ' num2str(VIM_final_stats{4,6})]);
end

disp('Significant effects in VOP: ');
if VOP_final_stats{2,5} > VOP_typecutoff
    disp(['Trial type: F = ' num2str(VOP_final_stats{2,5}) ', p = ' num2str(VOP_final_stats{2,6})]);
end
if VOP_final_stats{3,5} > VOP_timecutoff
    disp(['Timepoint: F = ' num2str(VOP_final_stats{3,5}) ', p = ' num2str(VOP_final_stats{3,6})]);
end
if VOP_final_stats{4,5} > VOP_intcutoff
    disp(['Trial x time interaction: F = ' num2str(VOP_final_stats{4,5}) ', p = ' num2str(VOP_final_stats{4,6})]);
end
% parse individual time points using t tests
for it = 1:length(nbins)-1
    [~,STN_gop(it)] = ttest(SUCCGO_main(stn,it),GO_bg_main(stn,it));
    [~,VIM_gop(it)] = ttest(SUCCGO_main(tha_to_do,it),GO_bg_main(tha_to_do,it));
    [~,VOP_gop(it)] = ttest(D_SUCCGO_main(tha_to_do,it),D_GO_bg_main(tha_to_do,it));
    [~,STN_failp(it)] = ttest(SUCCGO_main(stn,it),FAILGO_main(stn,it));
    [~,VIM_failp(it)] = ttest(SUCCGO_main(tha_to_do,it),FAILGO_main(tha_to_do,it));
    [~,VOP_failp(it)] = ttest(D_SUCCGO_main(tha_to_do,it),D_FAILGO_main(tha_to_do,it));
end
corrected_go_STNp = bonf_holm(STN_gop); corrected_fail_STNp = bonf_holm(STN_failp);
corrected_go_VIMp = bonf_holm(VIM_gop); corrected_fail_VIMp = bonf_holm(VIM_failp);
corrected_go_VOPp = bonf_holm(VOP_gop); corrected_fail_VOPp = bonf_holm(VOP_failp);
disp('STN sample - Significant burst differences were seen between SS and Go trials at these time points:');
for it = 1:length(nbins)-1
    if corrected_go_STNp(it)<=.05; disp([num2str(nbins(it)) ' to ' num2str(nbins(it+1)) 'ms: p = ' num2str(corrected_go_STNp(it))]); end
end
disp('STN sample - Significant burst differences were seen between SS and FS trials at these time points:');
for it = 1:length(nbins)-1
    if corrected_fail_STNp(it)<=.05; disp([num2str(nbins(it)) ' to ' num2str(nbins(it+1)) 'ms: p = ' num2str(corrected_fail_STNp(it))]); end
end
disp('VIM sample - Significant burst differences were seen between SS and Go trials at these time points:');
for it = 1:length(nbins)-1
    if corrected_go_VIMp(it)<=.05; disp([num2str(nbins(it)) ' to ' num2str(nbins(it+1)) 'ms: p = ' num2str(corrected_go_VIMp(it))]); end
end
disp('VIM sample - Significant burst differences were seen between SS and FS trials at these time points:');
for it = 1:length(nbins)-1
    if corrected_fail_VIMp(it)<=.05; disp([num2str(nbins(it)) ' to ' num2str(nbins(it+1)) 'ms: p = ' num2str(corrected_fail_VIMp(it))]); end
end
disp('VOP sample - Significant burst differences were seen between SS and Go trials at these time points:');
for it = 1:length(nbins)-1
    if corrected_go_VOPp(it)<=.05; disp([num2str(nbins(it)) ' to ' num2str(nbins(it+1)) 'ms: p = ' num2str(corrected_go_VOPp(it))]); end
end
disp('VOP sample - Significant burst differences were seen between SS and FS trials at these time points:');
for it = 1:length(nbins)-1
    if corrected_fail_VOPp(it)<=.05; disp([num2str(nbins(it)) ' to ' num2str(nbins(it+1)) 'ms: p = ' num2str(corrected_fail_VOPp(it))]); end
end

% 3) Do stats for ipsi- versus contralateral go-locked bursts in M1 (FIgure 3)
% set up 2-way (condition x time) ANOVA w/permutations
% set up matrices
Y = []; S= []; F1 = []; F2= [];
for is = 1:length(datasets)
    subs = repmat(is,1,(length(nbins)-1)*2)'; f1 = [ones(1,length(nbins)-1) repmat(2,1,length(nbins)-1)]';
    f2 = repmat(1:length(nbins)-1,1,2)';
    if isempty(Y)
        Y = [CONTRAGO_main(is,:) IPSIGO_main(is,:)]';
        S = subs; F1 = f1; F2 = f2;
    else
        Y = [Y; [CONTRAGO_main(is,:) IPSIGO_main(is,:)]'];
        S = [S; subs]; F1 = [F1; f1];
        F2 = [F2; f2];
    end
end
factnames = {'trialtype','timepoint'};
perm = 10000; % how many times to run
% run permutations to bootstrap
disp('Please wait... completing permutations... ');
for ip = 1:perm
    permstats = [];
    Y_rand = Y(randperm(length(Y)));
    
    perm_stats = rm_anova2(Y_rand,S,F1,F2,factnames);
    typeF(ip) = perm_stats{2,5};
    timeF(ip) = perm_stats{3,5};
    intF(ip) = perm_stats{4,5};
    
end
% define sig cutoff based on permutations
typecutoff = quantile(typeF,0.95); 
timecutoff = quantile(timeF,0.95); 
intcutoff = quantile(intF,0.95); 

% run actual value ANOVA
final_stats = rm_anova2(Y,S,F1,F2,factnames);
disp('Statistical results for go-locked burst rate analysis in motor cortex (contra- vs ipsi- go trials):');

disp('Significant effects: ');
if final_stats{2,5} > typecutoff
    disp(['Trial type: F = ' num2str(final_stats{2,5}) ', p = ' num2str(final_stats{2,6})]);
end
if final_stats{3,5} > timecutoff
    disp(['Timepoint: F = ' num2str(final_stats{3,5}) ', p = ' num2str(final_stats{3,6})]);
end
if final_stats{4,5} > intcutoff
    disp(['Trial x time interaction: F = ' num2str(final_stats{4,5}) ', p = ' num2str(final_stats{4,6})]);
end

% parse individual time points using t tests
for it = 1:length(nbins)-1
    [~,gop(it)] = ttest(CONTRAGO_main(:,it),IPSIGO_main(:,it));
end
corrected_gop = bonf_holm(gop); 
disp('Significant burst differences were seen between ipsilateral and contralateral go trials at these time points:');
for it = 1:length(nbins)-1
    if corrected_gop(it)<=.05; disp([num2str(nbins(it)) ' to ' num2str(nbins(it+1)) 'ms: p = ' num2str(corrected_gop(it))]); end
end

% 4) Do stats for dorsal thalamus
% 1) Do stats for stop-locked bursts (Figure 4) 
% set up 2-way (condition x time) ANOVA w/permutations
% set up matrices
Y_VIM = []; S_VIM = []; F1_VIM = []; F2_VIM = []; thacnt = 0;
for is = 1:length(tha)
    subs = repmat(is,1,(length(nbins)-1)*3)'; f1 = [ones(1,length(nbins)-1) repmat(2,1,length(nbins)-1) repmat(3,1,length(nbins)-1)]';
    f2 = repmat(1:length(nbins)-1,1,3)';
    if isempty(Y_VIM)
        Y_VIM = [D_FAILSTOP_main(tha(is),:) D_SUCCSTOP_main(tha(is),:) D_MATCHGO_main(tha(is),:)]';
        S_VIM = subs; F1_VIM = f1; F2_VIM = f2;
    else
        Y_VIM = [Y_VIM; [D_FAILSTOP_main(tha(is),:) D_SUCCSTOP_main(tha(is),:) D_MATCHGO_main(tha(is),:)]'];
        S_VIM = [S_VIM; subs]; F1_VIM = [F1_VIM; f1];
        F2_VIM = [F2_VIM; f2];
    end
end

factnames = {'trialtype','timepoint'};
perm = 10000; % how many times to run
% run permutations to bootstrap
    disp('Please wait... completing permutations... ');

for ip = 1:perm
    permstats = [];
    Y_VIM_rand = Y_VIM(randperm(length(Y_VIM)));
    
    perm_stats = rm_anova2(Y_VIM_rand,S_VIM,F1_VIM,F2_VIM,factnames);
    VIM_typeF(ip) = perm_stats{2,5};
    VIM_timeF(ip) = perm_stats{3,5};
    VIM_intF(ip) = perm_stats{4,5};
end
% define sig cutoff based on permutations
VIM_typecutoff = quantile(VIM_typeF,0.95);
VIM_timecutoff = quantile(VIM_timeF,0.95);
VIM_intcutoff = quantile(VIM_intF,0.95);

% run actual value ANOVA
VIM_final_stats = rm_anova2(Y_VIM,S_VIM,F1_VIM,F2_VIM,factnames);
disp('Dorsal thalamus - Statistical results for stop-locked burst rate analysis:');

disp('Significant effects in VIM sample: ');
if VIM_final_stats{2,5} > VIM_typecutoff
    disp(['Trial type: F = ' num2str(VIM_final_stats{2,5}) ', p = ' num2str(VIM_final_stats{2,6})]);
end
if VIM_final_stats{3,5} > VIM_timecutoff
    disp(['Timepoint: F = ' num2str(VIM_final_stats{3,5}) ', p = ' num2str(VIM_final_stats{3,6})]);
end
if VIM_final_stats{4,5} > VIM_intcutoff
    disp(['Trial x time interaction: F = ' num2str(VIM_final_stats{4,5}) ', p = ' num2str(VIM_final_stats{4,6})]);
end

% parse individual time points using t-tests
for it = 1:length(nbins)-1
    [~,VIM_gop(it)] = ttest(D_SUCCSTOP_main(tha,it),D_MATCHGO_main(tha,it));
    [~,VIM_failp(it)] = ttest(D_SUCCSTOP_main(tha,it),D_FAILSTOP_main(tha,it));    
end
corrected_go_VIMp = bonf_holm(VIM_gop); corrected_fail_VIMp = bonf_holm(VIM_failp);
disp('VIM sample - Significant burst differences were seen between SS and Go trials at these time points:');
for it = 1:length(nbins)-1
    if corrected_go_VIMp(it)<=.05; disp([num2str(nbins(it)) ' to ' num2str(nbins(it+1)) 'ms: p = ' num2str(corrected_go_VIMp(it))]); end
end
disp('VIM sample - Significant burst differences were seen between SS and FS trials at these time points:');
for it = 1:length(nbins)-1
    if corrected_fail_VIMp(it)<=.05; disp([num2str(nbins(it)) ' to ' num2str(nbins(it+1)) 'ms: p = ' num2str(corrected_fail_VIMp(it))]); end
end
% baseline stats
% Set up and run one-way ANOVA with bootstrapping
VIM_mat = [D_SUCCGO_blbg(tha_to_do,:) D_FAILGO_blbg(tha_to_do,:) D_GO_blbg(tha_to_do,:)];
perm = 10000;
disp(['Please wait... completing permutation...']);
for ip = 1:perm
    permstats = [];
    VIM_mat_rand = reshape(VIM_mat(randperm(numel(VIM_mat))),size(VIM_mat));
    
    perm_stats = rm_anova1(VIM_mat_rand);
    VIM_typeF(ip) = perm_stats.F;
end
% define sig cutoff based on permutations
VIM_typecutoff = quantile(VIM_typeF,0.95);
% do real ANOVA
final_VIMstats = rm_anova1(VIM_mat);
if final_VIMstats.F > VIM_typecutoff
    disp(['Sig differences in pre-stop baseline, dorsal thalamus: F = ' num2str(final_VIMstats.F) ', p = ' num2str(final_VIMstats.p)]);
end
% pre-go baseline
VIM_mat = [D_SUCCGO_goblbg(tha_to_do,:) D_FAILGO_goblbg(tha_to_do,:) D_GO_goblbg(tha_to_do,:)];
perm = 10000;
disp(['Please wait... completing permutation...']);
for ip = 1:perm
    permstats = [];
    VIM_mat_rand = reshape(VIM_mat(randperm(numel(VIM_mat))),size(VIM_mat));
    
    perm_stats = rm_anova1(VIM_mat_rand);
    VIM_typeF(ip) = perm_stats.F;
end
% define sig cutoff based on permutations
VIM_typecutoff = quantile(VIM_typeF,0.95);
% do real ANOVA
final_VIMstats = rm_anova1(VIM_mat);
if final_VIMstats.F > VIM_typecutoff
    disp(['Sig differences in pre-go baseline, dorsal thalamus: F = ' num2str(final_VIMstats.F) ', p = ' num2str(final_VIMstats.p)]);
end

%barweb for stops
h = figure('Color','w');
subplot(2,2,1);
barweb([nanmean(FAILSTOP_main(stn,:));nanmean(SUCCSTOP_main(stn,:));nanmean(MATCHGO_main(stn,:))]',[sem(FAILSTOP_main(stn,:));sem(SUCCSTOP_main(stn,:));sem(MATCHGO_main(stn,:))]',.8,cellfun(@num2str,num2cell(nbins(2:end)),'UniformOutput',0),'Beta in STN on stop trials', 'time (ms) after stop signal', 'proportion of trials', '', '', {'Failed stop','Succ stop','Matched go'});
subplot(2,2,2);
barweb([nanmean(FAILGO_blbg(stn,:));nanmean(SUCCGO_blbg(stn,:));nanmean(GO_blbg(stn,:))]',[sem(FAILGO_blbg(stn,:));sem(SUCCGO_blbg(stn,:));sem(GO_blbg(stn,:))]',.8,{'Burst rate/100ms'},'Beta in STN during pre-stop baseline', '500 ms before STOP', 'number of bursts', '', '', {'Failed stop','Succ stop','Matched go'});
subplot(2,2,3);
barweb([nanmean(FAILSTOP_main(tha_to_do,:));nanmean(SUCCSTOP_main(tha_to_do,:));nanmean(MATCHGO_main(tha_to_do,:))]',[sem(FAILSTOP_main(tha_to_do,:));sem(SUCCSTOP_main(tha_to_do,:));sem(MATCHGO_main(tha_to_do,:))]',.8,cellfun(@num2str,num2cell(nbins(2:end)),'UniformOutput',0),'Beta in VIM on stop trials', 'time (ms) after stop signal', 'proportion of trials', '', '', {'Failed stop','Succ stop','Matched go'});
subplot(2,2,4);
barweb([nanmean(FAILGO_blbg(tha_to_do,:));nanmean(SUCCGO_blbg(tha_to_do,:));nanmean(GO_blbg(tha_to_do,:))]',[sem(FAILGO_blbg(tha_to_do,:));sem(SUCCGO_blbg(tha_to_do,:));sem(GO_blbg(tha_to_do,:))]',.8,{'Burst rate/100ms'},'Beta in VIM during pre-stop baseline', '500 ms before STOP', 'number of bursts', '', '', {'Failed stop','Succ stop','Matched go'});

%barweb for go-locked bursts in subcortex
h = figure('Color','w');
subplot(3,1,1);
barweb([nanmean(FAILGO_main(stn,:));nanmean(SUCCGO_main(stn,:));nanmean(GO_bg_main(stn,:))]',[sem(FAILGO_main(stn,:));sem(SUCCGO_main(stn,:));sem(GO_bg_main(stn,:))]',.8,cellfun(@num2str,num2cell(nbins(2:end)),'UniformOutput',0),'Beta in STN on go trials', 'time (ms) after go signal', 'proportion of trials', '', '', {'Failed stop','Succ stop','Pure go'});
subplot(3,1,2);
barweb([nanmean(FAILGO_main(tha_to_do,:));nanmean(SUCCGO_main(tha_to_do,:));nanmean(GO_bg_main(tha_to_do,:))]',[sem(FAILGO_main(tha_to_do,:));sem(SUCCGO_main(tha_to_do,:));sem(GO_bg_main(tha_to_do,:))]',.8,cellfun(@num2str,num2cell(nbins(2:end)),'UniformOutput',0),'Beta in VIM on go trials', 'time (ms) after go signal', 'proportion of trials', '', '', {'Failed stop','Succ stop','Pure go'});
subplot(3,1,3);
barweb([nanmean(D_FAILGO_main(tha_to_do,:));nanmean(D_SUCCGO_main(tha_to_do,:));nanmean(D_GO_bg_main(tha_to_do,:))]',[sem(D_FAILGO_main(tha_to_do,:));sem(D_SUCCGO_main(tha_to_do,:));sem(D_GO_bg_main(tha_to_do,:))]',.8,cellfun(@num2str,num2cell(nbins(2:end)),'UniformOutput',0),'Beta in VOP on go trials', 'time (ms) after go signal', 'proportion of trials', '', '', {'Failed stop','Succ stop','Pure go'});

% barweb for ipsi and contralateral gos in motor cortex
h = figure('Color','w');
barweb([nanmean(CONTRAGO_main,1);nanmean(IPSIGO_main,1)]',[sem(CONTRAGO_main);sem(IPSIGO_main)]',.8,cellfun(@num2str,num2cell(nbins(2:end)),'UniformOutput',0),'Beta in M1 on go trials', 'time (ms) after go signal', 'number of bursts', '', '', {'Contra','Ipsi'});

%barweb for stops in dorsal thalamus
h = figure('Color','w');
subplot(2,1,1);
barweb([nanmean(D_FAILSTOP_main(tha,:));nanmean(D_SUCCSTOP_main(tha,:));nanmean(D_MATCHGO_main(tha,:))]',[sem(D_FAILSTOP_main(tha,:));sem(D_SUCCSTOP_main(tha,:));sem(D_MATCHGO_main(tha,:))]',.8,cellfun(@num2str,num2cell(nbins(2:end)),'UniformOutput',0),'Beta in dorsal thalamus on stop trials', 'time (ms) after stop signal', 'proportion of trials', '', '', {'Failed stop','Succ stop','Matched go'});
subplot(2,1,2);
barweb([nanmean(D_FAILGO_blbg(tha,:));nanmean(D_SUCCGO_blbg(tha,:));nanmean(D_GO_blbg(tha,:))]',[sem(D_FAILGO_blbg(tha,:));sem(D_SUCCGO_blbg(tha,:));sem(D_GO_blbg(tha,:))]',.8,{'Burst rate/100ms'},'Beta in dorsal thalamus during pre-stop baseline', '500 ms before STOP', 'number of bursts', '', '', {'Failed stop','Succ stop','Matched go'});

% pre-go baselines 
h = figure('Color','w');
subplot(3,1,1);
barweb([nanmean(FAILGO_goblbg(stn,:));nanmean(SUCCGO_goblbg(stn,:));nanmean(GO_goblbg(stn,:))]',[sem(FAILGO_goblbg(stn,:));sem(SUCCGO_goblbg(stn,:));sem(GO_goblbg(stn,:))]',.8,{'Burst rate/100ms'},'Beta in STN during pre-go baseline', '500 ms before GO', 'number of bursts', '', '', {'Failed stop','Succ stop','Matched go'});
subplot(3,1,2);
barweb([nanmean(FAILGO_goblbg(tha_to_do,:));nanmean(SUCCGO_goblbg(tha_to_do,:));nanmean(GO_goblbg(tha_to_do,:))]',[sem(FAILGO_goblbg(tha_to_do,:));sem(SUCCGO_goblbg(tha_to_do,:));sem(GO_goblbg(tha_to_do,:))]',.8,{'Burst rate/100ms'},'Beta in ventral thalamus during pre-go baseline', '500 ms before GO', 'number of bursts', '', '', {'Failed stop','Succ stop','Matched go'});
subplot(3,1,3);
barweb([nanmean(D_FAILGO_goblbg(tha,:));nanmean(D_SUCCGO_goblbg(tha,:));nanmean(D_GO_goblbg(tha,:))]',[sem(D_FAILGO_goblbg(tha,:));sem(D_SUCCGO_goblbg(tha,:));sem(D_GO_goblbg(tha,:))]',.8,{'Burst rate/100ms'},'Beta in dorsal thalamus during pre-go baseline', '500 ms before GO', 'number of bursts', '', '', {'Failed stop','Succ stop','Matched go'});

% comparisons between sig time bins and baselines
[~,STN_goblcomp] = ttest(SUCCSTOP_main(stn,7),SUCCGO_goblbg(stn,:));
[~,STN_stopblcomp] = ttest(SUCCSTOP_main(stn,7),SUCCGO_blbg(stn,:));
[~,VIM_goblcomp] = ttest(SUCCSTOP_main(tha_to_do,6),SUCCGO_goblbg(tha_to_do,:));
[~,VIM_stopblcomp] = ttest(SUCCSTOP_main(tha_to_do,6),SUCCGO_blbg(tha_to_do,:));
[~,VOP_goblcomp] = ttest(D_SUCCSTOP_main(tha,6),D_SUCCGO_goblbg(tha,:));
[~,VOP_stopblcomp] = ttest(D_SUCCSTOP_main(tha,6),D_SUCCGO_blbg(tha,:));