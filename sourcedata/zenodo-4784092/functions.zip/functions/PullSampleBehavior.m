%% Pull sample behavioral results
% In this section we extract accuracy and rt from the trials that were
% included in the beta analysis.
% which to include in thalamic group, i.e. not participant with both tha
% and stn recordings
tha_to_do = tha(2:end);
for is = 1:length(datasets)
    % load
    subnum = datasets(is).subnum;
    load(fullfile(fullfile(folders.behavout,['Subject' num2str(subnum) '_behavanalysis.mat'])));
    % trial counts
    COUNT_GO(is) = behav.numbers.go.cor;
    COUNT_FAIL(is) = behav.numbers.stop.fail;
    COUNT_STOP(is) = behav.numbers.stop.succ;
    % accuracy
    ACC_GO(is) = 1-behav.rates.error-behav.rates.miss;
    ACC_STOP(is) = behav.rates.stopsucc;
    % RT
    RT_GO(is) = behav.RT.corgo;
    RT_FAIL(is) = behav.RT.failstop;
    RT_SSRT(is) = behav.RT.SSRTi;
    
end
% all-subjects averages
AVG_COUNT_GO = mean(COUNT_GO); AVG_COUNT_FAIL = mean(COUNT_FAIL);
AVG_COUNT_STOP = mean(COUNT_STOP); 
AVG_ACC_GO = mean(ACC_GO); AVG_ACC_STOP = mean(ACC_STOP);
AVG_RT_GO = mean(RT_GO); AVG_RT_FAIL = mean(RT_FAIL); 
AVG_RT_SSRT = mean(RT_SSRT);

% separate by samples
VIM_ACC_GO = mean(ACC_GO(tha_to_do)); VIM_ACC_STOP = mean(ACC_STOP(tha_to_do));
VIM_RT_GO = mean(RT_GO(tha_to_do)); VIM_RT_FAIL = mean(RT_FAIL(tha_to_do)); VIM_RT_SSRT = mean(RT_SSRT(tha_to_do));
STN_ACC_GO = mean(ACC_GO(stn)); STN_ACC_STOP = mean(ACC_STOP(stn));
STN_RT_GO = mean(RT_GO(stn)); STN_RT_FAIL = mean(RT_FAIL(stn)); STN_RT_SSRT = mean(RT_SSRT(stn));

% test group differences
[~,goacc_diff,~,goacc_stats] = ttest2(ACC_GO(tha_to_do),ACC_GO(stn));
[~,stopacc_diff,~,stopacc_stats] = ttest2(ACC_STOP(tha_to_do),ACC_STOP(stn));
[~,gort_diff,~,gort_stats] = ttest2(RT_GO(tha_to_do),RT_GO(stn));
[~,failrt_diff,~,fail_rtstats] = ttest2(RT_FAIL(tha_to_do),RT_FAIL(stn));
[~,ssrt_diff,~,ssrt_stats] = ttest2(RT_SSRT(tha_to_do),RT_SSRT(stn));

% print behavioral info in the command window
disp('Here are the behavioral measures from subjects and blocks included in analysis!');
disp('Sample averages:')
disp(['Go accuracy was ' num2str(AVG_ACC_GO) ' and stop accuracy was ' num2str(AVG_ACC_STOP) '.']);
disp(['Go RT was ' num2str(AVG_RT_GO) 'ms and failed stop RT was ' num2str(AVG_RT_FAIL) 'ms.']);
disp(['Estimated SSRT was ' num2str(AVG_RT_SSRT) '.']);
disp('STN group:');
disp(['Go accuracy was ' num2str(STN_ACC_GO) ' and stop accuracy was ' num2str(STN_ACC_STOP) '.']);
disp(['Go RT was ' num2str(STN_RT_GO) 'ms and failed stop RT was ' num2str(STN_RT_FAIL) 'ms.']);
disp(['Estimated SSRT was ' num2str(STN_RT_SSRT) '.']);
disp('Thal group:');
disp(['Go accuracy was ' num2str(VIM_ACC_GO) ' and stop accuracy was ' num2str(VIM_ACC_STOP) '.']);
disp(['Go RT was ' num2str(VIM_RT_GO) 'ms and failed stop RT was ' num2str(VIM_RT_FAIL) 'ms.']);
disp(['Estimated SSRT was ' num2str(VIM_RT_SSRT) '.']);

if goacc_diff < .05
    disp(['There were significant differences between the groups for go accuracy: p = ' num2str(goacc_diff)]);
end
if stopacc_diff < .05
    disp(['There were significant differences between the groups for stop accuracy: p = ' num2str(stopacc_diff)]);
end
if gort_diff < .05
    disp(['There were significant differences between the groups for go RT: p = ' num2str(gort_diff)]);
end
if failrt_diff < .05
    disp(['There were significant differences between the groups for failed stop RT: p = ' num2str(failrt_diff)]);
end
if ssrt_diff < .05
    disp(['There were significant differences between the groups for SSRT: p = ' num2str(ssrt_diff)]);
end