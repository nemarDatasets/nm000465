function id = triallayout_Audiostop

% column indices for Audiostop
id.num = 1;
id.blo = 2;
id.dir = 3;
id.stop = 4;
id.lssd = 5;
id.rssd = 6;
id.resp = 7;
id.rt = 8;
id.acc = 9;
id.time = 10;