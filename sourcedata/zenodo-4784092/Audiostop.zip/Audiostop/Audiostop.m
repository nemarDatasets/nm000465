% initialize
clear; clc;

% input
data(1).Nr = input('Subject Number: ');
data.eeg = input('Send triggers? ');
data.age = input('Age? ');
data.gender = input('Gender? (m/f) ','s');
data.hand = input('Handedness? (l/r) ','s');
settings.input.ssd = input('Initial SSD? ');
settings.input.trials.go = input('Go trials per block? Must be divisable by 2. ');
settings.input.trials.stop = input('Stop trials per block? Must be divisable by 2. ');
settings.input.blocks = input('Blocks? ');

% triggers
if data.eeg == 1;
    settings.eeg.USB = DaqDeviceIndex();
    DaqDConfigPort(settings.eeg.USB,0,0);
    DaqDConfigPort(settings.eeg.USB,1,0);
    settings.eeg.marker_unit = 0.005; % 5 ms
    

end

% folders
settings.files.outfolder = fullfile(fileparts(which('Audiostop')),'out');
clocktime = clock; hrs = num2str(clocktime(4)); mins = num2str(clocktime(5));
settings.files.outfile = ['Subject_' num2str(data.Nr) '_' date '_' hrs '.' mins 'h.mat'];

% initialize
HideCursor;
InitializePsychSound(1);

% duration
settings.duration.deadline = 2; % response deadline
settings.duration.trial = 4; % response deadline
settings.duration.ssd_max = 1000; % max ssd (in ms)
settings.duration.ssd_increment = 50; % ssd adjusment (in ms)

% open sound device
settings.sound.srate = 44100; % sample rate (optimize for each system. some OS need specific srates. need to minimize the Output latency output ont he command line. 44100 works best for most modern systems)
settings.sound.channels = 2; % 1 = mono, 2 = stereo (needs 2 column vector)
settings.sound.audiohandle = PsychPortAudio('Open', [], [], 0, settings.sound.srate, settings.sound.channels);

% make SOUNDS
settings.sound.go.duration = .1; % duration of sound in sec
settings.sound.go.freq = 500; % Hz of the sine wave
settings.sound.stop.freq = 1000; % Hz of the sine wave
settings.sound.stop.duration = .1; % Hz of the sine wave
% go tones
asamples = 0:1/settings.sound.srate:settings.sound.go.duration; % vector with sample points
gotone = sin(2* pi * settings.sound.go.freq * asamples); % make the sine wave
right_tone = [zeros(1,length(gotone)); gotone]; % right go
left_tone = [gotone; zeros(1,length(gotone))]; % left go

% stop tone
asamples = 0:1/settings.sound.srate:settings.sound.stop.duration; % vector with sample points
stoptone = sin(2* pi * settings.sound.stop.freq * asamples); % make the sine wave
stop_tone = [stoptone; stoptone]; % right go

% columns
id.num = 1;
id.blo = 2;
id.dir = 3;
id.stop = 4;
id.lssd = 5;
id.rssd = 6;
id.resp = 7;
id.rt = 8;
id.acc = 9;
id.time = 10;

% make trialseq
trialseq = [];
for ib = 1:settings.input.blocks
    
    % go-trials
    gotrials = zeros(settings.input.trials.go,length(fieldnames(id)));
    % directions
    gotrials(1:settings.input.trials.go/2,id.dir) = 1; % left
    gotrials(settings.input.trials.go/2+1:end,id.dir) = 2; % right
    
    % stop-trials
    stoptrials = zeros(settings.input.trials.stop,length(fieldnames(id)));
    % directions
    stoptrials(1:settings.input.trials.stop/2,id.dir) = 1; % left
    stoptrials(settings.input.trials.stop/2+1:end,id.dir) = 2; % right
    % stop
    stoptrials(:,id.stop) = 1;
    
    % merge
    blocktrials = [gotrials;stoptrials];
    blocktrials(:,id.blo) = ib; % block number
    
    % shuffle
    blocktrials = blocktrials(randperm(size(blocktrials,1)),:);
    
    % append
    trialseq = [trialseq; blocktrials];
    
end
% trialnumbers
trialseq(:,id.num) = 1:size(trialseq,1);
% ssd
trialseq(:,id.lssd) = settings.input.ssd;
trialseq(:,id.rssd) = settings.input.ssd;

% first sound buffer
if trialseq(1,id.dir) == 1
    PsychPortAudio('FillBuffer', settings.sound.audiohandle, left_tone);
elseif trialseq(1,id.dir) ==2 
    PsychPortAudio('FillBuffer', settings.sound.audiohandle, right_tone);
end
sides = {'left';'right'};

% GO THROUGH TRIALS
btime = GetSecs;
for it = 1:size(trialseq,1)
    
    % stimulus
    starttime = GetSecs; trialseq(it,id.time) = GetSecs - btime;
    if data.eeg == 1; TMStrigger('tms2',settings.eeg.USB); end
    PsychPortAudio('Start', settings.sound.audiohandle, 1, 0, 1);
    disp(['Stimulus ' sides{trialseq(it,id.dir)}]);
    
    % pre-buffer stop
    if trialseq(it,id.stop) == 1 %&& trialseq(it,id.dir) == 2
        if data.eeg == 1; TMStrigger('tms2',settings.eeg.USB); end
        PsychPortAudio('FillBuffer', settings.sound.audiohandle, stop_tone);
        disp('Stop Signal');
    end
    
    % wait for resp
    respflag = false; stopflag = false; % flags
    SSD = trialseq(it,id.stop+trialseq(it,id.dir)); % SSD
    while GetSecs - starttime <= settings.duration.deadline
        
        % response
        if ~respflag
            
            % mouse input
            [~,~,buttons] = GetMouse;
            if any(buttons)
                trialseq(it,id.resp) = find(buttons);
                trialseq(it,id.rt) = 1000*(GetSecs - starttime);
                respflag = true;
            end
            
        end
        
        % stop signal
        if ~stopflag && trialseq(it,id.stop) == 1 && GetSecs >= starttime + SSD/1000
            PsychPortAudio('Start', settings.sound.audiohandle, 1, 0, 1);
            stopflag = true;
        end
        
    end
    
    % assess accuracy
    if trialseq(it,id.stop) == 0 % go
        
        if trialseq(it,id.rt) == 0; trialseq(it,id.acc) = 99; disp('Outcome: Miss.'); end % miss
        if trialseq(it,id.dir) == 1 % left
            if trialseq(it,id.resp) == 2 || trialseq(it,id.resp) == 3
                trialseq(it,id.acc) = 2;
                disp('Outcome: Error.');
            elseif trialseq(it,id.resp) == 1
                trialseq(it,id.acc) = 1;
                disp('Outcome: Correct.');
            end
        elseif trialseq(it,id.dir) == 2 % right
            if trialseq(it,id.resp) == 2 || trialseq(it,id.resp) == 3
                trialseq(it,id.acc) = 1;
                disp('Outcome: Correct.');
            elseif trialseq(it,id.resp) == 1
                trialseq(it,id.acc) = 2;
                disp('Outcome: Error.');
            end
        end
            
    elseif trialseq(it,id.stop) == 1 % stop
        
        if trialseq(it,id.resp) ~= 0 % failed stop
            trialseq(it,id.acc) = 4;
            disp('Outcome: Failed Stop.');
            % adjust SSD
            if it < size(trialseq,1)
                trialseq(it+1:end,id.stop+trialseq(it,id.dir)) = trialseq(it,id.stop+trialseq(it,id.dir)) - settings.duration.ssd_increment;
            end
        elseif trialseq(it,id.resp) == 0 % succ stop
            trialseq(it,id.acc) = 3;
            disp('Outcome: Successful Stop.');
            % adjust SSD
            if it < size(trialseq,1)
                trialseq(it+1:end,id.stop+trialseq(it,id.dir)) = trialseq(it,id.stop+trialseq(it,id.dir)) + settings.duration.ssd_increment;
            end
        end
        
        % check SSD limits
        if trialseq(it,id.stop+trialseq(it,id.dir)) < 0
            trialseq(it,id.stop+trialseq(it,id.dir)) = 0;
        end
        if trialseq(it,id.stop+trialseq(it,id.dir)) > settings.duration.ssd_max
            trialseq(it,id.stop+trialseq(it,id.dir)) = settings.duration.ssd_max;
        end
        
    end
    
    % buffer next tone
    if it < size(trialseq,1)
        if trialseq(it+1,id.dir) == 1
            PsychPortAudio('FillBuffer', settings.sound.audiohandle, left_tone);
        elseif trialseq(it+1,id.dir) == 2
            PsychPortAudio('FillBuffer', settings.sound.audiohandle, right_tone);
        end
    end
    
    % wait out trial duration
    while GetSecs - starttime <= settings.duration.trial
    end
    
    % save
    save(fullfile(settings.files.outfolder,settings.files.outfile),'settings','data','trialseq');
    
    % blockfeedback
    if it == size(trialseq,1) || trialseq(it,id.blo) ~= trialseq(it+1,id.blo)
        % get blocktrials
        btrials = trialseq(trialseq(:,id.blo) == trialseq(it,id.blo),:);
        % split trials
        gotrials = btrials(btrials(:,id.stop) == 0,:);
        correcttrials = gotrials(gotrials(:,id.acc)==1,:);
        stoptrials = btrials(btrials(:,id.stop) == 1,:);
        succstop = stoptrials(stoptrials(:,id.acc) == 3,:);
        failstop = stoptrials(stoptrials(:,id.acc) == 4,:);
        % metrics
        errorrate = 100*sum(gotrials(:,id.acc) == 2) / size(gotrials,1);
        missrate = 100*sum(gotrials(:,id.acc) == 99) / size(gotrials,1);
        stoprate = 100*size(succstop,1) / size(stoptrials,1);
        RT = mean(correcttrials(:,id.rt));
        % display
        disp(['End of block ' num2str(trialseq(it,id.blo)) '/' num2str(trialseq(end,id.blo))]);
        disp(['GoRT: ' num2str(RT) 'ms']);
        disp(['Stop Rate: ' num2str(stoprate) '%']);
        disp(['Error Rate: ' num2str(errorrate) '%']);
        disp(['Miss Rate: ' num2str(missrate) '%']);
        disp(['Current SSD: ' num2str(trialseq(it,id.lssd)) ' (left), '  num2str(trialseq(it,id.rssd)) ' (right).']);
        % Halt
        WaitSecs(1); KbWait(-1);
    end
    
end

% end
ShowCursor;
PsychPortAudio('Close', settings.sound.audiohandle);